﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using Caliburn.Micro;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;

namespace SatStoreTrac
{
  public  class AddItemViewModel : Screen
    {

        public ObservableCollection<ItemCategory> _StoreItems = new ObservableCollection<ItemCategory>();

        public ObservableCollection<ItemCategory> StoreItems { get { return _StoreItems; } set { _StoreItems = value; } }

        private string _isSaveOrUpdate = "Add New";
        public string isSaveOrUpdate { get { return _isSaveOrUpdate; } set { _isSaveOrUpdate = value; NotifyOfPropertyChange(() => isSaveOrUpdate); } }
       double DefaultPrice = 0;
       double ROLForItem = 0;
        private string _txtName;
        private string _txtROLvalue;
        private string _txtDefaultPricevalue;
        private int pageindex = 0;
        private int pageSize = 15;
        private string searchCriteria = "";
        public bool IsUpdate { get { return  _IsUpdate; } set { _IsUpdate = value; NotifyOfPropertyChange(() => IsUpdate); } }
        public bool _IsUpdate = false;
        public int CurrentItemID = 0;
        private bool _isAllChecked = false;
        public bool isAllChecked { get { return _isAllChecked; } set { _isAllChecked = value; NotifyOfPropertyChange(() => isAllChecked); } }

      
        private string _txtItemID = "";
        public string txtItemID { get { return _txtItemID; } set { _txtItemID = value; NotifyOfPropertyChange(() => txtItemID); } }

      private string _txtIDBox = "";
        public string txtIDBox { get { return _txtIDBox; } set { _txtIDBox = value; NotifyOfPropertyChange(() => txtIDBox); } }
        public string txtItemName {get { return _txtName;} set {_txtName=value; NotifyOfPropertyChange(() => txtItemName);}}
        public string txtROL { get { return _txtROLvalue; } set { _txtROLvalue = value; NotifyOfPropertyChange(() => txtROL); } }
        public string txtDefaultPrice { get { return _txtDefaultPricevalue; } set { _txtDefaultPricevalue = value; NotifyOfPropertyChange(() => txtDefaultPrice); } }

       ISession currentses = null;

       public ItemCategoryService itemCategoryService= new ItemCategoryService();

       public void Pagination(string direction)
       {

           switch (direction.ToUpper()){

               case "FORWARD": GoForward(); break;
               case "BACK": GoBack(); break;
               default: break;

           }


           
        }


       public void GetItemByID()
       {

           try
           {


               if (txtIDBox.Trim() == "")
               {

                   MessageBox.Show("Enter Id ", "ID Cannot Be Empty", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                   return;
               }
               int DispatchID = -1;
               if (!int.TryParse(txtIDBox.Trim(), out DispatchID))
               {
                   MessageBox.Show("ID is not an number ", "ID has to be an integer", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                   return;


               }

               if (DispatchID < 0)
               {
                   MessageBox.Show("ID Should be an positive number ", "ID has to be Positive number", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                   return;


               }


               ItemCategory Tempitem = ItemCategoryService.GetItemCategory(DispatchID);


              



               if (Tempitem == null)
               {

                   MessageBox.Show("No Dispatch  with the ID  " + DispatchID.ToString(), "NO Dispatch", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                   return;
               }

            //   ClearForm();

               txtDefaultPrice = Tempitem.DefaultPrice.ToString();
               txtROL = Tempitem.ROL.ToString();
               txtItemName = Tempitem.ItemName;
               txtItemID = (Tempitem.ItemTypeId ?? -1).ToString();
               CurrentItemID = Tempitem.ItemTypeId ?? -1;
               IsUpdate = true;
               isSaveOrUpdate = "Update";
               
               

               //TODO: ADD PURCHASE RETURN ITEMS LATER

           }

           catch (Exception ex)
           {
               MessageBox.Show("Error gettting Data! Try restart Application", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
           }



       }

       public void GoForward()
       {

           try
           {

               var results = itemCategoryService.QueryItemCategoryByName(searchCriteria, this.pageSize, this.pageindex + 1);

               if (results.Count() <= 0)
               {

                   MessageBox.Show("Last Page cannot go Forward!", "Navigation Message", MessageBoxButton.OK, MessageBoxImage.Exclamation);

               }
               else
               {
                   this.pageindex += 1;
                   StoreItems.Clear();
                   foreach (var ItemsInList in results)
                   {


                       _StoreItems.Add(ItemsInList);


                   }

                   ClearForm();


               }

           }
           catch (Exception ex)
           {

               MessageBox.Show("Unexpected Error: Try restart ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

           }
       }

      public void GoBack()
      {
          try
          {

              if (this.pageindex <= 0)
              {
                  MessageBox.Show("First Page cannot go back!", "Navigation Message", MessageBoxButton.OK, MessageBoxImage.Exclamation);

              }



              else
              {
                  var results = itemCategoryService.QueryItemCategoryByName(searchCriteria, this.pageSize, this.pageindex - 1);

                  this.pageindex -= 1;
                  StoreItems.Clear();
                  foreach (var ItemsInList in results)
                  {


                      _StoreItems.Add(ItemsInList);


                  }

                  ClearForm();


              }
          }
          catch (Exception ex)
          {

              MessageBox.Show("Unexpected Error: Try restart ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

          }

      }



       public void SearchItems(string Criteria,bool isAll)
       {

           try
           {
               if (isAll)
               {
                   isAllChecked = true;
                   searchCriteria = "";

               }
               else { searchCriteria = Criteria; isAllChecked = false; }
               pageindex = 0;
               _StoreItems.Clear();
               var results = itemCategoryService.QueryItemCategoryByName(searchCriteria, this.pageSize, this.pageindex);
               foreach (var ItemsInList in results)
               {


                   _StoreItems.Add(ItemsInList);


               }

               ClearForm();

           }
           catch (Exception ex)
           {
               MessageBox.Show("Unexpected Error showing Items list: Try restart ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
               
           }
       }
       

       public AddItemViewModel()
       {
          /*
           if (currentses == null)
           {

               currentses = SecurityValuesForApp.AppDataFactory.OpenSession();

           }



           IQuery resultsquery = currentses.CreateQuery(" from  ItemCategory order by ItemName");
           */
           isAllChecked = true;
           var results = itemCategoryService.QueryItemCategoryByName("",this.pageSize , this.pageindex);
           foreach (var ItemsInList in results)
           {


               _StoreItems.Add(ItemsInList);

              
           }

           ClearForm();
       }

       bool confirmOperation()
       {
           if (CurrentItemID <= 0) { MessageBox.Show("No Active record ! To Delete Select a Item", "Select a Item", MessageBoxButton.OK, MessageBoxImage.Exclamation); return false; } 
         //  if (CurrentItemID <= 0) return true;

           if (MessageBoxResult.Yes == MessageBox.Show("All the Item name in the database will be replaced \r\n Including Previous transactions \r\n To DO You want to Proceed?", "Proceed with Caution", MessageBoxButton.YesNo, MessageBoxImage.Question))
           {
               LoginViewModel TempLogin = new LoginViewModel(true);
               SecurityValuesForApp.AppWindowManger.ShowDialog(TempLogin);

               return TempLogin.LoginSuccess;



           }


           return false;


       }


       public void DeleteItem()
       {

           if (CurrentItemID <= 0) { MessageBox.Show("No Active record ! To Delete Select a Item", "Select a Item", MessageBoxButton.OK, MessageBoxImage.Exclamation); return; } 

           try{
           if (confirmDeleteOperation())
           {


               if (ItemCategoryService.DeleteItemCategory(CurrentItemID)) { MessageBox.Show("Successfully Deleted  the  Item " + txtItemName, "Sucess", MessageBoxButton.OK, MessageBoxImage.Information); SearchItems("", true); return; }

               MessageBox.Show("Cannot Delete the Record due to dependent Transactions ", "Cannot Delete", MessageBoxButton.OK, MessageBoxImage.Exclamation); return;


           }
           
           }
           
           catch(Exception ex){
               MessageBox.Show("Error Deleting the Item. May be the Item does not exist", "Error", MessageBoxButton.OK, MessageBoxImage.Error); return;

           }





       }



       bool confirmDeleteOperation()
       {

           if (CurrentItemID <= 0) return false;

           if (MessageBoxResult.Yes == MessageBox.Show("The the Item" + txtItemName +  " in the database will be Deleted \r\n To DO You want to Proceed?", "Proceed with Caution", MessageBoxButton.YesNo, MessageBoxImage.Question))
           {
               LoginViewModel TempLogin = new LoginViewModel(true);
               SecurityValuesForApp.AppWindowManger.ShowDialog(TempLogin);

               return TempLogin.LoginSuccess;



           }


           return false;


       }

       public void btnSaveOrUpdate(RoutedEventArgs e)
        {
            e.Handled = true;
            try
            {
                if (currentses == null)
                {

                    currentses = SecurityValuesForApp.AppDataFactory.OpenSession();

                }
                if (!currentses.IsOpen)
                {
                    currentses = SecurityValuesForApp.AppDataFactory.OpenSession();
                }
                if (validateForm())
                {
                    string updateORNew = "";
                    ItemCategory ItemCategoryObj = new ItemCategory();
                    updateORNew = " Added ";
                    if (CurrentItemID > 0) { ItemCategoryObj.ItemTypeId = CurrentItemID; updateORNew = " Updated "; }

                    if (!confirmOperation()) { return; }

                    ItemCategoryObj.DefaultPrice = DefaultPrice;
                    ItemCategoryObj.ItemName = txtItemName.Trim();
                    ItemCategoryObj.ROL = ROLForItem;
                    currentses.SaveOrUpdate(ItemCategoryObj); currentses.Flush(); currentses.Close();
                    MessageBox.Show("Successfully " + updateORNew + " the Item Category", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    SearchItems("", true);
                    
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Failed to add or update the Item Category", "Failed ", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

       


      public  void ShowItemSelectedInList(ListView itemsList)
        {

          

            if (itemsList.SelectedItem!= null)
            {
                ItemCategory Tempitem = itemsList.SelectedItem as ItemCategory;

                txtDefaultPrice = Tempitem.DefaultPrice.ToString();
                txtROL = Tempitem.ROL.ToString();
                txtItemName =Tempitem.ItemName;
                txtItemID = (Tempitem.ItemTypeId ?? -1).ToString();
                CurrentItemID = Tempitem.ItemTypeId??-1;
                IsUpdate = true;
                isSaveOrUpdate = "Update";
            }




        }
        public void ClearForm()
        {

            txtItemID = "Add New..";
            txtDefaultPrice = "0";
            txtROL = "0";
            txtItemName = "";
            ROLForItem = 0;
            DefaultPrice =0;
            CurrentItemID = 0;
            IsUpdate = false;
            isSaveOrUpdate = "Add New";


        }

        private bool validateForm()
        {
            StringBuilder str = new StringBuilder();
            try
            {
                if (txtItemName.Trim() == "")
                {


                    str.Clear();
                    str.Append("Item name cannot be empty");
                    throw new Exception();
                }

                if (CurrentItemID <= 0)
                {

                    string hqlquery = "select ItemName from ItemCategory where ItemName= :ItemName";

                    IQuery query = currentses.CreateQuery(hqlquery).SetString("ItemName", txtItemName.Trim());

                    if (query.List().Count > 0)
                    {


                        str.Clear();
                        str.Append("Item with this name is already in database");
                        throw new Exception();
                    }

                }

                str.Append("Default Price should be a Money");
                NumberStyles style = NumberStyles.AllowDecimalPoint;
                Decimal Moneyvalue;

                Moneyvalue = decimal.Parse(txtDefaultPrice.Trim(), style);
                DefaultPrice = (double)Moneyvalue;
                if ((DefaultPrice <= 0)|| (DefaultPrice.ToString().Count(x=>x=='.')>1))
                {

                    str.Clear();
                    str.Append("Default price cannot be negative or zero or more than one decimal point");
                    throw new Exception();
                }

                if ((DefaultPrice.ToString().Contains(".")) && ((DefaultPrice.ToString().Length - (DefaultPrice.ToString().IndexOf(".") + 1)) > 2))
                {


                    str.Clear();
                    str.Append("Default price cannot more than two decimals");
                    throw new Exception();
                }


                str.Clear();
                str.Append("ROL(Reorder level) is not valid number");
                int temp=int.Parse(txtROL.Trim());
                ROLForItem = temp;

                if ((ROLForItem <= 0))
                {

                    str.Clear();
                    str.Append("Reorder level cannot be negative or zero");
                    throw new Exception();
                }

                return true;
            }

            catch (Exception ex)
            {
                MessageBox.Show(str.ToString(), "Error Saving Item record", MessageBoxButton.OK, MessageBoxImage.Error);


                return false;
            }

         //   return false;

        }

       
    }
}
