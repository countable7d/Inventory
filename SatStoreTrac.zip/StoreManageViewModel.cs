﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using Caliburn.Micro;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;
namespace SatStoreTrac
{
    class StoreManageViewModel:Screen
    {
    
    
    // _StoreItems binds to listview
    public ObservableCollection<StoreData> _StoreItems = new ObservableCollection<StoreData>();

        public ObservableCollection<StoreData> StoreItems { get { return _StoreItems; } set { _StoreItems = value; } }


       double DefaultPrice = 0;
       double ROLForItem = 0;
       private string _isSaveOrUpdate = "Add New";
        private string _txtStoreName;
        private string _txtStoreLocation;
        private string _txtStorePhone;
        private string _txtStoreAddress;
        private bool _isAllChecked = false;
        private bool _isSearchChecked = false;
        private int pageindex = 0;
        private int pageSize = 15;
        private string searchCriteria = "";
        public string isSaveOrUpdate { get { return _isSaveOrUpdate; } set { _isSaveOrUpdate = value; NotifyOfPropertyChange(() => isSaveOrUpdate); } }
        public bool IsUpdate { get { return  _IsUpdate; } set { _IsUpdate = value; NotifyOfPropertyChange(() => IsUpdate); } }
        public bool _IsUpdate = false;
        public int CurrentItemID = 0;
        private string _txtItemID = "";
        private string _txtIDBox = "";

        public string txtIDBox { get { return _txtIDBox; } set { _txtIDBox = value; NotifyOfPropertyChange(() => txtIDBox); } }
        public string txtItemID { get { return _txtItemID; } set { _txtItemID = value; NotifyOfPropertyChange(() => txtItemID); } }
        public bool isSearchChecked { get { return _isSearchChecked; } set { _isSearchChecked = value; NotifyOfPropertyChange(() => isSearchChecked); } }
        public bool isAllChecked { get { return _isAllChecked; } set { _isAllChecked = value; NotifyOfPropertyChange(() => isAllChecked); } }
        public string txtStoreName {get { return _txtStoreName;} set {_txtStoreName=value; NotifyOfPropertyChange(() => txtStoreName);}}
        public string txtStoreLocation { get { return _txtStoreLocation; } set { _txtStoreLocation = value; NotifyOfPropertyChange(() => txtStoreLocation); } }
        public string txtStorePhone { get { return _txtStorePhone; } set { _txtStorePhone = value; NotifyOfPropertyChange(() => txtStorePhone); } }
        public string txtStoreAddress { get { return _txtStoreAddress; } set { _txtStoreAddress = value; NotifyOfPropertyChange(() => txtStoreAddress); } }
       ISession currentses = null;

       public StoresService itemCategoryService= new StoresService();

       public void Pagination(string direction)
       {

           switch (direction.ToUpper()){

               case "FORWARD": GoForward(); break;
               case "BACK": GoBack(); break;
               default: break;

           }


           
        }



        /// <summary>
        /// 
        /// </summary>





       public void GetItemByID()
       {

           try
           {


               if (txtIDBox.Trim() == "")
               {

                   MessageBox.Show("Enter Id ", "ID Cannot Be Empty", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                   return;
               }
               int DispatchID = -1;
               if (!int.TryParse(txtIDBox.Trim(), out DispatchID))
               {
                   MessageBox.Show("ID is not an number ", "ID has to be an integer", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                   return;


               }

               if (DispatchID < 0)
               {
                   MessageBox.Show("ID Should be an positive number ", "ID has to be Positive number", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                   return;


               }


               StoreData Tempitem = StoresService.GetStore(DispatchID);






               if (Tempitem == null)
               {

                   MessageBox.Show("No Dispatch  with the ID  " + DispatchID.ToString(), "NO Dispatch", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                   return;
               }

               //   ClearForm();

               txtStoreName = Tempitem.StoreName;
               txtStoreLocation = Tempitem.StoreLocation ?? "";
               txtStorePhone = Tempitem.StorePhone ?? "";
               txtStoreAddress = Tempitem.Address ?? "";
               txtItemID = (Tempitem.StoreId ?? -1).ToString();
               CurrentItemID = Tempitem.StoreId ?? -1;
               IsUpdate = true;
               isSaveOrUpdate = "Update";



               //TODO: ADD PURCHASE RETURN ITEMS LATER

           }

           catch (Exception ex)
           {
               MessageBox.Show("Error gettting Data! Try restart Application", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
           }



       }





       public void DeleteItem()
       {

           if (CurrentItemID <= 0) { MessageBox.Show("No Active record ! To Delete Select a Item", "Select a Item", MessageBoxButton.OK, MessageBoxImage.Exclamation); return; }

           try
           {
               if (confirmDeleteOperation())
               {


                   if (StoresService.DeleteStore(CurrentItemID)) { MessageBox.Show("Successfully Deleted  the  Item " + txtStoreName , "Sucess", MessageBoxButton.OK, MessageBoxImage.Information); SearchItems("", true); return; }

                   MessageBox.Show("Cannot Delete the Record due to dependent Transactions ", "Cannot Delete", MessageBoxButton.OK, MessageBoxImage.Exclamation); return;


               }

           }

           catch (Exception ex)
           {
               MessageBox.Show("Error Deleting the Item. May be the Item does not exist", "Error", MessageBoxButton.OK, MessageBoxImage.Error); return;

           }





       }



       bool confirmDeleteOperation()
       {

           if (CurrentItemID <= 0) return false;

           if (MessageBoxResult.Yes == MessageBox.Show("The the Item" + txtStoreName + " in the database will be Deleted \r\n To DO You want to Proceed?", "Proceed with Caution", MessageBoxButton.YesNo, MessageBoxImage.Question))
           {
               LoginViewModel TempLogin = new LoginViewModel(true);
               SecurityValuesForApp.AppWindowManger.ShowDialog(TempLogin);

               return TempLogin.LoginSuccess;



           }


           return false;


       }










        //





       public void GoForward()
       {

           try
           {

               var results = itemCategoryService.QueryStoresByName(searchCriteria, this.pageSize, this.pageindex + 1);

               if (results.Count() <= 0)
               {

                   MessageBox.Show("Last Page cannot go Forward!", "Navigation Message", MessageBoxButton.OK, MessageBoxImage.Exclamation);

               }
               else
               {
                   this.pageindex += 1;
                   StoreItems.Clear();
                   foreach (var ItemsInList in results)
                   {


                       _StoreItems.Add(ItemsInList);


                   }

                   ClearForm();


               }

           }
           catch (Exception ex)
           {

               MessageBox.Show("Unexpected Error: Try restart ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

           }
       }

      public void GoBack()
      {
          try
          {

              if (this.pageindex <= 0)
              {
                  MessageBox.Show("First Page cannot go back!", "Navigation Message", MessageBoxButton.OK, MessageBoxImage.Exclamation);

              }



              else
              {
                  var results = itemCategoryService.QueryStoresByName(searchCriteria, this.pageSize, this.pageindex - 1);

                  this.pageindex -= 1;
                  StoreItems.Clear();
                  foreach (var ItemsInList in results)
                  {


                      _StoreItems.Add(ItemsInList);


                  }

                  ClearForm();


              }
          }
          catch (Exception ex)
          {

              MessageBox.Show("Unexpected Error: Try restart ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

          }

      }



       public void SearchItems(string Criteria,bool isAll)
       {
           if (isAll)
           {

               isAllChecked = true;
              

           }
           else
           {
               isAllChecked = false;
              
           }
           try
           {
               if (isAll)
               {

                   searchCriteria = "";

               }
               else { searchCriteria = Criteria; }
               pageindex = 0;
               _StoreItems.Clear();
               var results = itemCategoryService.QueryStoresByName(searchCriteria, this.pageSize, this.pageindex);
               foreach (var ItemsInList in results)
               {


                   _StoreItems.Add(ItemsInList);


               }

               ClearForm();

           }
           catch (Exception ex)
           {
               MessageBox.Show("Unexpected Error showing stores list: Try restart ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
               
           }
       }
       

       public StoreManageViewModel()
       {
          /*
           if (currentses == null)
           {

               currentses = SecurityValuesForApp.AppDataFactory.OpenSession();

           }



           IQuery resultsquery = currentses.CreateQuery(" from  ItemCategory order by ItemName");
           * 
           */
           isAllChecked = true;
           
           var results = itemCategoryService.QueryStoresByName("",this.pageSize , this.pageindex);
           foreach (var ItemsInList in results)
           {


               _StoreItems.Add(ItemsInList);

              
           }

           ClearForm();
       }

       bool confirmOperation()
       {
           if (CurrentItemID <= 0) { MessageBox.Show("No Active record ! To Delete Select a Item", "Select a Item", MessageBoxButton.OK, MessageBoxImage.Exclamation); return false; }

           if (CurrentItemID <= 0) return false;

           if (MessageBoxResult.Yes == MessageBox.Show("All the store names in the database will be replaced \r\n Including in Previous transactions \r\n To DO You want to Proceed?", "Proceed with Caution", MessageBoxButton.YesNo, MessageBoxImage.Question))
           {
               LoginViewModel TempLogin = new LoginViewModel(true);
               SecurityValuesForApp.AppWindowManger.ShowDialog(TempLogin);

               return TempLogin.LoginSuccess;



           }


           return false;


       }


       public void btnSaveOrUpdate(RoutedEventArgs e)
        {
            try
            {
                if (currentses == null)
                {

                    currentses = SecurityValuesForApp.AppDataFactory.OpenSession();

                }
                if (!currentses.IsOpen)
                {
                    currentses = SecurityValuesForApp.AppDataFactory.OpenSession();
                }
                e.Handled = true;
                if (validateForm())
                {
                    string updateORNew = "";
                    StoreData storeItemObj = new StoreData();
                    updateORNew = " Added ";
                    if (CurrentItemID > 0) { storeItemObj.StoreId = CurrentItemID; updateORNew = " Updated "; }
                    if (!confirmOperation()) { return; }
                    storeItemObj.StoreName=txtStoreName;
                    storeItemObj.StoreLocation=txtStoreLocation;
                    storeItemObj.StorePhone=txtStorePhone;
                    storeItemObj.Address=txtStoreAddress;
                    storeItemObj.StoreType="D";
                    currentses.SaveOrUpdate(storeItemObj); currentses.Flush(); currentses.Close();
                    
                    MessageBox.Show("Successfully " + updateORNew + " the Item Category", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    SearchItems("", true);
                   // ClearForm();
                }
            }
            catch (Exception ex)
            {
                e.Handled = true;
                MessageBox.Show("Failed to add or update the Item Category", "Failed ", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        


      public  void ShowItemSelectedInList(ListView itemsList)
        {

          

            if (itemsList.SelectedItem!= null)
            {
                StoreData Tempitem = itemsList.SelectedItem as StoreData;

                txtStoreName = Tempitem.StoreName;
                txtStoreLocation = Tempitem.StoreLocation??"";
                txtStorePhone =Tempitem.StorePhone??"";
                txtStoreAddress=Tempitem.Address??"";
                txtItemID = (Tempitem.StoreId ?? -1).ToString();
                CurrentItemID = Tempitem.StoreId??-1;
                IsUpdate = true;
                isSaveOrUpdate = "Update" ;
            }




        }
        public void ClearForm()
        {

            txtItemID = "Add New..";
            txtStoreName = "";
                txtStoreLocation = "";
                txtStorePhone ="";
                txtStoreAddress="";
            CurrentItemID = 0;
            IsUpdate = false;
            isSaveOrUpdate = "Add New";


        }

        private bool validateForm()
        {
            StringBuilder str = new StringBuilder();
            try
            {
                if (txtStoreName.Trim() == "")
                {


                    str.Clear();
                    str.Append("Store Name cannot be empty");
                   
                    throw new Exception();
                }

                if (CurrentItemID<=0){

                string hqlquery = "select StoreName from StoreData where StoreName= :ItemName";

                IQuery query = currentses.CreateQuery(hqlquery).SetString("ItemName", txtStoreName.Trim());
                    
                if (query.List().Count > 0)
                {


                    str.Clear();
                    str.Append("Store with this name is already in database");
                    throw new Exception();
                }
                }

                /*

                str.Append("Default Price should be a Money");
                NumberStyles style = NumberStyles.AllowDecimalPoint;
                Decimal Moneyvalue;

                Moneyvalue = decimal.Parse(txtDefaultPrice.Trim(), style);
                DefaultPrice = (double)Moneyvalue;
                if ((DefaultPrice <= 0))
                {

                    str.Clear();
                    str.Append("Default price cannot be negative or zero");
                    throw new Exception();
                }

                if ((DefaultPrice.ToString().Contains(".")) && ((DefaultPrice.ToString().Length - (DefaultPrice.ToString().IndexOf(".") + 1)) > 2))
                {


                    str.Clear();
                    str.Append("Default price cannot more than two decimals");
                    throw new Exception();
                }


                str.Clear();
                str.Append("ROL(Reorder level) is not valid number");

                ROLForItem = Convert.ToDouble(txtROL.Trim());

                if ((ROLForItem <= 0))
                {

                    str.Clear();
                    str.Append("Reorder level cannot be negative or zero");
                    throw new Exception();
                }

                return true; */
            }

            catch (Exception ex)
            {
                MessageBox.Show(str.ToString(), "Error Saving Item record", MessageBoxButton.OK, MessageBoxImage.Error);

                
                return false;
            }

                 
            return true;

        }

       
    }
}

    
    
    

