﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using Caliburn.Micro;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;

namespace SatStoreTrac
{
    class LoginViewModel : Screen
    {
        public ObservableCollection<PinData> thisPinData = new ObservableCollection<PinData>(SecurityValuesForApp.UserData);
        public bool LoginSuccess = false;
        private string _selectedUser = "";
        public bool isAdminMode = false;
        public bool checkAdmin = false;
        private bool _isError = false;
        public bool isError { get { return _isError; } set { _isError = value; NotifyOfPropertyChange(() => isError); } }
        public string selectedUser { get { return _selectedUser; } set { _selectedUser = value; NotifyOfPropertyChange(() => selectedUser); } }
        public LoginViewModel()
        {

        }

        public LoginViewModel(bool adminMode)
        {
            checkAdmin = adminMode;
        }
        public void btnLogin(RoutedEventArgs argEvent)
        {



        }

        public bool CheckLogin(string UserType, string password)
        {
            if (checkAdmin) { UserType = "Admin"; }

            var pinNumber = thisPinData.Where(x => ((x.UserType.ToUpper().Trim() == UserType.ToUpper().Trim()) && (x.UserString == password))).FirstOrDefault();

            if (pinNumber == null)
            {
                

                LoginSuccess = false; return false;

            }

            else { if (pinNumber.UserType.ToUpper() == "ADMIN") { isAdminMode = true; } LoginSuccess = true; return true; }
            
           }
    }
}
