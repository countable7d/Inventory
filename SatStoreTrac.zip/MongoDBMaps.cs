﻿namespace MongoStoreTrack
{
    
    using System;
    using System.Collections.Generic;
    using MongoDB.Bson;
    using MongoDB.Bson.Serialization.Attributes;
    using MongoDB.Driver;

    public interface IMongoEntity
    {
        ObjectId Id { get; set; }
    }

    public class MongoEntity: IMongoEntity
    {
        [BsonId]
        public ObjectId Id { get; set; }
    }

    


    [BsonIgnoreExtraElements]
    public class ItemCategory : MongoEntity
    {

        public  int? ItemTypeId { get; set; }
        public  double? DefaultPrice { get; set; }
        public  double? ROL { get; set; }
        public  string ItemName { get; set; }
        /*
        public IList<ItemsInfo> FindItemsInfo(int ItemType)
        {

            return new List<ItemsInfo>();
        }
        */

    }
    [BsonIgnoreExtraElements]
    public class StoreItems : MongoEntity
    {
        [BsonElement("itemid")]
        public  int? ItemID { get; set; }
        [BsonElement("itemtyperef")]
        public  ObjectId? ItemTypeRef { get; set; }

        [BsonElement("purchaseprice")]
        public  double? PurchasePrice { get; set; }
        [BsonElement("dispatchprice")]
        public  double? DispatchPrice { get; set; }
        [BsonElement("inStore_or_dispatched")]
        public  string InStore_Or_Dispatched { get; set; }
        [BsonElement("quantity")]
        public  int? Quantity { get; set; }
        [BsonElement("qoh")]
        public  int? QOH { get; set; }
        [BsonElement("instoreid")]
        public  ObjectId? InStoreID { get; set; }
        [BsonElement("purchaseid")]
        public  ObjectId? PurchaseID { get; set; }
        


    }
    [BsonIgnoreExtraElements]
    public class DispatchHistory : MongoEntity
    {
        [BsonElement("outstoreid")]
        public  ObjectId? OutStoreID { get; set; }
        [BsonElement("itemid")]
        public  ObjectId? ItemId { get; set; }
        [BsonElement("dispatchid")]
        public ObjectId? DispatchID { get; set; }
        [BsonElement("quantity")]
        public  int? quantity { get; set; }
        [BsonElement("priceout")]
        public  double? PriceOut { get; set; }
        [BsonElement("percentage")]
        public  double? Percenatge { get; set; }

    }

    [BsonIgnoreExtraElements]
    public class DispatchTrack : MongoEntity
    {
        [BsonElement("notes")]
        public  string Notes { get; set; }
        [BsonElement("dispatcheddate")]
        public  DateTime? DispatchedDate { get; set; }
        [BsonElement("dispatchref")]
        public  string DisPatchRef { get; set; }
    }

    [BsonIgnoreExtraElements]
    public class PurchasesTrack : MongoEntity
    {
       
        [BsonElement("notes")]
        public string Notes { get; set; }
        [BsonElement("purchaseddate")]
        public DateTime? PurchasedDate { get; set; }
        [BsonElement("purchaseref")]
        public string PurchaseRef { get; set; }


    }

    [BsonIgnoreExtraElements]
    public class PinData : MongoEntity
    {
        [BsonElement("usertype")]
        public  string UserType { get; set; }
        [BsonElement("userstring")]
        public  string UserString { get; set; }


    }
    [BsonIgnoreExtraElements]
    public class StoreData : MongoEntity
    {

        [BsonElement("storename")]
        public  string StoreName { get; set; }
        [BsonElement("storelocation")]
        public  string StoreLocation { get; set; }
        [BsonElement("address")]
        public  string Address { get; set; }
        [BsonElement("storetype")]
        public  string StoreType { get; set; }

    }

    // Task Table Table with NHibernate
   





}