﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using Caliburn.Micro;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;

namespace SatStoreTrac
{
    class PurchaseReturnsReportViewModel:Screen
    {
    
        void initializeItemsList()
        {

            //TODO:BEGIN HERE  SEPTEMBER 16 2014


            try
            {
                List<ItemCategory> Temp = ItemCategoryService.QueryItemCategory();
                if (Temp != null)
                {
                    StoreItems = new ObservableCollection<ItemCategory>(Temp);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Error!Restart app", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public int currentItemID = -1, StoreID=-1;
        string DateFormat  = "yyyy-MM-dd HH:mm:ss";

        public ObservableCollection<ItemCategory> _StoreItems = new ObservableCollection<ItemCategory>();

        public ObservableCollection<ItemCategory> StoreItems { get { return _StoreItems; } set { _StoreItems = value; } }
       

        public ObservableCollection<ItemCategoryWithDiscount> listItems = new ObservableCollection<ItemCategoryWithDiscount>();

        public PurchaseReturnsReportViewModel()
        {
            initializeItemsList();
        }

        public bool ValidateItem(bool isOneItem, bool isOnestore, bool isOrginal)
        {

            return false;


        }
    }
}
