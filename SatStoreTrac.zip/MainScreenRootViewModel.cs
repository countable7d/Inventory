﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Caliburn.Micro;
using ActivityDB;
using NHibernate;
using FluentNHibernate;

namespace SatStoreTrac
{
  public  class MainScreenRootViewModel : Conductor<object>
    {

        public MainScreenRootViewModel()
        {
            
            ActivateItem(new FrontViewModel());
        }
    }
}
