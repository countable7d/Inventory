﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ActivityDB;
using NHibernate;
using FluentNHibernate;

using Caliburn.Micro;
namespace SatStoreTrac
{
  public static  class SecurityValuesForApp
    {
      public static bool adminmode { get; set; }
      public static bool Normalmode { get; set; }
      public static bool isLoggedIn { get; set; }
      public static ISessionFactory AppDataFactory = null;
      public static IWindowManager AppWindowManger = null;
      public static List<PinData> UserData=null;
      
    }
}
