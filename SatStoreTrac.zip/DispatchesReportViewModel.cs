﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using Caliburn.Micro;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;

namespace SatStoreTrac
{
    class DispatchesReportViewModel:Screen
    {


        public void SearchDetails()
        {
            listItems.Clear();
            if (ValidateSearch()) { pageNo = 0; GoForward(); }




        }


  

     public enum QueryType { StoreAllItems = 1, ItemAllStores, OneStoreAndOneItem, All };


        public void Pagination(string direction)
        {

            switch (direction.ToUpper())
            {

                case "FORWARD": GoForward(); break;
                case "BACK": GoBack(); break;
                default: break;

            }



        }

        public void GoForward()
        {

            try
            {
                 
                var results = QueryDetails(pageNo);

               
                if (results.Count<=0)
                {

                    if (pageNo == 0)
                    {

                        MessageBox.Show("No Records Found with this criteria!", "No Records", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    }
                    else
                    {

                        MessageBox.Show("No Records Last page Reached!", "Navigation Message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    }
                }
                else
                {
                    listItems = new ObservableCollection<DispatchReportDTO>(results);
                    pageNo += 1;

                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error: Try restart ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        }

        public void GoBack()
        {
            try
            {

                if (this.pageNo <= 0)
                {
                    MessageBox.Show("First Page cannot go back!", "Navigation Message", MessageBoxButton.OK, MessageBoxImage.Exclamation);

                }



                else
                {
                    
                    
                    var results = QueryDetails( pageNo);
                    listItems = new ObservableCollection<DispatchReportDTO>(results);
                    pageNo -= 1;

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Unexpected Error: Try restart ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }

        }






        void initializeItemsList()
        {

            //TODO:BEGIN HERE  SEPTEMBER 16 2014



            try
            {
                List<ItemCategory> Temp = ItemCategoryService.QueryItemCategory();
                if (Temp != null)
                {
                    StoreItems = new ObservableCollection<ItemCategory>(Temp);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Error!Restart app", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public int pageSize = 10;
        public int pageNo = 0;
        public QueryType CurrentQuery;
        public DateTime fromDate = DateTime.MinValue;
        public DateTime toDate = DateTime.MinValue;
        public int currentItemID = -1, StoreID = -1; public bool isOrginal = true;
        string DateFormat  = "yyyy-MM-dd HH:mm:ss";


        public bool _selectItem = false;
        public bool selectItem { get { return _selectItem; } set { _selectItem = value; NotifyOfPropertyChange(() => selectItem); } }
        public bool _selectStore = false;
        public bool selectStore { get { return _selectStore; } set { _selectStore = value; NotifyOfPropertyChange(() => selectStore); } }
        
        // selectorginal true if with purchase returns is selected other wise if orginal dispatches WHERE NOT selected
        public bool _selectOrginal = false;
        public bool selectOrginal { get { return _selectOrginal; } set { _selectOrginal = value; NotifyOfPropertyChange(() => selectOrginal); } }

        public ObservableCollection<ItemCategory> _StoreItems = new ObservableCollection<ItemCategory>();

        public ObservableCollection<ItemCategory> StoreItems { get { return _StoreItems; } set { _StoreItems = value; } }

        public ObservableCollection<DispatchReportDTO> _listItems = new ObservableCollection<DispatchReportDTO>();
        public ObservableCollection<DispatchReportDTO> listItems { get { return _listItems; } set { _listItems = value; NotifyOfPropertyChange(() => listItems); } }
      



        public DispatchesReportViewModel()
        {

           
            initializeItemsList();
        }

        //TODO:BEGIN HERE TO FINISH change queries to dataentity to accomidate all services SEP 18  
        List<DispatchReportDTO> QueryDetails(int argPage)
        {
            switch (CurrentQuery)
            {

                case QueryType.All:
                   return DispatchReportsService.QueryDispatchHistoryReport(pageSize, argPage, isOrginal,toDate, fromDate );
                    
                                                    break;
                case QueryType.ItemAllStores:

                                               return     DispatchReportsService.QueryDispatchHistoryReport(currentItemID, pageSize, argPage, isOrginal, toDate, fromDate );

                                                    break;
                case QueryType.OneStoreAndOneItem:
                                                    return DispatchReportsService.QueryDispatchHistoryReport(StoreID, currentItemID, pageSize, argPage, isOrginal, toDate, fromDate); 


                                                    break;
                case QueryType.StoreAllItems:
                                                return    DispatchReportsService.QueryDispatchHistoryReport(isOrginal, StoreID, pageSize, argPage, toDate, fromDate);
                                                    break;
                default: break;


            }


            return new List<DispatchReportDTO>();


        }


        public bool ValidateSearch()
        {

            if (selectItem)
            {
                if (currentItemID < 0)
                {

                    MessageBox.Show("You have selected a Report for an Item \r\n but not selected the Item \r\n ", "Please select an Item", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return false;
                }


            }

            if (selectStore)
            {
                if (StoreID < 0)
                {

                    MessageBox.Show("You have selected a Report for an Store \r\n but not selected the Store \r\n ", "Please select a Store", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return false;
                }




            }

            if ((toDate == DateTime.MinValue) || (fromDate == DateTime.MinValue))
            {
                

                    MessageBox.Show("Either from Date or To date is not selected ", "SELECT Dates!", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return false;
                




            }



            if (selectStore && selectItem) { CurrentQuery = QueryType.OneStoreAndOneItem; }
            if ((!selectStore) && (!selectItem)) { CurrentQuery = QueryType.All; }
            if ((!selectStore) && (selectItem)) { CurrentQuery = QueryType.ItemAllStores; }
            if ((selectStore) && (!selectItem)) { CurrentQuery = QueryType.StoreAllItems; }
            isOrginal = !selectOrginal;





            return true;



        }


    
    }
}
