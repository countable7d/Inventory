﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using Caliburn.Micro;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;

namespace SatStoreTrac
{
    class ReturnsViewModel : Screen
    {
        private bool _isSaved = false;
        public int currentItemID = 0;
        public bool isSaved { get { return _isSaved; } set { _isSaved = value; NotifyOfPropertyChange(() => isSaved); } }
        private string _txtItemName = "";
        private string _txtDispatchPrice = "";
        private string _txtQOH = "";
        private string _txtQuantity = "";
        private string _txtPercentage = "";
        private string _txtRefNo = "";
        private string _txtNotes = "";
        private bool _chkEnabled = true;
        public bool isLoadPurchase = true;
        public bool isLoadDiscount = true;
        public bool chkRestrictEnabled
        {
            get { return _chkEnabled; }
            set
            {
                _chkEnabled = value;
                NotifyOfPropertyChange(() => chkRestrictEnabled);

            }
        }
        public string txtRefNo { get { return _txtRefNo; } set { _txtRefNo = value; NotifyOfPropertyChange(() => txtRefNo); } }
        public string txtNotes { get { return _txtNotes; } set { _txtNotes = value; NotifyOfPropertyChange(() => txtNotes); } }
        public string onetxtItemName { get { return _txtItemName; } set { _txtItemName = value; NotifyOfPropertyChange(() => onetxtItemName); } }

        public string txtQuantity { get { return _txtQuantity; } set { _txtQuantity = value; NotifyOfPropertyChange(() => txtQuantity); } }
        public string txtDispatchPrice { get { return _txtDispatchPrice; } set { _txtDispatchPrice = value; NotifyOfPropertyChange(() => txtDispatchPrice); } }
        public string txtQOH { get { return _txtQOH; } set { _txtQOH = value; NotifyOfPropertyChange(() => txtQOH); } }
        public string txtPercentage { get { return _txtPercentage; } set { _txtPercentage = value; NotifyOfPropertyChange(() => txtPercentage); } }
        public List<ItemCategory> itemsDB = new List<ItemCategory>();
        public List<ItemsTrack> registerDB = new List<ItemsTrack>();
        public List<ItemCategory> itemsDBTemp = new List<ItemCategory>();
        public List<ItemsTrack> registerDBTemp = new List<ItemsTrack>();
        public ObservableCollection<ItemCategory> _listItems = new ObservableCollection<ItemCategory>();

        public ObservableCollection<ItemCategory> listItems { get { return _listItems; } set { _listItems = value; } }

        public ObservableCollection<ItemCategory> _StoreItems = new ObservableCollection<ItemCategory>();

        public ObservableCollection<ItemCategory> StoreItems { get { return _StoreItems; } set { _StoreItems = value; } }
        public ItemCategory currentItemCategory = null;

        public ObservableCollection<string> PreviousPurchases { get { return _PreviousPurchases; } set { _PreviousPurchases = value; } }
        public ObservableCollection<string> _PreviousPurchases = new ObservableCollection<string>();

        public ObservableCollection<string> PreviousDiscounts { get { return _PreviousDiscounts; } set { _PreviousDiscounts = value; } }
        public ObservableCollection<string> _PreviousDiscounts = new ObservableCollection<string>();
        public int StoreID = -1;
        public string StoreName;

        private ItemCategory _selectedStoreItem;
        public ItemCategory selectedStoreItem { get { return _selectedStoreItem; } set { _selectedStoreItem = value; NotifyOfPropertyChange(() => selectedStoreItem); } }
        private int _SelectedIndexPurchasePrice;
        private int _SelectedIndexDiscount;
        public int SelectedIndexPurchasePrice
        {
            get
            {
                return _SelectedIndexPurchasePrice;
            }
            set
            {
                _SelectedIndexPurchasePrice = value;
                NotifyOfPropertyChange(() => SelectedIndexPurchasePrice);
            }
        }

        public int SelectedIndexDiscount
        {
            get
            {
                return _SelectedIndexDiscount;
            }
            set
            {
                _SelectedIndexDiscount = value;
                NotifyOfPropertyChange(() => SelectedIndexDiscount);
            }
        }
        public List<string> cmbPrevPurchasePrice
        {
            get
            {
                // silly example of the collection to bind to
                return new List<string>(PreviousPurchases);
            }
            private set
            {

                if (value != null)
                {

                    PreviousPurchases = new ObservableCollection<string>(value);
                    NotifyOfPropertyChange(() => cmbPrevPurchasePrice);
                    if (PreviousPurchases.Count > 0)
                    {
                        SelectedIndexPurchasePrice = 0;
                    }

                }

            }

        }

        public List<string> cmbPrevDiscounts
        {
            get
            {
                // silly example of the collection to bind to
                return new List<string>(PreviousDiscounts);
            }
            private set
            {

                if (value != null)
                {

                    PreviousDiscounts = new ObservableCollection<string>(value);
                    NotifyOfPropertyChange(() => cmbPrevDiscounts);
                    if (PreviousDiscounts.Count > 0)
                    {
                        SelectedIndexDiscount = 0;
                    }

                }

            }

        }





        

        public void ClearForm()
        {
            itemsDB = ItemsService.GetRegisterAndItems(out registerDB);
            initializeItemsList();

            //    StoreItems = new ObservableCollection<ItemCategory>(itemsDB);
            listItems.Clear();
            ClearAddList();
            isSaved = false;

        }
        private string _selectedcmbPrevPurchasePrice;
        public string SelectedcmbPrevPurchasePrice
        {
            get { return _selectedcmbPrevPurchasePrice; }
            set
            {
                _selectedcmbPrevPurchasePrice = value;
                NotifyOfPropertyChange(() => SelectedcmbPrevPurchasePrice);
                // and do anything else required on selection changed
            }
        }
        private string _SelectedcmbPrevDiscount = "";
        public string SelectedcmbPrevDiscount
        {
            get { return _SelectedcmbPrevDiscount; }
            set
            {
                _SelectedcmbPrevDiscount = value;
                NotifyOfPropertyChange(() => SelectedcmbPrevDiscount);
                // and do anything else required on selection changed
            }
        }

      

        public string txtStoreName {get { return _txtStoreName;} set {_txtStoreName= value; NotifyOfPropertyChange(()=>txtStoreName);}}
        public string _txtStoreName ;

        public bool vaildateReturns(out DispatchItems argItemToReturn)
        {
            Decimal tmpDiscount = -1, tmpPurchasePrice = -1;
            int tmpQuantity = -1, tempQOH=-1;

            argItemToReturn = new DispatchItems();
            if (!decimal.TryParse(SelectedcmbPrevDiscount, out tmpDiscount)){

                MessageBox.Show("Discount Price is  not valid ", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                argItemToReturn = null;
                return false;
                
            }

            if (!decimal.TryParse(SelectedcmbPrevPurchasePrice, out tmpPurchasePrice))
            {

                MessageBox.Show("Dispacth Price is  not valid ", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                argItemToReturn = null;
                return false;

            }
            
           if(! int.TryParse(txtQuantity.Trim(), out tmpQuantity))
            {

                MessageBox.Show("Quantity is not valid", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                argItemToReturn = null;
                return false;

            }
           if (!int.TryParse(txtQOH.Trim(), out tempQOH))
           {

               MessageBox.Show("Quantity on Hand is not a Number", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
               argItemToReturn = null;
               return false;

           }

           if (tmpQuantity> tempQOH)
           {

               MessageBox.Show("Purchase Return Quantity cannot be more than Quantity on hand !", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
               argItemToReturn = null;
               return false;

           }

            int tempQuantityQOH=QOHForAnItem(currentItemID,StoreID,tmpPurchasePrice,tmpDiscount);


            // beging here 


            if (tempQuantityQOH != tempQOH)
            {

                MessageBox.Show("Purchase Return Quantity cannot be more than Quantity on hand !", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                argItemToReturn = null;
                return false;
            }


          if  (!( MessageBox.Show("DO you want To Return "+ onetxtItemName + " of quantity " + tmpQuantity + " from store " + txtStoreName,"Do you want to proceed? " ,MessageBoxButton.YesNo,MessageBoxImage.Question)== MessageBoxResult.Yes) )
          {

              
              argItemToReturn = null;
              return false;
          }


          argItemToReturn.DispatchPrice = tmpPurchasePrice;
          argItemToReturn.OutStoreID = StoreID;
          argItemToReturn.ItemCategoryID = currentItemID;
          argItemToReturn.QOH = tmpQuantity;
          argItemToReturn.Percenatge = tmpDiscount;
              return true;


        }
        public void btnSaveOrUpdate(RoutedEventArgs e)
        {
            int Tempint = -2;
            e.Handled = true;
            if (isSaved)
            {

                MessageBox.Show("Information already Saved. To add more items Clear form ", "Information", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Put the Validation code here


           

            try
            {

                Mouse.OverrideCursor = Cursors.Wait;
                DispatchItems tmpDispatchItem=null;

                if (vaildateReturns(out tmpDispatchItem)){

                if (((new DispacthTrackService()).ProcessPurchaseReturns(tmpDispatchItem.ItemCategoryID??0, tmpDispatchItem.OutStoreID??0, tmpDispatchItem.QOH??0, tmpDispatchItem.Percenatge??0, tmpDispatchItem.DispatchPrice??0, false)) != StateOfOperation.Success) { Tempint = -1; throw new Exception(); }
                MessageBox.Show("Purchase Returns Done successfully", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                isSaved = true;
                 ClearForm();
                }
            }
            catch (Exception ex)
            {

                if (Tempint < 0)
                {

                    MessageBox.Show("Error in adding Items ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    MessageBox.Show("Error clearing the Form \r\n But Items are Saved successfully to DataBase", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                }

            }
            finally
            {

                Mouse.OverrideCursor = null;

            }
        }

        void initializeItemsList()
        {

            foreach (var tempItem in registerDB)
            {


                var GetItemDB = itemsDBTemp.Where(x => x.ItemTypeId == tempItem.ItemsCategoryID).FirstOrDefault();

                if (GetItemDB == null)
                {
                    var getItemName = itemsDB.Where(x => x.ItemTypeId == tempItem.ItemsCategoryID).First().ItemName;
                    itemsDBTemp.Add(new ItemCategory() { ItemTypeId = tempItem.ItemsCategoryID, ItemName = getItemName, DefaultPrice = 0, ROL = tempItem.QOH });

                }
                else
                {
                    GetItemDB.ROL += tempItem.QOH ?? 0;


                }



            }

            StoreItems = new ObservableCollection<ItemCategory>(itemsDBTemp);

        }
        public ReturnsViewModel()
        {
            itemsDB = ItemsService.GetRegisterAndItems(out registerDB);



            initializeItemsList();

            ClearAddList();
        }

       public void ClearAfterStoreSelection(){

           isLoadDiscount = true;
           isLoadPurchase = true;
            PreviousPurchases.Clear();
            PreviousDiscounts.Clear();
            PreviousPurchases = new ObservableCollection<string>();
            PreviousPurchases.Add("N/A");
            cmbPrevPurchasePrice = PreviousPurchases.ToList<string>();
            PreviousDiscounts.Add("N/A");
            cmbPrevDiscounts = PreviousDiscounts.ToList<string>();
            currentItemID = -1;
            currentItemCategory = null;
           
           
            txtQOH = "";
            txtQuantity = "";
            onetxtItemName = "";
            isSaved = false;



       }

        public void ClearAddList()
        {
            PreviousPurchases.Clear();
            PreviousDiscounts.Clear();
            PreviousPurchases = new ObservableCollection<string>();
            PreviousPurchases.Add("N/A");
            cmbPrevPurchasePrice = PreviousPurchases.ToList<string>();
            PreviousDiscounts.Add("N/A");
            cmbPrevDiscounts = PreviousDiscounts.ToList<string>();
            currentItemID = -1;
            currentItemCategory = null;
            StoreID = -1;
            txtStoreName = "";
            txtQOH = "";
            txtQuantity = "";
            onetxtItemName = "";
            isSaved = false;

        }

        public void SetPurchases(int ItemID)
        {

            if ((currentItemID <= 0) && (StoreID <= 0)) return;

            


            List<string> prevPurchases = ItemsService.GeDispatchPurchases(currentItemID,StoreID);


            bool hasPurchaseValues = true;
            if (prevPurchases == null)
            {
                prevPurchases = new List<string>();
                prevPurchases.Add("N/A");
                hasPurchaseValues = false;


            }

            else
            {
                if (prevPurchases.Count <= 0)
                {
                    prevPurchases.Add("N/A");
                    hasPurchaseValues = false;

                }
            }

            PreviousPurchases.Clear();
            PreviousPurchases = new ObservableCollection<string>(prevPurchases);
            cmbPrevPurchasePrice = PreviousPurchases.ToList<string>();

            if (hasPurchaseValues)
            {
                int totalQOHtemp = -1;
                Decimal itemPriceTemp = -0;

                if (decimal.TryParse(prevPurchases[0] ?? "", out itemPriceTemp))
                {

                    SetDiscountsForItemPrice(ItemID,StoreID, itemPriceTemp, out totalQOHtemp);

                }
            }
            }

        




    public bool  SetDiscountsForItemPrice(int tempItemID,int argStoreIDVal, Decimal Itemprice,out int TotalQOH){
        TotalQOH = 0;
        List<string> prevDiscounts = ItemsService.GeDispatchDiscountsForDispatchPrice(tempItemID, argStoreIDVal, Itemprice);
        //    List<ItemsTrack> prevDiscountsList = registerDB.Where(x => x.ItemsCategoryID == tempItemID && x.ItemPrice == Itemprice).OrderBy(x => x.Discount).ToList();
            
            
            bool HasValues = true;


            if (prevDiscounts == null)
            {
                prevDiscounts = new List<string>();
                prevDiscounts.Add("N/A");
                HasValues = false;
                txtQOH = TotalQOH.ToString();
                
               

            }

            else
            {
                if (prevDiscounts.Count <= 0)
                {
                    prevDiscounts = new List<string>();
                    prevDiscounts.Add("N/A");
                    HasValues = false;
                    txtQOH = TotalQOH.ToString();

                }
            }

            PreviousDiscounts.Clear();
            PreviousDiscounts = new ObservableCollection<string>(prevDiscounts);
            cmbPrevDiscounts = PreviousDiscounts.ToList<string>();
            if (HasValues)
            {
                int tempID = tempItemID; Decimal TempPrice = Itemprice; Decimal QOHdiscount = -1;
                if (decimal.TryParse(prevDiscounts[0], out QOHdiscount))
                {
                    int tempQOH = QOHForAnItem(tempID, StoreID, TempPrice, QOHdiscount);
                    txtQOH = tempQOH.ToString();
                }
            }
            else
            {
                txtQOH = "N/A";

            }
            

            return true;


        }





   public  int QOHForAnItem(int tempItemID,int argStoreIDval, Decimal Itemprice, decimal tempDiscount)
        {

            int? prevDiscountsList = ItemsService.GetItemsDispatched(tempItemID, argStoreIDval, tempDiscount, Itemprice);

            if (prevDiscountsList ==null) { return -1; }
            if (prevDiscountsList <0 ) { return -1; }
                
            return prevDiscountsList??-1 ;

        }




        public void AddPurchaseItem(RoutedEventArgs e)
        {
            ItemCategory selectedItem = null;
            e.Handled = true;
            if (validateItem(out selectedItem))
            {
                if (ShowConfirmDialog(selectedItem) != null)
                {

                    listItems.Add(selectedItem);
                    ClearAddList();

                }

            }

        }

        private ItemCategory ShowConfirmDialog(ItemCategory itemValue)
        {
            int TempId = itemValue.ItemTypeId ?? currentItemID;

            var getItem = StoreItems.Where(x => x.ItemTypeId == TempId).FirstOrDefault();
            if (getItem == null)
            {
                MessageBox.Show("Not a ValidItem Selected, select the Item again", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                return null;

            }

            string confirmMessage = "The Item : " + getItem.ItemName + "\r\n" + " With Purchase Price : " + (itemValue.DefaultPrice ?? 0).ToString() + "\r\n and Quantity: " + ((Decimal)(itemValue.ROL ?? 0)).ToString() + " will be added to list ";
            if (MessageBoxResult.Cancel == MessageBox.Show(confirmMessage, "Confirm or Cancel to add the item to Purchase list", MessageBoxButton.OKCancel, MessageBoxImage.Question)) return null;
            itemValue.ItemName = getItem.ItemName;
            return itemValue;
        }

        private bool validateItem(out ItemCategory TempItem)
        {
            TempItem = new ItemCategory();
            StringBuilder str = new StringBuilder();
            try
            {




                if (currentItemID <= 0)
                {
                    str.Clear();
                    str.Append("No valid Item Selected to add");
                    throw new Exception();


                }



                if (onetxtItemName.Trim() == "")
                {


                    str.Clear();
                    str.Append("No valid Item Selected to add");
                    throw new Exception();
                }

                if (txtDispatchPrice.Trim() == "")
                {


                    str.Clear();
                    str.Append("Purchase price cannot be empty");
                    throw new Exception();
                }

                if (txtQuantity.Trim() == "")
                {


                    str.Clear();
                    str.Append("Quantity cannot be empty, Enter Quantity");
                    throw new Exception();
                }
                str.Append("Default Price should be a Money and Decimal value");
                NumberStyles style = NumberStyles.AllowDecimalPoint;
                Decimal DefaultPrice;

                // defaultprice is denoting purchase price here

                DefaultPrice = decimal.Parse(txtDispatchPrice.Trim(), style);

                if ((DefaultPrice <= 0))
                {

                    str.Clear();
                    str.Append("Dispatch price cannot be negative or zero");
                    throw new Exception();
                }

                if (DefaultPrice.ToString().Count(x => x == '.') > 1)
                {

                    str.Clear();
                    str.Append("Dispatch price cannot have more than two decimals points");
                    throw new Exception();

                }

                if ((DefaultPrice.ToString().Contains(".")) && ((DefaultPrice.ToString().Length - (DefaultPrice.ToString().IndexOf(".") + 1)) > 2))
                {


                    str.Clear();
                    str.Append("Purchase price is money, cannot have more than two digits after decimal");
                    throw new Exception();
                }






                str.Clear();
                str.Append("quantity is not valid number");

                // ROL denotes quantity
                int ROLForItem = int.Parse(txtQuantity.Trim());

                if ((ROLForItem <= 0))
                {

                    str.Clear();
                    str.Append("Quantity cannot be negative or zero and cannot have decimals");
                    throw new Exception();
                }

                /*
                if ((ROLForItem.ToString().Contains(".")) && ((ROLForItem.ToString().Length - (ROLForItem.ToString().IndexOf(".") + 1)) > 0))
                {


                    str.Clear();
                    str.Append("Purchase price cannot have more than two decimals");
                    throw new Exception();
                }

                */

                TempItem.DefaultPrice = (double)DefaultPrice;
                TempItem.ItemTypeId = currentItemID;
                TempItem.ItemName = onetxtItemName;
                TempItem.ROL = ROLForItem;

                return true;
            }

            catch (Exception ex)
            {
                MessageBox.Show(str.ToString(), "Error Saving Item record", MessageBoxButton.OK, MessageBoxImage.Error);


                return false;
            }

            //   return false;

        }


    }
}

