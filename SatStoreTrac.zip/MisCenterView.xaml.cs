﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Caliburn.Micro;
using Caliburn;
namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for MisCenterView.xaml
    /// </summary>
    public partial class MisCenterView : UserControl
    {
        public MisCenterView()
        {
            InitializeComponent();
        }

       

        private void UserControl_Loaded_1(object sender, RoutedEventArgs e)
        {
            Window temp = Window.GetWindow(this.Parent);
            temp.Height = 900;
            temp.Width = 1500;
            temp.ResizeMode = ResizeMode.NoResize;
            temp.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            temp.WindowStyle = WindowStyle.ToolWindow;
            temp.UseLayoutRounding = true;
            this.Width = 1500;
            this.Height = 950;
            this.MinHeight = 900;
            this.MinWidth = 1400;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((MisCenterViewModel)this.DataContext).Parent).ActivateItem(new DispatchesReportViewModel());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ((IConductor)((MisCenterViewModel)this.DataContext).Parent).ActivateItem(new PurchaseReturnsReportViewModel());
        }
    }
}
