﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using Caliburn.Micro;
using Caliburn;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for AddItemView.xaml
    /// </summary>
    public partial class AddItemView : UserControl
    {
        public AddItemView()
        {
            InitializeComponent();
           
         //   txtItemName.Text = (DateTime.Now.Ticks / 10000).ToString();
        }

        

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            Window temp = Window.GetWindow(this.Parent);
            temp.Height = 900;
            temp.Width = 1500;
            temp.ResizeMode = ResizeMode.NoResize;
            temp.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            temp.WindowStyle = WindowStyle.ToolWindow;
            temp.UseLayoutRounding = true;
            this.Width = 1500;
            this.Height = 900;
            this.MinHeight = 800;
            this.MinWidth = 1400;
            if ((System.Windows.SystemParameters.WorkArea.Width < 1500) || (System.Windows.SystemParameters.WorkArea.Height < 900))
            {
                screenHolder.Width = System.Windows.SystemParameters.WorkArea.Width;
                screenHolder.Height = System.Windows.SystemParameters.WorkArea.Height;

            }
            AddItemViewModel dataContext = (AddItemViewModel)this.DataContext;
           

            }

        private void listView1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if ((sender != null) && (sender is ListView))
            {
                ListView tempItemsList = (ListView)sender;

                ((AddItemViewModel)this.DataContext).ShowItemSelectedInList(tempItemsList);


           //     btnSaveORUpdate.Content = "Update item";


                //dataContext.ShowItemSelectedInList(TempItem );
            }
           
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            ((AddItemViewModel)this.DataContext).ClearForm();
         //   btnSaveORUpdate.Content = "Add New";
        
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)(((AddItemViewModel)this.DataContext).Parent)).ActivateItem(new FrontViewModel());
        }

        private void btndelete_Click(object sender, RoutedEventArgs e)
        {
            ((AddItemViewModel)this.DataContext).DeleteItem();
        }

        private void btnGetBox_Click(object sender, RoutedEventArgs e)
        {
            ((AddItemViewModel)this.DataContext).GetItemByID();
        }

       
        
    }
}
