﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using Caliburn.Micro;
using Caliburn;
using ActivityDB.EntityLayer;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for PurchaseTrackView.xaml
    /// </summary>
    public partial class PurchaseTrackView : UserControl
    {
        public PurchaseTrackView()
        {
            InitializeComponent();
        }


        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            Window temp = Window.GetWindow(this.Parent);
            temp.Height = 900;
            temp.Width = 1500;
            temp.ResizeMode = ResizeMode.NoResize;
            temp.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            temp.WindowStyle = WindowStyle.ToolWindow;
            temp.UseLayoutRounding = true;
            this.Width = 1500;
            this.Height = 900;
            this.MinHeight = 800;
            this.MinWidth = 1400;

            txtItemName.ItemsSource = ((PurchaseTrackViewModel)this.DataContext).StoreItems;

            txtItemName.FilterMode = AutoCompleteFilterMode.Custom;

            txtItemName.ItemFilter = (txt, i) => ItemCategoryAutoComplete.IsAutoCompleteSuggestion(txt, i);
            txtItemName.AddHandler(AutoCompleteBox.DropDownClosingEvent, new  RoutedEventHandler(txtItemName_DropDownClosed), false);
          //  txtItemName.AddHandler(AutoCompleteBox., new RoutedEventHandler(txtItemName_DropDownClosed), false);

        }

        

        private void txtItemName_DropDownClosed(object sender, RoutedEventArgs e)
        {
            e.Handled = true;
            
            if (txtItemName.Text.Trim() == "") { return; }
            if (sender is AutoCompleteBox)
            {

                if (txtItemName.SelectedItem == null) 
                {
                    

                    MessageBox.Show("No Item Starts with " +txtItemName.Text.Trim()+ "\r\n \r\n Please select a Valid Item", " Select a valid Item", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                    txtItemName.Text = "";
                }

                else
                {
                    txtItemName.Text = (((ItemCategory)txtItemName.SelectedItem).ItemName);
                    txtDefaultPrice.Text = (((ItemCategory)txtItemName.SelectedItem).DefaultPrice ?? 0).ToString();
                    int tempItemID=(((ItemCategory)txtItemName.SelectedItem).ItemTypeId ?? -1);;
                    ((PurchaseTrackViewModel)this.DataContext).currentItemID = tempItemID;
                    ((PurchaseTrackViewModel)this.DataContext).SetPurchases(tempItemID);
                }

            }
           
        }

        private void cmbPrevPurchasePrice_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try{
                ComboBox tempBox = sender as ComboBox;
                if (tempBox.SelectedItem != null)
                {
                    decimal tempVal;
                    if (decimal.TryParse(tempBox.SelectedValue.ToString(), out tempVal))
                    {
                        txtPurchasePrice.Text = tempVal.ToString();

                        if (((PurchaseTrackViewModel)this.DataContext).currentItemID > 0)
                        {
                            ((PurchaseTrackViewModel)this.DataContext).SetDiscounts(tempVal, ((PurchaseTrackViewModel)this.DataContext).currentItemID); 

                        }
                    
                    }

                }
            }
            catch (Exception ex){

            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)(((PurchaseTrackViewModel)this.DataContext).Parent)).ActivateItem(new FrontViewModel());
        }

        private void btnRemovefromList_Click(object sender, RoutedEventArgs e)
        {

            e.Handled = true;
            if (listView1.Items.Count <= 0) return;
           if (listView1.SelectedItem!= null)

           {
               if (listView1.SelectedIndex >= 0)
               {

                   ((PurchaseTrackViewModel)this.DataContext).listItems.RemoveAt(listView1.SelectedIndex);
               }
           }
           }

        private void cmbPrevDiscounts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                ComboBox tempBox = sender as ComboBox;
                if (tempBox.SelectedItem != null)
                {
                    decimal tempVal;
                    if (decimal.TryParse(tempBox.SelectedValue.ToString(), out tempVal))
                    {
                        txtDiscount.Text = tempVal.ToString();

                        

                    }

                }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnclear_Click(object sender, RoutedEventArgs e)
        {
            ((PurchaseTrackViewModel)this.DataContext).ClearForm();
        }

        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            ((PurchaseTrackViewModel)this.DataContext).PrintItem();

          
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
           
            

                if (((PurchaseTrackViewModel)this.DataContext).confirmOperation())
                {

                    ((PurchaseTrackViewModel)this.DataContext).CancelPurchaseTrack();

                }

            
        }

        private void btnGetPurchase_Click(object sender, RoutedEventArgs e)
        {
            ((PurchaseTrackViewModel)this.DataContext).LoadDispatch();
        }
    


    }
}
