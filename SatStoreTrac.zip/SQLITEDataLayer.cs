﻿namespace  ActivityDB.EntityLayer
{
 using FluentNHibernate;
using FluentNHibernate.Mapping;
using NHibernate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SQLite;
using System.Data;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using FluentNHibernate.Automapping;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using NHibernate.Criterion;
using NHibernate.Linq;
using System.IO;
using FluentNHibernate.Automapping.Alterations;
using SatStoreTrac;
using ActivityDB;
    using System.Windows.Controls;
   // using System.Drawing.Printing;
    using System.Windows.Documents;
    using System.Printing;
   
    using System.Windows.Media;
using System.Windows.Media.Imaging;
    using System.Globalization;
    using System.Windows;

    
    





    public class ItemKey
    {

        public int Itemtype { get; set; }
        public Decimal PurchasePrice { get; set; }
        public int StoreID { get; set; }

    }

    public class StoresService
    {
        public int QueryPageNo;
        public int QueryPageSize;
        public long CurrentCount;


        public static StoreData GetStore(int argStoreID)
        {

            try
            {
                using (IStatelessSession sessionObj = SecurityValuesForApp.AppDataFactory.OpenStatelessSession())
                {

                    return sessionObj.Get<StoreData>(argStoreID);
                }

            }
            catch (Exception ex)
            {

                throw ex;

            }


        }
        


        public static bool DeleteStore(int argStoreID)
        {

            try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenSession())
                {
                    var results = sessionobj.QueryOver<DispatchHistory>().Where(x => x.OutStoreID == argStoreID).Take(1).List();

                    bool continueDelete = false;
                    if (results == null) { continueDelete = true; }
                    else if (results.Count <= 0) { continueDelete = true; }

                    if (!continueDelete) { return false; }


                    StoreData tempItem = sessionobj.Get<StoreData>(argStoreID);
                    if (tempItem == null) { throw new Exception(); }

                    sessionobj.Delete(tempItem);
                    sessionobj.Flush();


                    return true;

                }
            }
            catch (Exception ex)
            {
                throw ex;

            }



        }



        public int CreateORUpdateStore(StoreData Item)
        {
            try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenSession())
                {

                    sessionobj.SaveOrUpdate(Item);
                    sessionobj.Flush();

                }

                return 0;




            }
            catch (DataException)
            {

                return -1;
            }
            catch (Exception)
            {

                return 1;
            }


        }


        public bool CheckCancel(int ID, string transactionType, out string argmesg)
        {

            try
            {
                argmesg = "";

                switch (transactionType)
                {

                    case "P": return CheckCanCancelPurchase(ID, out argmesg); break;

                    case "D": return CheckCanCancelDispatch(ID, out argmesg); break;
                    default: return false;

                }
            }
            catch (Exception ex)
            {

                throw ex;
            }


        }



        



        //mesg= "true" cancancel is true, if mesg = "false" cancancel is false otherwise other errors




        static bool  CheckCanCancelPurchase(int purchaseID, out string mesg)
        {
            StateOfOperation tempState = StateOfOperation.GeneralFailure;
            ITransaction currentTransaction = null;
            ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
            if (Temp == null) throw new DataException("Error connecting to DataBase");
            using (var sessionobj = Temp.OpenStatelessSession())
            {
                // currentTransaction = sessionobj.BeginTransaction(IsolationLevel.ReadCommitted);
                try
                {
                    var purchaseItemDB = sessionobj.Get<PurchasesTrack>((object)(purchaseID));
                    if (purchaseItemDB == null)
                    {
                        mesg = " No Dispatch  with this Item code";
                        return false;
                    }

                    var siItems = sessionobj.QueryOver<StoreItems>().Where(x => x.PurchaseID == purchaseItemDB.Id).List<StoreItems>();

                    if (siItems == null)
                    {
                        mesg = "Dispatch Item does not contain any Items";
                        return false;
                    }
                    if (siItems.Count <= 0)
                    {
                        mesg = "Dispatch Item does not contain any Items";
                        return false;
                    }

                    int[] ItemIdCollection = siItems.Select(x => x.ItemID ?? 0).ToArray<int>();

                    var DispatchHistoryItems = sessionobj.QueryOver<DispatchHistory>().Where(x => x.ItemId.IsIn(ItemIdCollection)).List<DispatchHistory>();

                    if (DispatchHistoryItems == null)
                    {
                        mesg = "True";
                        return true;


                    }
                    if (DispatchHistoryItems.Count <= 0)
                    {
                        mesg = "True";
                        return true;


                    }
                    mesg = "False";
                    return false;
                }
                catch (Exception ex)
                {
                    throw ex;

                }
            }
            mesg = "FALSE";
            return false;
        }










       static bool CheckCanCancelDispatch(int dispatchID, out string mesg)
        {
                StateOfOperation tempState = StateOfOperation.GeneralFailure; 
                ITransaction currentTransaction = null;
                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenStatelessSession())
                {
                   // currentTransaction = sessionobj.BeginTransaction(IsolationLevel.ReadCommitted);
                    try
                    {
                        var dispatchItemDB = sessionobj.Get<DispatchTrack>((object)(dispatchID));
                        if (dispatchItemDB == null)
                        {
                            mesg=" No Dispatch  with this Item code";
                            return false;
                        }

                        var dispatchHistoryItems = sessionobj.QueryOver<DispatchHistory>().Where(x => x.DispatchID == dispatchItemDB.Id).List<DispatchHistory>();

                        if (dispatchHistoryItems == null)
                        {
                            mesg = "Dispatch Item does not contain any Items";
                            return false;
                        }
                        if (dispatchHistoryItems.Count <= 0)
                        {
                            mesg = "Dispatch Item does not contain any Items";
                            return false;
                        }

                        int[] dhItemIdCollection = dispatchHistoryItems.Select(x => x.ID??0).ToArray<int>();

                        var purchaseReturns = sessionobj.QueryOver<PurchasesReturns>().Where(x => x.DispatchHistoryID.IsIn(dhItemIdCollection)).List<PurchasesReturns>();

                        if (purchaseReturns == null)
                        {
                            mesg = "True";
                            return true;


                        }
                        if (purchaseReturns.Count <= 0)
                        {
                            mesg = "True";
                            return true;


                        }
                        mesg = "False";
                        return false;
                    }
                    catch (Exception ex)
                    {
                        throw ex;

                    }
                }
                mesg = "FALSE";
            return false;
        }


        // Delete an Purchase Item by id and adjust registers and delete Items

        public static StateOfOperation DeletePurchaseTrack( PurchasesTrack purchaseItem)
        {
            StateOfOperation tempState = StateOfOperation.GeneralFailure;
            
            List<StoreItems> siCache = new List<StoreItems>();
            List<ItemsTrack> RegisterCache = new List<ItemsTrack>();
            string mshstr = "";
            try
            {

                if (!CheckCanCancelPurchase(purchaseItem.Id ?? -1, out mshstr)) { return StateOfOperation.CannotCancelPurchase; }
                ITransaction currentTransaction = null;
                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenSession())
                {
                    currentTransaction = sessionobj.BeginTransaction(IsolationLevel.ReadCommitted);
                    try
                    {
                        var purchaseItemDB = sessionobj.Get<PurchasesTrack>((object)(purchaseItem.Id ?? 0));
                        if (purchaseItemDB == null)
                        {
                            tempState = StateOfOperation.ItemNotFound;
                            throw new Exception();
                        }

                        var siItemsForDT = sessionobj.QueryOver<StoreItems>().Where(x => x.PurchaseID == purchaseItemDB.Id).List<StoreItems>();

                        if (siItemsForDT == null) { currentTransaction.Rollback(); return StateOfOperation.NotEnoughDispatchItems; }
                        if (siItemsForDT.Count <= 0) { currentTransaction.Rollback(); return StateOfOperation.NotEnoughDispatchItems; }
                        siCache = siItemsForDT.ToList<StoreItems>();

                        foreach (var SiItemInCache in siCache)
                        {
                            StoreItems currentItem = SiItemInCache; int qohAdj = SiItemInCache.QOH??0;







                            var tempRegisterIteminCache = RegisterCache.Where(x => ((x.ItemsCategoryID == currentItem.ItemTypeRef) && (x.ItemPrice == currentItem.PurchasePrice) && (x.Discount == currentItem.Discount) && (x.InStoreID == currentItem.InStoreID))).FirstOrDefault();


                            if (tempRegisterIteminCache == null)
                            {

                                var tempRegisterItem = sessionobj.QueryOver<ItemsTrack>().And(Restrictions.Eq("ItemsCategoryID", currentItem.ItemTypeRef)).And(Restrictions.Eq("ItemPrice", currentItem.PurchasePrice)).And(Restrictions.Eq("Discount", currentItem.Discount)).And(Restrictions.Eq("InStoreID", currentItem.InStoreID)).List<ItemsTrack>().FirstOrDefault();
                                tempRegisterItem.QOH -= qohAdj;
                                RegisterCache.Add(tempRegisterItem);

                            }

                            else
                            {

                                tempRegisterIteminCache.QOH -= qohAdj;

                            }

                        }



                       


                        
                        siCache.ForEach(x => { sessionobj.Delete(x); });
                        sessionobj.Delete(purchaseItemDB);
                        RegisterCache.ForEach(x => sessionobj.SaveOrUpdate(x));
                        currentTransaction.Commit();


                    }
                    


                    catch (Exception ex)
                    {
                        currentTransaction.Rollback();
                        throw ex;
                    }


                }
            }
            catch (Exception ex)
            {



                throw ex;
            }

            return StateOfOperation.Success;



        }













        // Delete an Dispatch Item by id and adjust registers and Items



        public static StateOfOperation DeleteDispatch(DispatchTrack dispatchItem)
        {
            StateOfOperation tempState = StateOfOperation.GeneralFailure;
            List<DispatchHistory> dhCache= new List<DispatchHistory>();
            List <StoreItems> siCache= new List<StoreItems>();
            List <ItemsTrack> RegisterCache= new List<ItemsTrack>();
            string mshstr = "";

            



            try{

                if (!CheckCanCancelDispatch(dispatchItem.Id??-1,out mshstr)){ return StateOfOperation.CannotCancelDispatch;}

                ITransaction currentTransaction = null;
              ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
            if (Temp == null) throw new DataException("Error connecting to DataBase");
            using (var sessionobj = Temp.OpenSession())
            {
                currentTransaction = sessionobj.BeginTransaction(IsolationLevel.ReadCommitted);
                try
                {
                    var dispatchItemDB=sessionobj.Get<DispatchTrack>( (object) (dispatchItem.Id??0));
                    if (dispatchItemDB==null){
                        tempState=StateOfOperation.ItemNotFound;
                        throw new Exception();}

                        var dhItemsForDT = sessionobj.QueryOver<DispatchHistory>().Where(x => x.DispatchID == dispatchItemDB.Id).List<DispatchHistory>();

                        if (dhItemsForDT == null) { currentTransaction.Rollback(); return StateOfOperation.NotEnoughDispatchItems; }
                        if (dhItemsForDT.Count <= 0) { currentTransaction.Rollback(); return StateOfOperation.NotEnoughDispatchItems; }
                        dhCache = dhItemsForDT.ToList<DispatchHistory>();

                        foreach (var dhitemInCache in dhCache)
                        {
                            var ItemInCache = siCache.Where(x => x.ItemID == dhitemInCache.ItemId).FirstOrDefault();
                            StoreItems currentItem = new StoreItems(); int qohAdj = 0;
                            if (ItemInCache == null)
                            {

                                var tempItem = sessionobj.QueryOver<StoreItems>().Where(x => x.ItemID == dhitemInCache.ItemId).List<StoreItems>().FirstOrDefault();

                                if (tempItem == null) { currentTransaction.Rollback(); return StateOfOperation.NotEnoughDispatchItems; }
                                qohAdj=dhitemInCache.initQuantity??0;
                                tempItem.QOH += qohAdj;
                                if ((tempItem.Quantity ?? 0) < (tempItem.QOH ?? 0)) { currentTransaction.Rollback(); return StateOfOperation.RegisterCorrupted; }


                                siCache.Add(tempItem);
                                currentItem = tempItem;

                            }

                            else
                            {
                                qohAdj = dhitemInCache.initQuantity ?? 0;
                                ItemInCache.QOH += qohAdj;
                                if ((ItemInCache.Quantity ?? 0) < (ItemInCache.QOH ?? 0)) { currentTransaction.Rollback(); return StateOfOperation.RegisterCorrupted; }

                                currentItem = ItemInCache;
                            }


                            

                            var tempRegisterIteminCache = RegisterCache.Where(x => ((x.ItemsCategoryID == currentItem.ItemTypeRef) && (x.ItemPrice == currentItem.PurchasePrice) && (x.Discount == currentItem.Discount) && (x.InStoreID == currentItem.InStoreID))).FirstOrDefault();


                            if (tempRegisterIteminCache == null) { 

                            var tempRegisterItem = sessionobj.QueryOver<ItemsTrack>().And(Restrictions.Eq("ItemsCategoryID", currentItem.ItemTypeRef)).And(Restrictions.Eq("ItemPrice", currentItem.PurchasePrice)).And(Restrictions.Eq("Discount", currentItem.Discount)).And(Restrictions.Eq("InStoreID", currentItem.InStoreID)).List<ItemsTrack>().FirstOrDefault();
                            tempRegisterItem.QOH += qohAdj;
                            RegisterCache.Add(tempRegisterItem);
                            
                            }

                        else{

                            tempRegisterIteminCache.QOH += qohAdj;

                        }
                              
                        }



                   


                        dhCache.ForEach(x => { sessionobj.Delete(x); });
                        siCache.ForEach(x => { sessionobj.SaveOrUpdate(x); });
                        sessionobj.Delete(dispatchItemDB);
                        RegisterCache.ForEach(x => sessionobj.SaveOrUpdate(x));
                        currentTransaction.Commit();


                    }
                 

                
                catch (Exception ex)
                {
                    currentTransaction.Rollback();
                    throw ex;
                }

            
            }
            }
            catch (Exception ex){
                
               
                
                throw ex;
            }

            return StateOfOperation.Success;



        }



        public List<StoreData> QueryStoresByName(string StoreName, int pageSize, int pageIndex)
        {

            try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenSession())
                {
                    if (StoreName != "")
                    {
                        var results = sessionobj.QueryOver<StoreData>().OrderBy(x=>x.StoreName).Asc.Where(x => x.StoreName.IsInsensitiveLike(StoreName,MatchMode.Start)).And(x=>x.StoreType=="D").Skip(pageIndex * pageSize).Take(pageSize).Future<StoreData>();

                        return results.ToList<StoreData>();
                    }
                    else
                    {
                        var results = sessionobj.QueryOver<StoreData>().OrderBy(x=>x.StoreName).Asc.And(x=>x.StoreType=="D").Skip(pageIndex * pageSize).Take(pageSize).Future<StoreData>();

                        return results.ToList<StoreData>();
                    }
                }
            }
            catch (Exception ex)
            {
                return null;

            }




        }
    }



    public class PurchaseReturnsReports
    {


        public static List<PurchaseReturnsReportDTO> QueryPRReport(int outstore, int item, int pagesize, int index,  DateTime fromdate, DateTime todate)
        {
            String PRQueryForStoreForItem = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName, sum(PR.Quantity) as ROL ,DH.DispatchPrice as DefaultPrice ,DH.Percenatge as Discount from DispatchHistory DH, ItemCategory IC,StoreItems SI, PurchasesReturns PR Where ( (PR.DispatchHistoryID=DH.ID) AND (DH.OutStoreID = :outstore) AND  ((PR.ReturnDate >= :stdate) and (PR.ReturnDate <= :enddate)) AND (PR.ItemID=SI.ItemID) AND (SI.ItemTypeRef=:itemtypeid) AND (SI.ItemTypeRef=IC.ItemTypeId)) GROUP By IC.ItemTypeId,DH.DispatchPrice,DH.Percenatge ORDER BY IC.ItemName,DH.DispatchPrice,DH.Percenatge";



            try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenStatelessSession())
                {

                    var hqlQuery = sessionobj.CreateQuery(PRQueryForStoreForItem); //.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                    int firstresult = 0;
                    if (index > 0) { firstresult = (pagesize * index) - 1; }

                    var results = hqlQuery.SetParameter("outstore", outstore).SetParameter("itemtypeid", item).SetParameter("stdate", todate).SetParameter("enddate", fromdate).SetFirstResult(firstresult).SetMaxResults(pagesize).SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(PurchaseReturnsReportDTO))).List<PurchaseReturnsReportDTO>();

                    if (results == null) { return new List<PurchaseReturnsReportDTO>(); }

                    return results.ToList<PurchaseReturnsReportDTO>();

                }
            }
            catch (Exception ex)
            {
                throw ex;

            }



        }

        public static List<PurchaseReturnsReportDTO> QueryPRReport(int item, int pagesize, int index, DateTime fromdate, DateTime todate)
        {
            String PRQueryAllStoresForItem = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName, sum(PR.Quantity) as ROL ,DH.DispatchPrice as DefaultPrice ,DH.Percenatge as Discount from DispatchHistory DH, ItemCategory IC,StoreItems SI, PurchasesReturns PR Where ( (PR.DispatchHistoryID=DH.ID)  AND  ((PR.ReturnDate >= :stdate) and (PR.ReturnDate <= :enddate)) AND (PR.ItemID=SI.ItemID) AND (SI.ItemTypeRef=:itemtypeid) AND (SI.ItemTypeRef=IC.ItemTypeId) ) GROUP By IC.ItemTypeId, DH.DispatchPrice,DH.Percenatge ORDER BY IC.ItemName, DH.DispatchPrice, DH.Percenatge";



            try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenStatelessSession())
                {

                    var hqlQuery = sessionobj.CreateQuery(PRQueryAllStoresForItem); //.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                    int firstresult = 0;
                    if (index > 0) { firstresult = (pagesize * index) - 1; }

                    var results = hqlQuery.SetParameter("itemtypeid", item).SetParameter("stdate", todate).SetParameter("enddate", fromdate).SetFirstResult(firstresult).SetMaxResults(pagesize).SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(PurchaseReturnsReportDTO))).List<PurchaseReturnsReportDTO>();

                    if (results == null) { return new List<PurchaseReturnsReportDTO>(); }

                    return results.ToList<PurchaseReturnsReportDTO>();

                }
            }
            catch (Exception ex)
            {
                throw ex;

            }




        }

        public static List<PurchaseReturnsReportDTO> QueryPRReport(bool isStore, int outstore, int pagesize, int index, DateTime fromdate, DateTime todate)
        {
            String PRQueryForStoreAllItems = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName, sum(PR.Quantity) as ROL ,DH.DispatchPrice as DefaultPrice ,DH.Percenatge as Discount from DispatchHistory DH, ItemCategory IC,StoreItems SI, PurchasesReturns PR Where ( (PR.DispatchHistoryID=DH.ID) AND (DH.OutStoreID = :outstore) AND  ((PR.ReturnDate >= :stdate) and (PR.ReturnDate <= :enddate)) AND (PR.ItemID=SI.ItemID) AND (SI.ItemTypeRef=IC.ItemTypeId) ) GROUP By IC.ItemTypeId, DH.DispatchPrice, DH.Percenatge ORDER BY IC.ItemName, DH.DispatchPrice, DH.Percenatge";





            try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenStatelessSession())
                {

                    var hqlQuery = sessionobj.CreateQuery(PRQueryForStoreAllItems); //.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                    int firstresult = 0;
                    if (index > 0) { firstresult = (pagesize * index) - 1; }

                    var results = hqlQuery.SetParameter("outstore", outstore).SetParameter("stdate", todate).SetParameter("enddate", fromdate).SetFirstResult(firstresult).SetMaxResults(pagesize).SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(PurchaseReturnsReportDTO))).List<PurchaseReturnsReportDTO>();

                    if (results == null) { return new List<PurchaseReturnsReportDTO>(); }

                    return results.ToList<PurchaseReturnsReportDTO>();

                }
            }
            catch (Exception ex)
            {
                throw ex;

            }




        }

        public static List<PurchaseReturnsReportDTO> QueryPRReport(int pagesize, int index, DateTime fromdate, DateTime todate)
        {
            String PRQUeryAllStoresAllItems = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName, sum(PR.Quantity) as ROL ,DH.DispatchPrice as DefaultPrice ,DH.Percenatge as Discount from DispatchHistory DH, ItemCategory IC,StoreItems SI, PurchasesReturns PR Where ( (PR.DispatchHistoryID=DH.ID)  AND  ((PR.ReturnDate >= :stdate) and (PR.ReturnDate <= :enddate)) AND (PR.ItemID=SI.ItemID) AND (SI.ItemTypeRef=IC.ItemTypeId) ) GROUP By IC.ItemTypeId, DH.DispatchPrice, DH.Percenatge ORDER BY IC.ItemName, DH.DispatchPrice, DH.Percenatge";



            try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenStatelessSession())
                {

                    var hqlQuery = sessionobj.CreateQuery(PRQUeryAllStoresAllItems); //.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                    int firstresult = 0;
                    if (index > 0) { firstresult = (pagesize * index) - 1; }

                    var results = hqlQuery.SetParameter("stdate", todate).SetParameter("enddate", fromdate).SetFirstResult(firstresult).SetMaxResults(pagesize).SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(PurchaseReturnsReportDTO))).List<PurchaseReturnsReportDTO>();

                    if (results == null) { return new List<PurchaseReturnsReportDTO>(); }

                    return results.ToList<PurchaseReturnsReportDTO>();

                }
            }
            catch (Exception ex)
            {
                throw ex;

            }



        }






    }



    public class PurchaseReportService{

         public static List<PurchaseReportDTO> QueryPurchaseHistoryReport( int item, int pagesize, int index,bool isorginal, DateTime fromdate, DateTime todate)
        {
            String PHReportQueryForItem = "Select IC.ItemTypeId as ItemTypeId, IC.ItemName as ItemName, sum(SI.QOH) as ROL, SI.PurchasePrice as DefaultPrice,SI.Discount as Discount from PurchasesTrack PT, StoreItems SI,ItemCategory IC Where ( (PT.Id=SI.PurchaseID) AND  ((PT.PurchasedDate >= :stdate) and  (PT.PurchasedDate <= :enddate)) AND (SI.ItemTypeRef=IC.ItemTypeId) AND (IC.ItemTypeId=:itemtypeid) ) GROUP By IC.ItemTypeId,SI.PurchasePrice,SI.Discount ORDER BY IC.ItemName,SI.PurchasePrice,SI.Discount ";
            String OrgPHReportQueryForItem = "Select IC.ItemTypeId as ItemTypeId, IC.ItemName as ItemName, sum(SI.Quantity) as ROL, SI.PurchasePrice as DefaultPrice,SI.Discount as Discount from PurchasesTrack PT, StoreItems SI,ItemCategory IC Where ( (PT.Id=SI.PurchaseID) AND  ((PT.PurchasedDate >= :stdate) and  (PT.PurchasedDate <= :enddate)) AND (SI.ItemTypeRef=IC.ItemTypeId) AND (IC.ItemTypeId=:itemtypeid) ) GROUP By IC.ItemTypeId,SI.PurchasePrice,SI.Discount ORDER BY IC.ItemName,SI.PurchasePrice,SI.Discount ";
            string qryString = (isorginal) ? OrgPHReportQueryForItem : PHReportQueryForItem;

            try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenStatelessSession())
                {

                    var hqlQuery = sessionobj.CreateQuery(qryString); //.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                    int firstresult = 0;
                    if (index > 0) { firstresult = (pagesize * index) - 1; }

                    var results = hqlQuery.SetParameter("stdate", todate).SetParameter("enddate", fromdate).SetFirstResult(firstresult).SetMaxResults(pagesize).SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(PurchaseReportDTO))).List<PurchaseReportDTO>();

                    if (results == null) { return new List<PurchaseReportDTO>(); }

                    return results.ToList<PurchaseReportDTO>();

                }
            }
            catch (Exception ex)
            {
                throw ex;

            }





            return new List<PurchaseReportDTO>();

        }

         public static List<PurchaseReportDTO> QueryPurchaseHistoryReport(int pagesize, int index, bool isorginal, DateTime fromdate, DateTime todate)
         {
             String PHReportQuery = "Select IC.ItemTypeId as ItemTypeId, IC.ItemName as ItemName, sum(SI.QOH) as ROL, SI.PurchasePrice as DefaultPrice,SI.Discount as Discount from PurchasesTrack PT, StoreItems SI,ItemCategory IC Where ( (PT.Id=SI.PurchaseID) AND (PT.Id=SI.PurchaseID) AND  ((PT.PurchasedDate >= :stdate) and  (PT.PurchasedDate <= :enddate)) AND (SI.ItemTypeRef=IC.ItemTypeId)) GROUP By IC.ItemTypeId,SI.PurchasePrice,SI.Discount ORDER BY IC.ItemName,SI.PurchasePrice,SI.Discount ";
             String OrgPHReportQuery = "Select IC.ItemTypeId as ItemTypeId, IC.ItemName as ItemName, sum(SI.Quantity) as ROL, SI.PurchasePrice as DefaultPrice,SI.Discount as Discount from PurchasesTrack PT, StoreItems SI,ItemCategory IC Where ( (PT.Id=SI.PurchaseID) AND (PT.Id=SI.PurchaseID) AND  ((PT.PurchasedDate >= :stdate) and  (PT.PurchasedDate <= :enddate)) AND (SI.ItemTypeRef=IC.ItemTypeId)) GROUP By IC.ItemTypeId,SI.PurchasePrice,SI.Discount ORDER BY IC.ItemName,SI.PurchasePrice,SI.Discount ";
             string qryString = (isorginal) ? OrgPHReportQuery : PHReportQuery;

             try
             {


                 ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                 if (Temp == null) throw new DataException("Error connecting to DataBase");
                 using (var sessionobj = Temp.OpenStatelessSession())
                 {

                     var hqlQuery = sessionobj.CreateQuery(qryString); //.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                     int firstresult = index*pagesize;
                     if (index > 0) { firstresult = (pagesize * index) - 1; }

                     var results = hqlQuery.SetParameter("stdate", todate).SetParameter("enddate", fromdate).SetFirstResult(firstresult).SetMaxResults(pagesize).SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(PurchaseReportDTO))).List<PurchaseReportDTO>();

                     if (results == null) { return new List<PurchaseReportDTO>(); }

                     return results.ToList<PurchaseReportDTO>();

                 }
             }
             catch (Exception ex)
             {
                 throw ex;

             }
             
             return new List<PurchaseReportDTO>();

         }
}

   

    public class DispatchReportsService
    {

        // index in functions refers current index 

        public static string hqlDateFormat = "yyyy-MM-dd HH:mm:ss";

        public static List<DispatchReportDTO> QueryDispatchHistoryReport(int outstore, int item, int pagesize, int index, bool isOrginal,DateTime fromdate, DateTime todate )
        {
            String DHReportQueryForStoreForItem = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName , sum(DH.quantity) as ROL , DH.DispatchPrice as DefaultPrice , DH.Percenatge as Discount from DispatchTrack DT, DispatchHistory DH, ItemCategory IC, StoreItems SI  Where ((DT.Id=DH.DispatchID) AND ( (DT.DispatchedDate >= :stdate) and (DT.DispatchedDate <= :enddate)) AND ( DH.OutStoreID = :outstore) AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=IC.ItemTypeId)  AND (IC.ItemTypeId=:itemtypeid)  ) GROUP By IC.ItemTypeId,DH.DispatchPrice,DH.Percenatge ORDER BY IC.ItemName,DH.DispatchPrice,DH.Percenatge";
            String OrgDHReportQueryForStoreForItem = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName , sum(DH.initQuantity) as ROL , DH.DispatchPrice as DefaultPrice , DH.Percenatge as Discount from DispatchTrack DT, DispatchHistory DH, ItemCategory IC, StoreItems SI Where ((DT.Id=DH.DispatchID) AND ( (DT.DispatchedDate >= :stdate) and (DT.DispatchedDate <= :enddate)) AND ( DH.OutStoreID = :outstore) AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=IC.ItemTypeId)  AND (IC.ItemTypeId=:itemtypeid)  ) GROUP By IC.ItemTypeId,DH.DispatchPrice,DH.Percenatge ORDER BY IC.ItemName,DH.DispatchPrice,DH.Percenatge";
            String qryString = "";
            qryString= (isOrginal?OrgDHReportQueryForStoreForItem:DHReportQueryForStoreForItem);




            try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenStatelessSession())
                {
                    
                        var hqlQuery = sessionobj.CreateQuery(qryString); //.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                            int firstresult=0;
                            if (index > 0) { firstresult = (pagesize * index) - 1; }
                        
                        var results = hqlQuery.SetParameter("outstore", outstore).SetParameter("itemtypeid", item).SetParameter("stdate", todate).SetParameter("enddate", fromdate).SetFirstResult(firstresult).SetMaxResults(pagesize).SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                          
                        if (results==null){ return new List<DispatchReportDTO>();}

                        return results.ToList<DispatchReportDTO>();
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }




            return new List<DispatchReportDTO>();

        }

        public static List<DispatchReportDTO> QueryDispatchHistoryReport(int item, int pagesize, int index, bool isOrginal, DateTime fromdate, DateTime todate)
        {
            String OrgDHReportQueryAllStoresForItem = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName , sum(DH.initQuantity) as ROL , DH.DispatchPrice as DefaultPrice , DH.Percenatge as Discount from DispatchTrack DT, DispatchHistory DH, ItemCategory IC, StoreItems SI Where ((DT.Id=DH.DispatchID) AND ( DT.DispatchedDate BETWEEN :stdate and :enddate)  AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=IC.ItemTypeId)  AND (IC.ItemTypeId=:itemtypeid)  ) GROUP By IC.ItemTypeId,DH.DispatchPrice,DH.Percenatge ORDER BY IC.ItemName,DH.DispatchPrice,DH.Percenatge";
            String DHReportQueryAllStoresForItem = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName , sum(DH.quantity) as ROL , DH.DispatchPrice as DefaultPrice , DH.Percenatge as Discount from DispatchTrack DT, DispatchHistory DH, ItemCategory IC, StoreItems SI Where ((DT.Id=DH.DispatchID) AND ( DT.DispatchedDate BETWEEN :stdate and :enddate)  AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=IC.ItemTypeId)  AND (IC.ItemTypeId=:itemtypeid)  ) GROUP By IC.ItemTypeId,DH.DispatchPrice,DH.Percenatge ORDER BY IC.ItemName,DH.DispatchPrice,DH.Percenatge";
            String qryString = "";
            qryString = (isOrginal ? OrgDHReportQueryAllStoresForItem : DHReportQueryAllStoresForItem);





             try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenStatelessSession())
                {
                    
                        var hqlQuery = sessionobj.CreateQuery(qryString); //.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                            int firstresult=0;
                            if (index > 0) { firstresult = (pagesize * index) - 1; }
                        
                        var results = hqlQuery.SetParameter("itemtypeid", item).SetParameter("stdate", todate).SetParameter("enddate", fromdate).SetFirstResult(firstresult).SetMaxResults(pagesize).SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                          
                        if (results==null){ return new List<DispatchReportDTO>();}

                        return results.ToList<DispatchReportDTO>();
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }




            return new List<DispatchReportDTO>();

        }






           

        public static List<DispatchReportDTO> QueryDispatchHistoryReport(bool isOrginal, int outstore, int pagesize, int index, DateTime fromdate, DateTime todate)
        {
            String DHReportQueryForStoreAllItems = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName , sum(DH.quantity) as ROL , DH.DispatchPrice as DefaultPrice , DH.Percenatge as Discount from DispatchTrack DT, DispatchHistory DH, ItemCategory IC, StoreItems SI Where ((DT.Id=DH.DispatchID) AND ( (DT.DispatchedDate >= :stdate) and (DT.DispatchedDate <= :enddate)) AND ( DH.OutStoreID = :outstore) AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=IC.ItemTypeId)) GROUP By IC.ItemTypeId,DH.DispatchPrice,DH.Percenatge ORDER BY IC.ItemName,DH.DispatchPrice,DH.Percenatge";
            String OrgDHReportQueryForStoreAllItems = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName , sum(DH.initQuantity) as ROL , DH.DispatchPrice as DefaultPrice , DH.Percenatge as Discount from DispatchTrack DT, DispatchHistory DH, ItemCategory IC, StoreItems SI Where ((DT.Id=DH.DispatchID) AND ( (DT.DispatchedDate >= :stdate) and (DT.DispatchedDate <= :enddate)) AND ( DH.OutStoreID = :outstore) AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=IC.ItemTypeId)) GROUP By IC.ItemTypeId,DH.DispatchPrice,DH.Percenatge ORDER BY IC.ItemName,DH.DispatchPrice,DH.Percenatge";
            String qryString = "";
            qryString = (isOrginal ? OrgDHReportQueryForStoreAllItems : DHReportQueryForStoreAllItems);


             try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenStatelessSession())
                {
                    
                        var hqlQuery = sessionobj.CreateQuery(qryString); //.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                            int firstresult=0;
                            if (index > 0) { firstresult = (pagesize * index) - 1; }
                        
                        var results = hqlQuery.SetParameter("outstore", outstore).SetParameter("stdate", todate).SetParameter("enddate", fromdate).SetFirstResult(firstresult).SetMaxResults(pagesize).SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                          
                        if (results==null){ return new List<DispatchReportDTO>();}

                        return results.ToList<DispatchReportDTO>();
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }




            return new List<DispatchReportDTO>();

        }








            

        public static List<DispatchReportDTO> QueryDispatchHistoryReport(int pagesize, int index, bool isOrginal, DateTime fromdate, DateTime todate)
        {
            String OrgDHReportQueryAllStoresAllItems = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName , sum(DH.initQuantity) as ROL , DH.DispatchPrice as DefaultPrice , DH.Percenatge as Discount from DispatchTrack DT, DispatchHistory DH, ItemCategory IC, StoreItems SI Where ((DT.Id=DH.DispatchID) AND ((DT.DispatchedDate >= :stdate) and (DT.DispatchedDate <= :enddate)) AND  (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=IC.ItemTypeId)) GROUP By IC.ItemTypeId,DH.DispatchPrice,DH.Percenatge ORDER BY IC.ItemName,DH.DispatchPrice,DH.Percenatge";
            String DHReportQueryAllStoresAllItems = "Select IC.ItemTypeId as ItemTypeId , IC.ItemName as ItemName , sum(DH.quantity) as ROL , DH.DispatchPrice as DefaultPrice , DH.Percenatge as Discount from DispatchTrack DT, DispatchHistory DH, ItemCategory IC, StoreItems SI Where ((DT.Id=DH.DispatchID) AND ( (DT.DispatchedDate >= :stdate) and (DT.DispatchedDate <= :enddate)) AND  (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=IC.ItemTypeId)) GROUP By IC.ItemTypeId,DH.DispatchPrice,DH.Percenatge ORDER BY IC.ItemName,DH.DispatchPrice,DH.Percenatge";
            String qryString = "";
            qryString = (isOrginal ? OrgDHReportQueryAllStoresAllItems : DHReportQueryAllStoresAllItems);




             try
            {


                ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                if (Temp == null) throw new DataException("Error connecting to DataBase");
                using (var sessionobj = Temp.OpenStatelessSession())
                {
                    
                        var hqlQuery = sessionobj.CreateQuery(qryString); //.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                            int firstresult=0;
                            if (index > 0) { firstresult = (pagesize * index) - 1; }
                        
                        var results = hqlQuery.SetParameter("stdate", todate).SetParameter("enddate", fromdate).SetFirstResult(firstresult).SetMaxResults(pagesize).SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchReportDTO))).List<DispatchReportDTO>();
                          
                        if (results==null){ return new List<DispatchReportDTO>();}

                        return results.ToList<DispatchReportDTO>();
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }




            return new List<DispatchReportDTO>();

        }











            


    }



        public class ItemCategoryService
        {
            public int QueryPageNo;
            public int QueryPageSize;


            public static ItemCategory GetItemCategory(int argItemCategoryID)
            {

                try
                {
                    using (IStatelessSession sessionObj = SecurityValuesForApp.AppDataFactory.OpenStatelessSession())
                    {

                        return sessionObj.Get<ItemCategory>(argItemCategoryID);
                    }

                }
                catch(Exception ex)
                {

                    throw ex;

                }


            }

            public static bool DeleteItemCategory(int argItemCategoryID)
            {

                try
                {


                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenSession())
                    {
                        var results = sessionobj.QueryOver<StoreItems>().Where(x => x.ItemTypeRef == argItemCategoryID).Take(1).List();

                        bool continueDelete = false;
                        if (results == null){ continueDelete = true;}
                        else if (results.Count <= 0) { continueDelete = true; }

                        if (!continueDelete) { return false; }


                       ItemCategory tempItem=  sessionobj.Get<ItemCategory>(argItemCategoryID);
                       if (tempItem == null) {throw new Exception();}

                       sessionobj.Delete(tempItem);
                       sessionobj.Flush();


                        return true;

                    }
                }
                catch (Exception ex)
                {
                    throw ex;

                }



            }

            public static List<ItemCategory> QueryItemCategory()
            {
                try
                {


                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenSession())
                    {
                            var results = sessionobj.QueryOver<ItemCategory>().OrderBy(x=>x.ItemName).Asc.Future<ItemCategory>();

                            return results.ToList<ItemCategory>();
                        
                    }
                }
                catch (Exception ex)
                {
                    return null;

                }

            }
        






            public int CreateORUpdateStore(ItemCategory Item)
            {
                try
                {


                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenSession())
                    {

                        sessionobj.SaveOrUpdate(Item);
                        sessionobj.Flush();


                    }

                    return 0;




                }
                catch (DataException)
                {

                    return -1;
                }
                catch (Exception)
                {

                    return 1;
                }


            }

            public List<ItemCategory> QueryItemCategoryByName(string ItemName, int pageSize, int pageIndex)
            {
                try
                {


                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenSession())
                    {
                        if (ItemName != "")
                        {
                            var results = sessionobj.QueryOver<ItemCategory>().OrderBy(x=>x.ItemName).Asc.Where(x => x.ItemName.IsInsensitiveLike(ItemName,MatchMode.Start)).Skip(pageIndex * pageSize).Take(pageSize).Future<ItemCategory>();

                            return results.ToList<ItemCategory>();
                        }
                        else
                        {

                            var results = sessionobj.QueryOver<ItemCategory>().OrderBy(x=>x.ItemName).Asc.Skip(pageIndex * pageSize).Take(pageSize).Future<ItemCategory>();

                            return results.ToList<ItemCategory>();

                        }
                    }
                }
                catch (Exception ex)
                {
                    return null;

                }

            }
        }


        public static class PrinterService
        {

            static double PrinterWidth;

          public  static List<DispatchItemsWithItemName> TempDispatchSeed()
            {

                List<DispatchItemsWithItemName> tmp = new List<DispatchItemsWithItemName>();

                tmp.Add(new DispatchItemsWithItemName() { DispatchPrice = 12, ItemName="first",Percenatge=5, QOH=10 });
                tmp.Add(new DispatchItemsWithItemName() { DispatchPrice = 30, ItemName = "Second", Percenatge = 6, QOH = 11 });
                tmp.Add(new DispatchItemsWithItemName() { DispatchPrice = 40, ItemName = "Second", Percenatge = 7, QOH = 12 });
                return tmp;

            }

          public  static void PrintDispatch(List<DispatchItemsWithItemName> listofItems, int argItemID)
            {
               
                PrintDialog STPrinter = new PrintDialog();
               
                if (STPrinter.ShowDialog() != true) return;
              

               


            }

          static int pagecount = 0;

           public static List<DispatchItemsWithItemName> itemsToPrint;











           public static void MakePrintDispatch(List<ItemCategoryWithDiscount> listofItems, StoreData argStoreData, DispatchTrack argPurchaseTrack)
           {

               try
               {


                   DrawingVisual visual = new DrawingVisual();
                   // Get the drawing context.
                   System.Windows.Controls.PrintDialog printDialog = new System.Windows.Controls.PrintDialog();
                   List<string> headers = ItemsService.GetPrintHeader().OrderBy(x => x.lineNo).Select(x => x.line).ToList<string>();

                   if (printDialog.ShowDialog() != true) return;
                   printDialog.PrintTicket.PageResolution = new PageResolution(96, 96);
                   printDialog.PrintTicket.PageMediaType = PageMediaType.Label;
                   printDialog.PrintTicket.PageMediaSize = new PageMediaSize(96 * 3, 20000);

                   using (DrawingContext dc = visual.RenderOpen())
                   {
                       double StartX = 1;
                       double StartY = 10;
                       double offset = 5;
                       double fontHeight = 0;
                       double printWidth = 3 * 96;
                       foreach (var str1 in headers)
                       {



                           // Define the text you want to print.
                           FormattedText text = new FormattedText(str1,
                           CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                           new Typeface("Courier New"), 8, Brushes.Black);
                           // You must pick a maximum width to use text wrapping.
                           text.MaxTextWidth = printWidth - 10;
                           // Get the size required for the text.

                           Size textSize = new Size(text.Width, text.Height);
                           double Xoffset = 0;
                           // Find the top-left corner where you want to place the text.
                           double margin = 0;

                           StartX = (printWidth - text.Width) / 2;
                           Point point = new Point(StartX + Xoffset, StartY);
                           // Draw the content.
                           dc.DrawText(text, point);
                           StartY += offset + text.Height;
                       }


                       FormattedText textPurchasehdr = new FormattedText("Dispatch Invoice",
                          CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                          new Typeface("Courier New"), 15, Brushes.Black);
                       // You must pick a maximum width to use text wrapping.
                       textPurchasehdr.MaxTextWidth = printWidth - 10;
                       // Get the size required for the text.

                       Size textPurchasehdrSize = new Size(textPurchasehdr.Width, textPurchasehdr.Height);


                       StartX = (printWidth - textPurchasehdr.Width) / 2;
                       StartY += offset + 5;
                       Point pointhdr = new Point(StartX, StartY);
                       // Draw the content.
                       dc.DrawText(textPurchasehdr, pointhdr);


                       StartY += textPurchasehdr.Height;



                       FormattedText textPurchaseID = new FormattedText("ID: " + (argPurchaseTrack.Id ?? 0).ToString() + " Invoice Date: " + (argPurchaseTrack.DispatchedDate ?? DateTime.Now).ToLongDateString(),
                          CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                          new Typeface("Courier New"), 8, Brushes.Black);
                       // You must pick a maximum width to use text wrapping.
                       textPurchaseID.MaxTextWidth = printWidth - 10;
                       // Get the size required for the text.

                       Size textPurchaseIDSize = new Size(textPurchasehdr.Width, textPurchasehdr.Height);


                       StartX = 5;
                       StartY += offset + 5;
                       Point pointID = new Point(StartX, StartY);
                       // Draw the content.
                       dc.DrawText(textPurchasehdr, pointhdr);


                       StartY += textPurchaseID.Height;
                       dc.DrawText(textPurchaseID, pointID);

                       dc.DrawLine(new Pen(Brushes.Black, 1), new Point(0, StartY + 30), new Point(printWidth - 1, StartY + 30));



                       int i = 1;
                       StartX = 0;
                       StartY += 40;
                       double pointsize = (4d / 3d) * 5.5d;
                       String Header = "SNo".PadRight(4) + "Item/ID".PadRight(10) + "Price".PadRight(8) + "Discount".PadRight(9) + "Qty".PadRight(6) + "Total.Amt.".PadRight(10) + "Disc. Amt.".PadRight(10);

                       FormattedText Headertext1 = new FormattedText(Header,
                          CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                          new Typeface("Courier New"), pointsize, Brushes.Black);
                       FormattedText Headertext = new FormattedText(Header,
                          CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                          new Typeface("Courier New"), 8.1, Brushes.Black);

                       // You must pick a maximum width to use text wrapping.
                       Headertext.MaxTextWidth = printWidth - 10;
                       // Get the size required for the text.

                       Size textSizetmp = new Size(Headertext.Width, Headertext.Height);
                       double Xoffset1 = 1;
                       // Find the top-left corner where you want to place the text.
                       //   double margin = 0;


                       Point pointtmp = new Point(StartX + Xoffset1, StartY);
                       // Draw the content.
                       dc.DrawText(Headertext, pointtmp);

                       decimal runningTotalAmt = 0, runningTotalAmtDisc = 0;
                       StartY += Headertext.Height + 5;
                       foreach (var tempItem in listofItems)
                       {


                           decimal TotalAmt = (decimal)((tempItem.ROL ?? 0) * (tempItem.DefaultPrice ?? 0));
                           decimal TotalAmtDiscount = (TotalAmt * (1 - (((decimal)(tempItem.Discount ?? 0)) / 100)));
                           runningTotalAmt += TotalAmt;
                           runningTotalAmtDisc += TotalAmtDiscount;

                           String HeaderLine = " ".PadRight(4) + tempItem.ItemTypeId.ToString().PadRight(10) + tempItem.DefaultPrice.ToString().PadRight(8) + tempItem.Discount.ToString().PadRight(9) + tempItem.ROL.ToString().PadRight(6) + TotalAmt.ToString().PadRight(10) + TotalAmtDiscount.ToString().PadRight(10);

                           FormattedText HeadertextName = new FormattedText(i.ToString().PadRight(4) + tempItem.ItemName,
                              CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                              new Typeface("Courier New"), 8.1, Brushes.Black);
                           FormattedText HeadertextLine = new FormattedText(HeaderLine,
                              CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                              new Typeface("Courier New"), 8.1, Brushes.Black);

                           // You must pick a maximum width to use text wrapping.
                           HeadertextName.MaxTextWidth = printWidth - 10;
                           // Get the size required for the text.

                           Size textSizetmp1 = new Size(HeadertextName.Width, HeadertextName.Height);
                           double Xoffsettmp = 5;
                           // Find the top-left corner where you want to place the text.
                           //   double margin = 0;


                           Point pointtmp1 = new Point(StartX + Xoffsettmp, StartY);
                           // Draw the content.
                           dc.DrawText(HeadertextName, pointtmp1);

                           StartY += offset + HeadertextName.Height;
                           Point pointtmp2 = new Point(StartX + Xoffsettmp, StartY);
                           dc.DrawText(HeadertextLine, pointtmp2);

                           StartY += HeadertextLine.Height + 5;
                           i++;

                       }
                       dc.DrawLine(new Pen(Brushes.Black, 1), new Point(0, StartY + 5), new Point(printWidth - 1, StartY + 5));

                       String BottomLine = "Total " + runningTotalAmt.ToString() + " Total with Disc. " + runningTotalAmtDisc.ToString();

                       FormattedText BottomLinetext = new FormattedText(BottomLine,
                             CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                             new Typeface("Courier New"), 10, Brushes.Black);

                       Point pointbottom = new Point(StartX, StartY + 10);
                       dc.DrawText(BottomLinetext, pointbottom);



                   }
                   printDialog.PrintVisual(visual, "Test");
               }
               catch (Exception ex)
               {
                   throw ex;
               }
           }














           public static void MakePrintPurchase(List<ItemCategoryWithDiscount> listofItems, StoreData argStoreData, PurchasesTrack argPurchaseTrack)
           {

               try
               {

                   
                   DrawingVisual visual = new DrawingVisual();
                   // Get the drawing context.
                   System.Windows.Controls.PrintDialog printDialog = new System.Windows.Controls.PrintDialog();
                   List<string> headers = ItemsService.GetPrintHeader().OrderBy(x => x.lineNo).Select(x => x.line).ToList<string>();

                   if (printDialog.ShowDialog() != true) return;
                   printDialog.PrintTicket.PageResolution = new PageResolution(96, 96);
                   printDialog.PrintTicket.PageMediaType = PageMediaType.Label;
                   printDialog.PrintTicket.PageMediaSize = new PageMediaSize(96 * 3, 20000);

                   using (DrawingContext dc = visual.RenderOpen())
                   {
                       double StartX = 1;
                       double StartY = 10;
                       double offset = 5;
                       double fontHeight = 0;
                       double printWidth = 3 * 96;
                       foreach (var str1 in headers)
                       {



                           // Define the text you want to print.
                           FormattedText text = new FormattedText(str1,
                           CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                           new Typeface("Courier New"), 8, Brushes.Black);
                           // You must pick a maximum width to use text wrapping.
                           text.MaxTextWidth = printWidth - 10;
                           // Get the size required for the text.

                           Size textSize = new Size(text.Width, text.Height);
                           double Xoffset = 0;
                           // Find the top-left corner where you want to place the text.
                           double margin = 0;

                           StartX = (printWidth - text.Width) / 2;
                           Point point = new Point(StartX + Xoffset, StartY);
                           // Draw the content.
                           dc.DrawText(text, point);
                           StartY += offset + text.Height;
                       }


                       FormattedText textPurchasehdr = new FormattedText("Purchase Invoice",
                          CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                          new Typeface("Courier New"), 15, Brushes.Black);
                       // You must pick a maximum width to use text wrapping.
                       textPurchasehdr.MaxTextWidth = printWidth - 10;
                       // Get the size required for the text.

                       Size textPurchasehdrSize = new Size(textPurchasehdr.Width, textPurchasehdr.Height);


                       StartX = (printWidth - textPurchasehdr.Width) / 2;
                       StartY += offset + 5;
                       Point pointhdr = new Point(StartX , StartY);
                       // Draw the content.
                       dc.DrawText(textPurchasehdr, pointhdr);


                       StartY += textPurchasehdr.Height;



                       FormattedText textPurchaseID = new FormattedText("ID: " + (argPurchaseTrack.Id??0).ToString() + " Invoice Date: " + (argPurchaseTrack.PurchasedDate??DateTime.Now).ToLongDateString()  ,
                          CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                          new Typeface("Courier New"), 8, Brushes.Black);
                       // You must pick a maximum width to use text wrapping.
                       textPurchaseID.MaxTextWidth = printWidth - 10;
                       // Get the size required for the text.

                       Size textPurchaseIDSize = new Size(textPurchasehdr.Width, textPurchasehdr.Height);


                       StartX = 5;
                       StartY += offset + 5;
                       Point pointID = new Point(StartX, StartY);
                       // Draw the content.
                       dc.DrawText(textPurchasehdr, pointhdr);


                       StartY += textPurchaseID.Height;
                       dc.DrawText(textPurchaseID, pointID);

                       dc.DrawLine(new Pen(Brushes.Black, 1), new Point(0, StartY + 30), new Point( printWidth - 1, StartY + 30));



                       int i = 1;
                       StartX = 0;
                       StartY += 40;
                       double pointsize = (4d / 3d) * 5.5d;
                       String Header = "SNo".PadRight(4) + "Item/ID".PadRight(10) + "Price".PadRight(8) + "Discount".PadRight(9) + "Qty".PadRight(6) + "Total.Amt.".PadRight(10) + "Disc. Amt.".PadRight(10);

                       FormattedText Headertext1 = new FormattedText(Header,
                          CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                          new Typeface("Courier New"), pointsize, Brushes.Black);
                       FormattedText Headertext = new FormattedText(Header,
                          CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                          new Typeface("Courier New"), 8.1, Brushes.Black);

                       // You must pick a maximum width to use text wrapping.
                       Headertext.MaxTextWidth = printWidth - 10;
                       // Get the size required for the text.

                       Size textSizetmp = new Size(Headertext.Width, Headertext.Height);
                       double Xoffset1 = 1;
                       // Find the top-left corner where you want to place the text.
                       //   double margin = 0;


                       Point pointtmp = new Point(StartX + Xoffset1, StartY);
                       // Draw the content.
                       dc.DrawText(Headertext, pointtmp);

                       decimal runningTotalAmt = 0, runningTotalAmtDisc = 0;
                       StartY += Headertext.Height + 5;
                       foreach (var tempItem in listofItems)
                       {


                           decimal TotalAmt =(decimal)( (tempItem.ROL?? 0) * (tempItem.DefaultPrice ?? 0));
                           decimal TotalAmtDiscount = (TotalAmt * (1 - (((decimal)(tempItem.Discount ?? 0)) / 100)));
                           runningTotalAmt += TotalAmt;
                           runningTotalAmtDisc += TotalAmtDiscount;

                           String HeaderLine =  " ".PadRight(4) + tempItem.ItemTypeId.ToString().PadRight(10) + tempItem.DefaultPrice.ToString().PadRight(8) + tempItem.Discount.ToString().PadRight(9) + tempItem.ROL.ToString().PadRight(6) + TotalAmt.ToString().PadRight(10) + TotalAmtDiscount.ToString().PadRight(10);

                           FormattedText HeadertextName = new FormattedText(i.ToString().PadRight(4) + tempItem.ItemName,
                              CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                              new Typeface("Courier New"), 8.1, Brushes.Black);
                           FormattedText HeadertextLine = new FormattedText(HeaderLine,
                              CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                              new Typeface("Courier New"), 8.1, Brushes.Black);

                           // You must pick a maximum width to use text wrapping.
                           HeadertextName.MaxTextWidth = printWidth - 10;
                           // Get the size required for the text.

                           Size textSizetmp1 = new Size(HeadertextName.Width, HeadertextName.Height);
                           double Xoffsettmp = 5;
                           // Find the top-left corner where you want to place the text.
                           //   double margin = 0;


                           Point pointtmp1 = new Point(StartX + Xoffsettmp, StartY);
                           // Draw the content.
                           dc.DrawText(HeadertextName, pointtmp1);

                           StartY += offset + HeadertextName.Height;
                           Point pointtmp2 = new Point(StartX + Xoffsettmp, StartY);
                           dc.DrawText(HeadertextLine, pointtmp2);

                           StartY += HeadertextLine.Height + 5;
                           i++;

                       }
                       dc.DrawLine(new Pen(Brushes.Black, 1), new Point(0, StartY + 5), new Point(printWidth - 1, StartY + 5));

                       String BottomLine =   "Total " + runningTotalAmt.ToString() + " Total with Disc. " + runningTotalAmtDisc.ToString();

                       FormattedText BottomLinetext = new FormattedText(BottomLine,
                             CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                             new Typeface("Courier New"), 10, Brushes.Black);

                       Point pointbottom = new Point(StartX , StartY+10);
                       dc.DrawText(BottomLinetext, pointbottom);



                   }
                   printDialog.PrintVisual(visual, "Test");
               }
               catch (Exception ex)
               {
                   throw ex;
               }
           }






           public static void MakePrint(List<DispatchItemsWithItemName> listofItems, int argItemID)
           {

               try
               {

                   listofItems = TempDispatchSeed();
                   DrawingVisual visual = new DrawingVisual();
                   // Get the drawing context.
                   System.Windows.Controls.PrintDialog printDialog = new System.Windows.Controls.PrintDialog();
                   List<string> headers = ItemsService.GetPrintHeader().OrderBy(x => x.lineNo).Select(x => x.line).ToList<string>();

                   if (printDialog.ShowDialog() != true) return;
                   printDialog.PrintTicket.PageResolution = new PageResolution(96, 96);
                   printDialog.PrintTicket.PageMediaType = PageMediaType.Label;
                   printDialog.PrintTicket.PageMediaSize = new PageMediaSize(96 * 3, 20000);

                   using (DrawingContext dc = visual.RenderOpen())
                   {
                       double StartX = 1;
                       double StartY = 10;
                       double offset = 5;
                       double fontHeight = 0;
                       double printWidth = 3 * 96;
                       foreach (var str1 in headers)
                       {



                           // Define the text you want to print.
                           FormattedText text = new FormattedText(str1,
                           CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                           new Typeface("Courier New"), 20, Brushes.Black);
                           // You must pick a maximum width to use text wrapping.
                           text.MaxTextWidth = printWidth - 10;
                           // Get the size required for the text.

                           Size textSize = new Size(text.Width, text.Height);
                           double Xoffset = 10;
                           // Find the top-left corner where you want to place the text.
                           double margin = 0;
                           

                           Point point = new Point(StartX + Xoffset, StartY);
                           // Draw the content.
                           dc.DrawText(text, point);
                           StartY += offset + text.Height;
                       }

                       dc.DrawLine(new Pen(Brushes.Black, 1), new Point(0, StartY + 30), new Point(StartX + printWidth - 2, StartY + 30));



                       int i = 1;

                       StartY += 40;
                       double pointsize = (4d  / 3d) * 5.5d;
                       String Header = "SNo".PadRight(4) + "Item/ID".PadRight(10) + "Price".PadRight(8) + "Discount".PadRight(9) + "Qty".PadRight(6) + "Total.Amt.".PadRight(10) + "Disc. Amt.".PadRight(10);

                       FormattedText Headertext1 = new FormattedText(Header,
                          CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                          new Typeface("Courier New"), pointsize, Brushes.Black);
                       FormattedText Headertext = new FormattedText(Header,
                          CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                          new Typeface("Courier New"), 8.1, Brushes.Black);

                       // You must pick a maximum width to use text wrapping.
                       Headertext.MaxTextWidth = printWidth - 10;
                       // Get the size required for the text.

                       Size textSizetmp = new Size(Headertext.Width, Headertext.Height);
                       double Xoffset1 = 0;
                       // Find the top-left corner where you want to place the text.
                       //   double margin = 0;


                       Point pointtmp = new Point(StartX + Xoffset1, StartY);
                       // Draw the content.
                       dc.DrawText(Headertext, pointtmp);

                       decimal runningTotalAmt = 0, runningTotalAmtDisc = 0;
                       StartY += Headertext.Height+ 5;
                       foreach (var tempItem in listofItems)
                       {
                           

                           decimal TotalAmt = (tempItem.QOH ?? 0 * tempItem.ItemPrice ?? 0);
                           decimal TotalAmtDiscount =  (TotalAmt * (1 - (tempItem.Percenatge ?? 0 / 100)));
                           runningTotalAmt += TotalAmt;
                           runningTotalAmtDisc += TotalAmtDiscount;

                           String HeaderLine = i.ToString().PadRight(4) + tempItem.ItemCategoryID.ToString().PadRight(10) + tempItem.ItemPrice.ToString().PadRight(8) + tempItem.Percenatge.ToString().PadRight(9) + tempItem.QOH.ToString().PadRight(6) + TotalAmt.ToString().PadRight(10) + TotalAmtDiscount.ToString().PadRight(10);

                           FormattedText HeadertextName = new FormattedText(tempItem.ItemName,
                              CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                              new Typeface("Courier New"), 8.1, Brushes.Black);
                           FormattedText HeadertextLine = new FormattedText(HeaderLine,
                              CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
                              new Typeface("Courier New"), 8.1, Brushes.Black);

                           // You must pick a maximum width to use text wrapping.
                           HeadertextName.MaxTextWidth = printWidth - 10;
                           // Get the size required for the text.

                           Size textSizetmp1 = new Size(Headertext.Width, Headertext.Height);
                           double Xoffsettmp = 5;
                           // Find the top-left corner where you want to place the text.
                           //   double margin = 0;


                           Point pointtmp1 = new Point(StartX + Xoffsettmp, StartY);
                           // Draw the content.
                           dc.DrawText(HeadertextName, pointtmp1);
                           
                           StartY += offset + HeadertextName.Height;
                           Point pointtmp2 = new Point(StartX + Xoffsettmp, StartY);
                           dc.DrawText(HeadertextLine, pointtmp2);

                           StartY += HeadertextLine.Height + 5;
                           i++;

                       }
                   }
                   printDialog.PrintVisual(visual, "Test");
               }
               catch (Exception ex)
               {
                   throw ex;
               }
           }





}

        public class ItemsService
        {



            

            

            #region storemanager-configure-print-header
            public static List<StorePrintHeader> GetPrintHeader()
            {
                try
                {


                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenStatelessSession())
                    {
                        var tempobj = sessionobj.QueryOver<StorePrintHeader>().UnderlyingCriteria.AddOrder(new Order("lineNo", true)).List<StorePrintHeader>();
                        if (tempobj == null) return null;
                        return tempobj.ToList<StorePrintHeader>();
                    }

                }
                catch (Exception ex)
                {

                    return null;
                }


            }

            public static bool SavePrintHeader(List<string> Items)
            {
                ITransaction tempTransaction = null;
                try
                {


                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenSession())
                    {
                        tempTransaction = sessionobj.BeginTransaction();

                        var tempobj = sessionobj.CreateQuery("delete from StorePrintHeader").ExecuteUpdate();
                        tempTransaction.Commit();
                        tempTransaction = sessionobj.BeginTransaction();
                        int i = 1;
                        Items.ForEach((x) => { sessionobj.SaveOrUpdate(new StorePrintHeader() { line = x.ToString(), lineNo = i }); i++; });



                        tempTransaction.Commit();

                        return true;
                    }

                }
                catch (Exception ex)
                {
                    if (tempTransaction != null) tempTransaction.Rollback();

                    return false;
                }


            } 

            #endregion




            public static bool UpdateUserPin(string argPwd, string userType){
                ITransaction TempTransaction = null;
                try
                {

                    
                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenSession())
                    {
                        TempTransaction = sessionobj.BeginTransaction();
                        var tempobj = sessionobj.QueryOver<PinData>().List<PinData>();


                        foreach (var tempUser in tempobj)
                        {

                            if (tempUser.UserType.ToUpper() == userType.ToUpper())
                            {

                                tempUser.UserString = argPwd;
                                sessionobj.SaveOrUpdate(tempUser);
                                break;
                            }

                        }


                       
                        TempTransaction.Commit();
                        return true;
                    }

                }
                catch (Exception ex)
                {
                    if (TempTransaction != null) TempTransaction.Rollback();
                    return false;
                }



            }

            public static List<PinData> GetUserData()
            {
                try
                {


                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenStatelessSession())
                    {
                       var tempobj=sessionobj.QueryOver<PinData>().List<PinData>();
                       return tempobj.ToList<PinData>();
                    }

                }catch (Exception ex){

                    return null;
                }


            }
            
            
            //  Add code purchaseTrack View Model
            // used in purchase returns




            public static List<String> GeDispatchPurchases(int argItemID, int argStoreID)
            {

                List<string> returnPurchasePrices = new List<string>();
                try
                {


                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenStatelessSession())
                    {




                      //  string orderStr = (UseLatestDispatch) ? " ASC " : "DESC ";
                     //   string HqlQuery = @"select DH from DispatchHistory DH, StoreItems SI, DispatchTrack DT where " + " ((DH.DispatchID=DT.Id) AND (DH.quantity>0) AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=" + argItemID.ToString().Trim() + ") AND " + "(DH.Percenatge=" + percentageGiven.ToString().Trim() + ") " + ")" 

                        string HqlQuery = @"select distinct DH.DispatchPrice  from DispatchHistory DH , StoreItems  SI, DispatchTrack  DT where " + " ((DH.DispatchID=DT.Id) AND (DH.quantity>0) AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=" + argItemID.ToString().Trim() + ") AND (DH.quantity>0) AND (DH.OutStoreID=" + argStoreID.ToString() + ")) Order By DH.DispatchPrice ASC"; 
                        IQuery query = sessionobj.CreateQuery(HqlQuery);
                        var dispatchData = query.List();
                        




                     //   var returnTempPurchasePrices = sessionobj.QueryOver<DispatchHistory>().And(Restrictions.Eq("ItemId", argItemID)).And(Restrictions.Eq("OutStoreID", argStoreID)).Future<DispatchHistory>().GroupBy(x => x.DispatchPrice).Select(x => x.Key).OrderBy(x => x).Cast<String>().ToList();

                        if (dispatchData == null) return null;

                        if (dispatchData.Count <= 0) return null;

                       List<string> PurchasePrices= new List<string>();


                       


                      foreach(var tempitem in dispatchData)
                       {

                          PurchasePrices.Add(tempitem.ToString());



                       }


                      return PurchasePrices;
                    }

                }
                catch (Exception ex)
                {


                    throw ex;
                }


               

            }



            public static int GetItemsDispatched(int itemCategoryID, int outStoreID, decimal percentageGiven, decimal PurchasePrice)
            {
                try
                {
                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    ISession ongoingSession = Temp.OpenSession();
                    //ITransaction ongoingTransaction = ongoingSession.BeginTransaction();

                    string HqlQuery = @"select sum(DH.quantity) from DispatchHistory DH, StoreItems SI, DispatchTrack DT where " + " ((DH.DispatchID=DT.Id) AND (DH.quantity>0) AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=" + itemCategoryID.ToString().Trim() + ") AND " + "(DH.Percenatge=" + percentageGiven.ToString().Trim() + ") AND " + "(DH.DispatchPrice=" + PurchasePrice.ToString().Trim() + ")  AND (DH.OutStoreID=" + outStoreID.ToString() + ")) ";
                    IQuery query = ongoingSession.CreateQuery(HqlQuery);
                    return (int) query.UniqueResult<Int64>();
                }
                catch (Exception ex)
                {
                    return -1;
                }
            }




            // used in purchase returns
            // used in purchase returns

            public static List<String> GeDispatchDiscountsForDispatchPrice(int argItemID, int argStoreID, decimal argPurchasePrice)
            {


                List<string> returnPurchasePrices = new List<string>();
                try
                {


                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenStatelessSession())
                    {




                        //  string orderStr = (UseLatestDispatch) ? " ASC " : "DESC ";
                        //   string HqlQuery = @"select DH from DispatchHistory DH, StoreItems SI, DispatchTrack DT where " + " ((DH.DispatchID=DT.Id) AND (DH.quantity>0) AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=" + argItemID.ToString().Trim() + ") AND " + "(DH.Percenatge=" + percentageGiven.ToString().Trim() + ") " + ")" 

                        string HqlQuery = @"select distinct DH.Percenatge from DispatchHistory DH, StoreItems SI, DispatchTrack DT where " + " ((DH.DispatchID=DT.Id) AND (DH.quantity>0) AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=" + argItemID.ToString().Trim() + ") AND (DH.DispatchPrice=" + argPurchasePrice.ToString() + ") AND (DH.OutStoreID=" + argStoreID.ToString() + ")) Order By DH.Percenatge ASC";
                        IQuery query = sessionobj.CreateQuery(HqlQuery);
                        var dispatchData = query.List();





                        //   var returnTempPurchasePrices = sessionobj.QueryOver<DispatchHistory>().And(Restrictions.Eq("ItemId", argItemID)).And(Restrictions.Eq("OutStoreID", argStoreID)).Future<DispatchHistory>().GroupBy(x => x.DispatchPrice).Select(x => x.Key).OrderBy(x => x).Cast<String>().ToList();

                        if (dispatchData == null) return null;

                        if (dispatchData.Count <= 0) return null;

                        List<string> DisocuntPrices = new List<string>();





                        foreach (var tempitem in dispatchData)
                        {

                            DisocuntPrices.Add(tempitem.ToString());



                        }


                        return DisocuntPrices;
                    }

                }
                catch (Exception ex)
                {


                    throw ex;
                }


               


            }

            public static List<ItemCategory> GetRegisterAndItems(out List<ItemsTrack> registerValues){


                registerValues = new List<ItemsTrack>();
                var tempItemsInDB = new List<ItemCategory>();
                
                ITransaction TempTransaction=null;
                try
                {

                    try
                    {


                        ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                        if (Temp == null) throw new DataException("Error connecting to DataBase");
                        using (var sessionobj = Temp.OpenSession())
                        {

                            using (TempTransaction = sessionobj.BeginTransaction(IsolationLevel.ReadCommitted))
                            {
                                tempItemsInDB = sessionobj.QueryOver<ItemCategory>().OrderBy(x => x.ItemName).Asc.Future<ItemCategory>().ToList();
                                registerValues = sessionobj.QueryOver<ItemsTrack>().OrderBy(x => x.ItemsCategoryID).Asc.Future<ItemsTrack>().ToList();

                                TempTransaction.Commit();
                                return tempItemsInDB;


                            }



                        }
                    }
                    catch (Exception ex)
                    {
                        if (TempTransaction != null)
                        {
                            TempTransaction.Rollback();
                        }

                        throw ex;
                    }
                }
                catch (Exception ex)
                {
                   

                    throw ex;
                }

                
              //  return tempItemsInDB;

                


            }

            public static bool ProcessItemsTrackRegister(List<StoreItems> Items, string PurchaseOrDispatch,ISession sessionobj,ITransaction TempTransaction)
            {
                try
                {
                    

                    int[] categories =Items.GroupBy(x=>x.ItemTypeRef).Select(x=>x.Key??0).Cast<int>().ToArray();
                      var ItemsQuantitysummary = sessionobj.QueryOver<ItemsTrack>().Where(d => d.ItemsCategoryID.IsIn(categories)).List<ItemsTrack>();
                    if (ItemsQuantitysummary == null)
                    {
                        ItemsQuantitysummary = new List<ItemsTrack>();
                    }
                    foreach (var tempItem in Items)
                    {

                        var ItemsTrackObj = ItemsQuantitysummary.Where(x => ((x.ItemsCategoryID == tempItem.ItemTypeRef) && (x.ItemPrice == tempItem.PurchasePrice) && (x.InStoreID == tempItem.InStoreID && (x.Discount == tempItem.Discount)))).FirstOrDefault<ItemsTrack>();

                        if (ItemsTrackObj == null)
                        {
                            ItemsQuantitysummary.Add(new ItemsTrack { ItemsCategoryID = tempItem.ItemTypeRef, ItemPrice = tempItem.PurchasePrice, QOH = tempItem.Quantity,InStoreID=tempItem.InStoreID,Discount=tempItem.Discount });

                        }
                        else
                        {
                            ItemsTrackObj.QOH += tempItem.Quantity;


                        }
                    }

                    ItemsQuantitysummary.ForEach((x)=>{sessionobj.SaveOrUpdate( x);});
                    return true;

                    
                }
                catch (Exception ex)
                {
                    throw ex;

                }

             //   return true;
            }


        }
        // use stateofoperation for purchasetrackservice
        public class PurchaseTrackService
        {
            public int QueryPageNo;
            public int QueryPageSize;


           


            public static List<StoreItemsDTO> GetItems(ref PurchasesTrack thisPurchase,  out StoreData argInStore)
            {
                try
                {
                    using (IStatelessSession sessionObj = SecurityValuesForApp.AppDataFactory.OpenStatelessSession())
                    {

                        argInStore = new StoreData();

                        List<StoreItemsDTO> returnList = new List<StoreItemsDTO>();
                        var TempPurchaseTrack = sessionObj.Get<PurchasesTrack>(thisPurchase.Id);

                        if (TempPurchaseTrack == null) { thisPurchase = null; return null; }

                        thisPurchase = TempPurchaseTrack ;


                        string HQLquery = "Select SI.ItemTypeRef as ItemTypeRef,SI.Quantity as Quantity,SI.QOH as QOH,IC.ItemName as ItemName,SI.PurchasePrice as PurchasePrice,SI.Discount as Discount  from PurchasesTrack PT, StoreItems  SI, ItemCategory IC";
                        HQLquery += " Where ( (PT.Id=" + TempPurchaseTrack.Id.ToString() + ") AND (PT.Id=SI.PurchaseID)  AND (SI.ItemTypeRef=IC.ItemTypeId) ) ";


                        IQuery query = sessionObj.CreateQuery(HQLquery);
                        var ListItems = query.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(StoreItemsDTO))).List<StoreItemsDTO>();

                        if (ListItems == null) { return null; }


                        returnList = ListItems.ToList<StoreItemsDTO>();

                        if (returnList.Count > 0)
                        {

                            var tempDHItem = returnList.First();

                            argInStore = sessionObj.Get<StoreData>(tempDHItem.InStoreID);
                        }

                        return returnList;

                    }
                }
                catch (Exception ex) { throw ex; }

            }





            public int CreatePurchaseTrack(ref PurchasesTrack Item, List<StoreItems> PurchaseItems)
            {

                try
                {


                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null) throw new DataException("Error connecting to DataBase");
                    using (var sessionobj = Temp.OpenSession())
                    {

                        using (ITransaction TempTransaction = sessionobj.BeginTransaction())
                        {
                            try
                            {
                                sessionobj.Save(Item);

                                foreach (var TempItem in PurchaseItems)
                                {

                                    TempItem.PurchaseID = Item.Id;
                                    TempItem.QOH = TempItem.Quantity;
                                    sessionobj.Save(TempItem);
                                }
                                ItemsService.ProcessItemsTrackRegister(PurchaseItems, "P", sessionobj,TempTransaction);

                                TempTransaction.Commit();
                                return 0;
                            }
                            catch (Exception ex)
                            {

                                TempTransaction.Rollback();
                                return -1;
                            }


                        }

                    }
                }
                catch (Exception ex)
                {
                    return -1;

                }

            }

        }

     




        public class DispatchItemCompare : IComparer<DispatchItems>
        {
            #region IComparer<DispatchItems> Members

            public int Compare(DispatchItems x, DispatchItems y)
            {
                int result = (x.InStoreID ?? 0).CompareTo((y.InStoreID ?? 0));
                if (result == 0) result = (x.ItemCategoryID ?? 0).CompareTo((y.ItemCategoryID ?? 0));
                if (result == 0) result = (x.ItemPrice ?? 0).CompareTo((y.ItemPrice ?? 0));

                return result;

            }

            #endregion
        }

        
        
        
        public class DispacthTrackService
            {
                public int QueryPageNo;
                public int QueryPageSize;



               
                // DispatchItemsWithItemName is used to populate Dispatch History values , null return means no dispatch record   
        
                public static List<DispatchItemsWithItemName> GetItems(ref DispatchTrack thisDispatch, out List<PurchaseReturnsForDispatch> argPurchaseReturns, out StoreData argOutStore)
                {
                    try
                    {
                        using (IStatelessSession sessionObj = SecurityValuesForApp.AppDataFactory.OpenStatelessSession())
                        {

                            argOutStore = new StoreData();
                            argPurchaseReturns = new List<PurchaseReturnsForDispatch>();
                            List<DispatchItemsWithItemName> returnList = new List<DispatchItemsWithItemName>();
                            var TempDispatchTrack = sessionObj.Get<DispatchTrack>(thisDispatch.Id);

                            if (TempDispatchTrack == null) { thisDispatch = null; return null; }

                            thisDispatch = TempDispatchTrack;


                            string HQLquery = "Select IC.ItemName as ItemName,IC.ItemTypeId as ItemCategoryID,DH.Percenatge as Percenatge,DH.DispatchPrice as DispatchPrice ,DH.initQuantity as QOH,SI.InStoreID as InStoreID,DH.OutStoreID as OutStoreID,SI.PurchasePrice as ItemPrice,SI.Discount as inDiscount,DH.PriceOut as PriceOut  from DispatchHistory DH,DispatchTrack DT, StoreItems  SI, ItemCategory IC";
                            HQLquery += " Where ( (DT.Id=" + TempDispatchTrack.Id.ToString() + ") AND (DT.Id=DH.DispatchID) AND  (DH.ItemId=SI.ItemID)  AND (SI.ItemTypeRef=IC.ItemTypeId) ) ";


                            IQuery query = sessionObj.CreateQuery(HQLquery);
                            var ListItems = query.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(DispatchItemsWithItemName))).List<DispatchItemsWithItemName>();

                            if (ListItems == null) { return null; }
        
                            argPurchaseReturns = GetPurchasesReturnsInfoForDispatch(TempDispatchTrack.Id ?? -1);
                            returnList=ListItems.ToList<DispatchItemsWithItemName>();

                            if (returnList.Count>0){

                                var tempDHItem= returnList.First();

                                argOutStore=sessionObj.Get<StoreData>(tempDHItem.OutStoreID);
                            }

                            return returnList;

                        }
                    }
                    catch (Exception ex) { throw ex; }

                }

               
                //Using ItemCategorywithdiscount to hold purchases returns Value, null means no purchase returns value;

                 public static List<PurchaseReturnsForDispatch> GetPurchasesReturnsInfoForDispatch(int argDispatchID)
                {
                    try
                    {
                       

                        string HQLquery = "Select IC.ItemName as ItemCategoryName,IC.ItemTypeId as ItemType,DH.Percenatge as Discount,DH.DispatchPrice as Price ,sum(PR.Quantity) as QOH  from DispatchHistory DH,DispatchTrack DT, StoreItems  SI, ItemCategory IC,PurchasesReturns PR ";
                        HQLquery += " Where ( (DT.Id=" + argDispatchID.ToString() + ") AND (DT.Id=DH.DispatchID) AND (PR.DispatchHistoryID=DH.ID) AND (DH.ItemId=SI.ItemID)  AND (SI.ItemTypeRef=IC.ItemTypeId) ) ";
                        HQLquery += " Group By  IC.ItemTypeId,DH.DispatchPrice,DH.Percenatge ";




                        ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                        if (Temp == null) throw new DataException("Error connecting to DataBase");
                        IStatelessSession ongoingSession = Temp.OpenStatelessSession();
                        //ITransaction ongoingTransaction = ongoingSession.BeginTransaction();


                        IQuery query = ongoingSession.CreateQuery(HQLquery);
                        var ListItems = query.SetResultTransformer(NHibernate.Transform.Transformers.AliasToBean(typeof(PurchaseReturnsForDispatch))).List<PurchaseReturnsForDispatch>();

                        if (ListItems == null) { return null; }

                    return ListItems.ToList<PurchaseReturnsForDispatch>();

                    }
                    catch (Exception ex)
                    {

                        throw ex;
                    }

                   




                }

                #region Dispatch Task

                //  createdispatch track code to disptach logic : next thing STEP 1 Create Dispatch Task

                public StateOfOperation CreateDispatchTrack(ref DispatchTrack Item, List<DispatchItems> dispatchItems, bool useLatestPurchases)
                {
                    StateOfOperation tempState = StateOfOperation.GeneralFailure;
                    try
                    {


                        ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                        if (Temp == null) throw new DataException("Error connecting to DataBase");
                        using (var sessionobj = Temp.OpenSession())
                        {

                            using (ITransaction TempTransaction = sessionobj.BeginTransaction())
                            {
                                try
                                {
                                    sessionobj.Save(Item);
                                    if ((Item.Id == null) || (Item.Id == 0)) { tempState = StateOfOperation.DataBaseError; throw new Exception("DB Error Creating ID"); }
                                    int ID = Item.Id ?? 0;
                                    tempState = DispatchItems(dispatchItems, useLatestPurchases, ID,sessionobj,TempTransaction);
                                    if (tempState != StateOfOperation.Success) { throw new Exception("Error"); }

                                    TempTransaction.Commit();
                                    return StateOfOperation.Success;
                                }
                                catch (Exception ex)
                                {

                                    TempTransaction.Rollback();
                                    return tempState;
                                }


                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        return tempState;

                    }
                    return StateOfOperation.Success;

                }
                
                


            // Step 2 Dispatch Task

                public StateOfOperation DispatchItems(List<DispatchItems> ItemForDispatch, bool UseLatestPurchases, int DispatchIDToUse,ISession tempsession, ITransaction temptransaction)
                {

                    // stateofoperation (Important)
                    ISession sessionobj = tempsession;
                    ITransaction TempTransaction = temptransaction;

                    StateOfOperation tempState = StateOfOperation.GeneralFailure;

                    List<StoreItems> storeItemsCache = new List<StoreItems>();
                    List<DispatchHistory> dispatchHistoryCache = new List<DispatchHistory>();
                    List<ItemsTrack> itemsTrackCache = new List<ItemsTrack>();
                 //   ITransaction TempTransaction = null;
                    //sort the items so the list cache is created in efficient manner

                    ItemForDispatch.Sort((IComparer<DispatchItems>)(new DispatchItemCompare()));

                    //   List<int?> ItemCatgories = ItemForDispatch.Select(x=>x.ItemCategoryID).Distinct().ToList<int?>();

                    // Process each item to be dispatched


                    //process each dispatch item
                    try
                    {
                       // ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                        //if (Temp == null) throw new DataException("Error connecting to DataBase");
                       // using (var sessionobj = Temp.OpenSession())
                        {
                            try
                            {
                               // TempTransaction = sessionobj.BeginTransaction(IsolationLevel.ReadCommitted);

                                foreach (var tempItem in ItemForDispatch)
                                {
                                    int limit = 100;
                                    int? ItemQuantity = tempItem.QOH;
                                    bool processFinished = false;

                                    // Loop through untill all the quantity for each ietm is dispatch 
                                    for (int i = 0; ; i += limit)
                                    {

                                        
                                        if (processFinished) break;






                                        {
                                            //   try
                                            //  {
                                            // sessionobj.Save(Item);




                                            //  var  ItemsTrackObj = sessionobj.QueryOver<StoreItems>().Where(x => ((x.ItemTypeRef == tempItem.ItemCategoryID) && (x.PurchasePrice == tempItem.ItemPrice) && (x.InStoreID==tempItem.InStoreID))).Skip(i).Take(limit).Future<StoreItems>().ToList<StoreItems>();

                                            var ItemsTrackCriteriaA = sessionobj.CreateCriteria<StoreItems>().Add(Restrictions.Eq("ItemTypeRef", tempItem.ItemCategoryID)).Add(Restrictions.Eq("InStoreID", tempItem.InStoreID)).Add(Restrictions.Eq("PurchasePrice", tempItem.ItemPrice)).Add(Restrictions.Eq("Discount", tempItem.inDiscount)).Add(Restrictions.Gt("QOH", 0)).AddOrder(new Order("PurchaseID", !UseLatestPurchases)).SetFirstResult(i).SetMaxResults(limit-1).Future<StoreItems>().ToList<StoreItems>();

                                            // change this  code guard to see if there are enough elements for each Dispatch if not USER ShOULD KNOW


                                            if (ItemsTrackCriteriaA == null)
                                            {
                                                tempState = StateOfOperation.NotEnoughDispatchItems;
                                                throw new Exception("Not enough Elements to be dispatched");
                                            }

                                            if (ItemsTrackCriteriaA.Count <= 0)
                                            {
                                                tempState = StateOfOperation.NotEnoughDispatchItems;
                                                throw new Exception("Not enough Elements to be dispatched");
                                            }

                                            // sort results to delete first elements with lowest QOH;

                                            ItemsTrackCriteriaA.Sort((x1, x2) => { var result = (x1.ItemID ?? 0).CompareTo((x2.ItemID ?? 0)); if (result == 0) { result = (x1.QOH ?? 0).CompareTo((x2.QOH ?? 0)); } return result; });

                                            // Add DB list to cache whenever required

                                            storeItemsCache.AddRange(ItemsTrackCriteriaA);

                                            var ItemsTrackCriteria = storeItemsCache.Where<StoreItems>(x => ((x.QOH > 0) && (x.InStoreID==tempItem.InStoreID) && (x.ItemTypeRef==tempItem.ItemCategoryID) && (x.PurchasePrice==tempItem.ItemPrice) && (x.Discount==tempItem.inDiscount)) );


                                            foreach (var tempStoreItem in ItemsTrackCriteria)
                                            {
                                                // this variable tracks the dispatch track qunatity
                                                int QOHAdjusted = 0;
                                                if ((tempStoreItem.QOH ?? 0) > 0)
                                                {
                                                    if (ItemQuantity <= tempStoreItem.QOH)
                                                    {

                                                        tempStoreItem.QOH = tempStoreItem.QOH - ItemQuantity;
                                                        QOHAdjusted = ItemQuantity ?? 0;
                                                        ItemQuantity = 0;
                                                        processFinished = true;
                                                        tempStoreItem.InStore_Or_Dispatched = "R";


                                                    }
                                                    else
                                                    {

                                                        QOHAdjusted = tempStoreItem.QOH ?? 0;
                                                        ItemQuantity -= tempStoreItem.QOH;
                                                        tempStoreItem.QOH = 0;
                                                        tempStoreItem.InStore_Or_Dispatched = "R";

                                                    }

                                                    // Adjust or create dispatch history element cached;




                                                    var dispatchedItemGet = dispatchHistoryCache.Where<DispatchHistory>(x => ((x.DispatchID == DispatchIDToUse) && (x.OutStoreID == tempItem.OutStoreID) && (x.DispatchPrice == tempItem.DispatchPrice) && (x.Percenatge == tempItem.Percenatge) && (x.ItemId == tempStoreItem.ItemID))).FirstOrDefault<DispatchHistory>();

                                                    if (dispatchedItemGet == null)
                                                    {

                                                        dispatchHistoryCache.Add(new DispatchHistory { DispatchID = DispatchIDToUse, ItemId = tempStoreItem.ItemID, OutStoreID = tempItem.OutStoreID, DispatchPrice = tempItem.DispatchPrice, Percenatge = tempItem.Percenatge, PriceOut = tempItem.PriceOut, quantity = tempItem.QOH, initQuantity = tempItem.QOH });
                                                    }

                                                    else
                                                    {
                                                        dispatchedItemGet.quantity += QOHAdjusted;
                                                        dispatchedItemGet.initQuantity += QOHAdjusted;

                                                    }


                                                    // update ItemsTrack cache Object

                                                    var itemsTrackGet = itemsTrackCache.Where<ItemsTrack>(x => ((x.ItemsCategoryID == tempStoreItem.ItemTypeRef) && (x.InStoreID == tempStoreItem.InStoreID) && (x.ItemPrice == tempStoreItem.PurchasePrice) && (x.Discount == tempStoreItem.Discount))).FirstOrDefault<ItemsTrack>();

                                                    if (itemsTrackGet == null)
                                                    {
                                                        ItemsTrack tempItemsTrackObj = new ItemsTrack { ItemsCategoryID = tempStoreItem.ItemTypeRef, InStoreID = tempStoreItem.InStoreID, ItemPrice = tempStoreItem.PurchasePrice, QOH = QOHAdjusted, Discount=tempStoreItem.Discount };
                                                        itemsTrackCache.Add(tempItemsTrackObj);


                                                    }

                                                    else { itemsTrackGet.QOH += QOHAdjusted; }


                                                    // BEGIN HERE NOW exit loop and iteration

                                                }


                                                if (processFinished) break;





                                            } // Exit of inner iteration over





                                        } // dummy scope

                                    }  // end of for loop




                                } // End of outer foreach and iterating  all items



                            }
                            catch (Exception ex)
                            {

                               // if (TempTransaction != null) TempTransaction.Rollback();
                                throw ex;

                            } // end of using  try
                          //  TempTransaction.Commit(); // note nothing here to commit but used to end of unit work
                        } // end of using session
                    }

                    catch (Exception ex)
                    {
                        return tempState;

                    }

                    try
                    {

                        List<StoreItems> changedItems = storeItemsCache.Where<StoreItems>(x => (x.InStore_Or_Dispatched == "R")).ToList<StoreItems>();
                        tempState = ProcessDispatchCache(changedItems, dispatchHistoryCache, itemsTrackCache,sessionobj,TempTransaction );
                        if (tempState != StateOfOperation.Success) { throw new Exception(); }

                    }
                    catch (Exception Ex)
                    {

                        throw Ex;



                    }
                    //BEGIN HERE process  write database operations to persist caches

                    return StateOfOperation.Success;


                }


            //STEP 3 Dispatch Task

                public StateOfOperation ProcessDispatchCache(List<StoreItems> StoreCache, List<DispatchHistory> DispatchHistoryElements, List<ItemsTrack> RegisterElements, ISession tempsessionobj, ITransaction TempTransaction)
             {
                 ISession sessionobj = tempsessionobj;

                 ITransaction TempTransactionDB=TempTransaction;

                 StateOfOperation tempState = StateOfOperation.GeneralFailure;

                try
                {

                    /*
                    ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                    if (Temp == null)
                    {
                        tempState = StateOfOperation.DataBaseError; throw new DataException("Error connecting to DataBase");
                    }

                    using (var sessionobj = Temp.OpenSession())
                    
                     * 
                     */
                    {
                        try
                        {
                           // TempTransactionDB = sessionobj.BeginTransaction(IsolationLevel.ReadCommitted);
                            {

                                // update Items


                                tempState = StateOfOperation.DataBaseError;
                                foreach (var tempStoreItemDb in StoreCache)
                                {

                                    tempStoreItemDb.InStore_Or_Dispatched = "D";
                                    sessionobj.SaveOrUpdate(tempStoreItemDb);
                                }
                                tempState = StateOfOperation.DataBaseError;
                                foreach (var tempItemDb in DispatchHistoryElements)
                                {

                                    sessionobj.SaveOrUpdate(tempItemDb);
                                }
                                tempState = StateOfOperation.GeneralFailure;


                            
                                var allItemsTypeInTransactionArr = RegisterElements.GroupBy(x => x.ItemsCategoryID).Select(x => x.Key ?? 0).Cast<int>().ToArray(); ;
                                tempState = StateOfOperation.DataBaseError;
                                var allItemTypesInRegister = sessionobj.QueryOver<ItemsTrack>().WhereRestrictionOn(x => x.ItemsCategoryID).IsIn(allItemsTypeInTransactionArr).List<ItemsTrack>();
                                tempState = StateOfOperation.GeneralFailure;
                                foreach (var registerElm in RegisterElements)
                                {
                                    
                                    // BEGIN HERE  to update register 

                                    var tempRegisterItem = allItemTypesInRegister.Where<ItemsTrack>(x => ((x.InStoreID == registerElm.InStoreID) && (x.ItemsCategoryID == registerElm.ItemsCategoryID) && (x.ItemPrice == registerElm.ItemPrice) && (x.Discount == registerElm.Discount))).FirstOrDefault<ItemsTrack>();

                                    if (tempRegisterItem == null)
                                    {

                                        tempState = StateOfOperation.RegisterCorrupted;

                                        throw new Exception("Register problem");

                                    }

                                    tempRegisterItem.QOH -= registerElm.QOH;
                                    if (tempRegisterItem.QOH < 0) { tempState = StateOfOperation.RegisterCorrupted; throw new Exception("Register problem"); }
                                    tempState = StateOfOperation.DataBaseError;
                                    sessionobj.SaveOrUpdate(tempRegisterItem);

                                }

                                tempState = StateOfOperation.GeneralFailure;

                            }
                            return StateOfOperation.Success;
                           // TempTransactionDB.Commit();
                        }
                        catch (Exception ex){
                     //   if(TempTransactionDB!=null) TempTransactionDB.Rollback();
                        throw ex;
                    }
                    }

                }
                    
                
                 catch (Exception ex){


                     throw ex;
                     
                 }



                 return StateOfOperation.Success;
             }


 #endregion

             public int GetItemsDispatched(int itemCategoryID, int outStoreID,  decimal percentageGiven, decimal PurchasePrice)
             {
                 try
                 {
                     ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                     if (Temp == null) throw new DataException("Error connecting to DataBase");
                     ISession ongoingSession = Temp.OpenSession();
                     //ITransaction ongoingTransaction = ongoingSession.BeginTransaction();

                     string HqlQuery = @"select sum(DH.quantity) from DispatchHistory DH, StoreItems SI, DispatchTrack DT where " + " ((DH.DispatchID=DT.Id) AND (DH.quantity>0) AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=" + itemCategoryID.ToString().Trim() + ") AND " + "(DH.Percenatge=" + percentageGiven.ToString().Trim() + ") AND " + "(DH.DispatchPrice=" + PurchasePrice.ToString().Trim() + ")) ";
                     IQuery query = ongoingSession.CreateQuery(HqlQuery);
                     return query.UniqueResult<int>();
                 }
                 catch (Exception ex)
                 {
                     return -1;
                 }
             }

             public StateOfOperation ProcessPurchaseReturns(int itemCategoryID, int outStoreID, int quantityReturned, decimal percentageGiven, decimal PurchasePrice, bool UseLatestDispatch)
             {
                // int FirstList = 1;
                 int Limit = 100;
               //  int index = 0;

                 int QOH = quantityReturned;

                 bool finished=false;

                 ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                 if (Temp == null) throw new DataException("Error connecting to DataBase");
                 ISession ongoingSession = Temp.OpenSession();
                 ITransaction ongoingTransaction = ongoingSession.BeginTransaction();

                 try
                 {
                     List<DispatchHistory> dispatchCache = new List<DispatchHistory>();
                     List<StoreItems> itemsCache = new List<StoreItems>();
                     List<ItemsTrack> registerCache = new List<ItemsTrack>();
                     List<PurchasesReturns> returnsCache = new List<PurchasesReturns>();
                     //ISessionFactory Temp = SecurityValuesForApp.AppDataFactory;
                     //if (Temp == null) throw new DataException("Error connecting to DataBase");
                     //ISession ongoingSession = Temp.OpenSession();
                     //ITransaction ongoingTransaction = ongoingSession.BeginTransaction();

                     for (int index = 0; ; index++)
                     {

                         if ((QOH <= 0) || finished) break;


                         string orderStr = (UseLatestDispatch) ? " ASC " : "DESC ";
                         string HqlQuery = @"select DH from DispatchHistory DH, StoreItems SI, DispatchTrack DT where " + " ((DH.DispatchID=DT.Id) AND (DH.quantity>0)  AND (DH.ItemId=SI.ItemID) AND (SI.ItemTypeRef=" + itemCategoryID.ToString().Trim() + ") AND " + "(DH.Percenatge=" + percentageGiven.ToString().Trim() + ") AND " + "(DH.DispatchPrice=" + PurchasePrice.ToString().Trim() + ") AND (DH.OutStoreID="+outStoreID.ToString() +")) ORDER By DT.DispatchedDate " + orderStr;
                         IQuery query = ongoingSession.CreateQuery(HqlQuery).SetFirstResult(Limit * index).SetMaxResults(Limit);
                         var dispatchData = query.List<DispatchHistory>() ;







                         #region ProcessItems
                         foreach (var tempDispatchHistory in dispatchData)
                         {
                             var getDHCacheItem = dispatchCache.Where(x => x.ID == tempDispatchHistory.ID).FirstOrDefault();
                             var getPRCacheItem = returnsCache.Where(x => x.DispatchHistoryID == tempDispatchHistory.ID).FirstOrDefault();
                             int tempItemID = 0; decimal tempPurchasePrice = 0; Double tempDiscount = 0; int QOHAdj = 0; int tempInStoreID = 0; int tempItemCategory;

                             if (getDHCacheItem == null)
                             {
                                 if ((tempDispatchHistory.quantity ?? 0) >= QOH)
                                 {
                                     QOHAdj = QOH;
                                     tempDispatchHistory.quantity -= QOH;
                                     QOH = 0; finished = true;


                                 }

                                 else
                                 {
                                     QOH -= tempDispatchHistory.quantity ?? 0;
                                     QOHAdj = tempDispatchHistory.quantity ?? 0;
                                     tempDispatchHistory.quantity = 0; finished = false;

                                 }
                                 tempItemID = tempDispatchHistory.ItemId ?? 0;
                                 dispatchCache.Add(tempDispatchHistory);
                                 if (getPRCacheItem == null)
                                 {
                                     returnsCache.Add(new PurchasesReturns() { DispatchHistoryID = tempDispatchHistory.ID, ItemID = tempDispatchHistory.ItemId, Quantity = QOHAdj, ReturnDate = DateTime.Now });
                                 }

                             }

                             else
                             {

                                 if ((getDHCacheItem.quantity ?? 0) >= QOH)
                                 {
                                     QOHAdj = QOH;
                                     getDHCacheItem.quantity -= QOH;
                                     QOH = 0; finished = true;


                                 }

                                 else
                                 {
                                     QOH -= getDHCacheItem.quantity ?? 0;
                                     QOHAdj = getDHCacheItem.quantity ?? 0;
                                     getDHCacheItem.quantity = 0; finished = false;

                                 }

                                 if (getPRCacheItem != null)
                                 {
                                     getPRCacheItem.Quantity += QOHAdj;
                                 }

                                 tempItemID = getDHCacheItem.ItemId ?? 0;
                             }


                             var getSICacheItem = itemsCache.Where(x => x.ItemID == tempItemID).FirstOrDefault();


                             if (getSICacheItem == null)
                             {

                                 var getSICacheItemTemp = ongoingSession.QueryOver<StoreItems>().Where(x => x.ItemID == tempItemID).List().FirstOrDefault();
                                 getSICacheItemTemp.QOH += QOHAdj;
                                 if (getSICacheItemTemp.QOH < 0) throw new Exception("error in DB");

                                 itemsCache.Add(getSICacheItemTemp);

                                 tempPurchasePrice = getSICacheItemTemp.PurchasePrice ?? 0;
                                 tempDiscount = getSICacheItemTemp.Discount ?? 0;
                                 tempInStoreID = getSICacheItemTemp.InStoreID ?? 0;
                                 tempItemCategory = getSICacheItemTemp.ItemTypeRef ?? 0;


                             }

                             else
                             {

                                 getSICacheItem.QOH += QOHAdj;
                                 if (getSICacheItem.QOH < 0) throw new Exception("error in DB");



                                 tempPurchasePrice = getSICacheItem.PurchasePrice ?? 0;
                                 tempDiscount = getSICacheItem.Discount ?? 0;
                                 tempInStoreID = getSICacheItem.InStoreID ?? 0;
                                 tempItemCategory = getSICacheItem.ItemTypeRef ?? 0;

                             }

                             var GetRegisterItem = registerCache.Where(x => ((x.ItemsCategoryID == tempItemCategory) && (x.ItemPrice == tempPurchasePrice) && (x.Discount == tempDiscount) && (x.InStoreID == tempInStoreID))).FirstOrDefault();

                           


                             if (GetRegisterItem == null)
                             {

                                 var GetRegisterItemTemp = ongoingSession.QueryOver<ItemsTrack>().Where(x => ((x.ItemsCategoryID == tempItemCategory) && (x.ItemPrice == tempPurchasePrice) && (x.Discount == tempDiscount) && (x.InStoreID == tempInStoreID))).List().FirstOrDefault();


                                 GetRegisterItemTemp.QOH += QOHAdj;
                                 registerCache.Add(GetRegisterItemTemp);
                             }
                             else
                             {

                                 GetRegisterItem.QOH += QOHAdj;

                             }



                             // use this: PurchaseReturnsCache.Add(new PurchasesReturns() { DispatchHistoryID = tempHistory.ID, ItemID = tempHistory.ItemId, Quantity = tempHistory.quantity, ReturnDate = DateTime.Now });

                             if (finished) break;

                         }




#endregion


                    #region Save Data
                         dispatchCache.ForEach(x => {  ongoingSession.SaveOrUpdate(x); });
                      //   itemsCache.ForEach(x => { ongoingSession.SaveOrUpdate(x); });
                         returnsCache.ForEach(x => { ongoingSession.SaveOrUpdate(x); });
                    //     registerCache.ForEach(x => { ongoingSession.SaveOrUpdate(x); });


                         ongoingTransaction.Commit();

                         return StateOfOperation.Success;


                    #endregion

                         

                     }



                 }
                 catch (Exception)
                 {
                     ongoingTransaction.Rollback();

                     throw;
                 }


                 return StateOfOperation.Success;
             }

             public StateOfOperation ProcessDispatchReturns(List<DispatchHistory> historyItems, List<int> QOH,int DispatchID,ITransaction ongoingTransaction,ISession ongoingSession)
             {

                 //Get all Items ITEMS with the dispatch ID

                 //Get all Itemscategories for all items in registry with this dispatch ID

                 // for each dispatch update Items qunatity with QOH and mark 'R' and reduce dispatch Quantity, update register cache Values

                 // Save caches to DB all the ITEMS with R, update dispatch qunatity in dispatch track and save register cache 

                 ongoingTransaction =ongoingSession.Transaction;



                 try
                 {
                     object[] ItemsArray = historyItems.Distinct(new LambdaComparer<DispatchHistory>((x, y) => { return (x.ItemId ?? 0) == (y.ItemId ?? 0); })).Select(x => x.ItemId ?? 0).Cast<object>().ToArray<object>();



                     var projections = Projections.Distinct(Projections.ProjectionList().Add(Projections.Property("ItemTypeRef").As("ItemTypeRef")));
                     var getRegisterProjection = Projections.ProjectionList().Add(Projections.Property("ItemsCategoryID").As("ItemsCategoryID"));

                     var itemsUniqueCategories = ongoingSession.QueryOver<StoreItems>().Select(projections).List();

                     var itemCategoriesUniqueArray = itemsUniqueCategories.Select(x => x.ItemTypeRef ?? 0).Cast<object>().ToArray();

                     var RegisterCache = ongoingSession.QueryOver<ItemsTrack>().WhereRestrictionOn(d => d.ItemsCategoryID).IsIn(itemCategoriesUniqueArray).List();

                     var ItemsCache = ongoingSession.QueryOver<StoreItems>().WhereRestrictionOn(d => d.ItemID).IsIn(ItemsArray).List();
                     var PurchaseReturnsCache = new List<PurchasesReturns>();

                     int i = 0;

                     foreach (var tempHistory in historyItems)
                     {
                         var TempItem = ItemsCache.Where(x => x.ItemID == tempHistory.ItemId).FirstOrDefault();

                         var QOHAdj = QOH[i];

                         if (TempItem != null)
                         {

                             TempItem.QOH += QOHAdj;
                             TempItem.InStore_Or_Dispatched = "R";

                             PurchaseReturnsCache.Add(new PurchasesReturns() { DispatchHistoryID = tempHistory.ID, ItemID = tempHistory.ItemId, Quantity = tempHistory.quantity, ReturnDate = DateTime.Now });


                             var GetRegisterItem = RegisterCache.Where(x => ((x.ItemsCategoryID == TempItem.ItemTypeRef) && (x.ItemPrice == TempItem.PurchasePrice) && (x.Discount == TempItem.Discount) && (x.InStoreID == TempItem.InStoreID))).FirstOrDefault();



                             if (GetRegisterItem != null)
                             {

                                 GetRegisterItem.QOH += TempItem.QOH;

                                 tempHistory.quantity -= QOHAdj;

                             }


                         }

                         i++;


                     }

                     //   update dataBase

                     
                     var ItemsUpdatedCache = ItemsCache.Where(x => x.InStore_Or_Dispatched.Equals((object)"R")).ToList();

                     ItemsUpdatedCache.ForEach(x => { x.InStore_Or_Dispatched = "D"; ongoingSession.SaveOrUpdate(x); });
                     PurchaseReturnsCache.ForEach(x => { ongoingSession.SaveOrUpdate(x); });
                     RegisterCache.ForEach(x => { ongoingSession.SaveOrUpdate(x); });
                     historyItems.ForEach(x => { ongoingSession.SaveOrUpdate(x); });


                 }
                 catch (Exception ex)
                 {
                     
                     throw ex;
                 }

                 

                 return StateOfOperation.Success;
             }



             public class LambdaComparer<T> : IEqualityComparer<T>
             {
                 private readonly Func<T, T, bool> _lambdaComparer;
                 private readonly Func<T, int> _lambdaHash;

                 public LambdaComparer(Func<T, T, bool> lambdaComparer) :
                     this(lambdaComparer, o => 0)
                 {
                 }

                 public LambdaComparer(Func<T, T, bool> lambdaComparer, Func<T, int> lambdaHash)
                 {
                     if (lambdaComparer == null)
                         throw new ArgumentNullException("lambdaComparer");
                     if (lambdaHash == null)
                         throw new ArgumentNullException("lambdaHash");

                     _lambdaComparer = lambdaComparer;
                     _lambdaHash = lambdaHash;
                 }

                 public bool Equals(T x, T y)
                 {
                     return _lambdaComparer(x, y);
                 }

                 public int GetHashCode(T obj)
                 {
                     return _lambdaHash(obj);
                 }
             }

             





           








                public PurchasesTrack GetPurchasesTrackById(string ID)
                {


                    return new PurchasesTrack();

                }

                public int DeletePurchasesTrack(string ID)
                {

                    return 0;
                }

            }

    

        }
    


