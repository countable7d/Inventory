﻿namespace SatStoreTrac.DataLayer
{
    using MongoStoreTrack;
    using System.Data;
    using MongoDB.Driver;
    using System;
    using System.Linq;
    using MongoDB.Driver.Builders;
    using System.Text.RegularExpressions;
    using MongoDB.Bson;
    using System.Collections.Generic;

    public class StoresService
    {
        public int QueryPageNo;
        public int QueryPageSize;
        public long CurrentCount;

        public int CreateORUpdateStore(StoreData Item)
        {
            try
            {
                MongoDatabase Temp = ConnectionClass.GetConnectionToDB();
                if (Temp == null) throw new MongoConnectionException("Error connecting to DataBase");
                Temp.GetCollection<StoreData>("StoreData").Save(Item);

                return 0;




            }
            catch (MongoConnectionException)
            {

                return -1;
            }
            catch (Exception)
            {

                return 1;
            }


        }

        public List<StoreData>  QueryStoresByName(string StoreName, int PageSize, int PageNo){

             try
            {
                MongoDatabase Temp = ConnectionClass.GetConnectionToDB();
                 
                if (Temp == null) throw new MongoConnectionException("Error connecting to DataBase");
               var TempCollection= Temp.GetCollection<StoreData>("StoreData");
                 IMongoQuery TempQuery=null;
               MongoCursor<StoreData> TempCursor=null;
               if (StoreName != "")
               {
                    TempQuery = Query<StoreData>.Matches(x => x.StoreName, new BsonRegularExpression(new Regex("^"+StoreName + ".$", RegexOptions.IgnoreCase)));
               
               TempCursor= TempCollection.Find(TempQuery).SetSortOrder(SortBy.Ascending("StoreName")).SetSkip(PageSize*PageNo).SetLimit(PageSize);

               }
               else
               {
                   TempCursor = TempCollection.FindAll().SetSortOrder(SortBy.Ascending("StoreName")).SetSkip(PageSize*PageNo).SetLimit(PageSize);
               }

               if (TempCursor.Size() <= 0) { return null; }
               return TempCursor.ToList<StoreData>();
                 




            }

            catch(Exception ex ){

                throw ex;
            
            }

           
        

    }


    public class ItemCategoryService
    {
        public int QueryPageNo;
        public int QueryPageSize;

        public int CreateORUpdateStore(ItemCategory Item)
        {
            try
            {
                MongoDatabase Temp = ConnectionClass.GetConnectionToDB();
                if (Temp == null) throw new MongoConnectionException("Error connecting to DataBase");
                Temp.GetCollection<ItemCategory>("ItemCategory").Save(Item);

                return 0;




            }
            catch (MongoConnectionException )
            {

                return -1;
            }
            catch (Exception )
            {

                return 1;
            }

        }

        public List<ItemCategory> QueryItemCategoryByName(string ItemName, int PageSize, int PageNo)
        {
             try
            {
                MongoDatabase Temp = ConnectionClass.GetConnectionToDB();
                 
                if (Temp == null) throw new MongoConnectionException("Error connecting to DataBase");
               var TempCollection= Temp.GetCollection<ItemCategory>("ItemCategory");
                 IMongoQuery TempQuery=null;
               MongoCursor<ItemCategory> TempCursor=null;
               if (ItemName != "")
               {
                    TempQuery = Query<ItemCategory>.Matches(x => x.ItemName, new BsonRegularExpression(new Regex("^"+ItemName + ".$", RegexOptions.IgnoreCase)));
               
               TempCursor= TempCollection.Find(TempQuery).SetSortOrder(SortBy.Ascending("ItemName")).SetSkip(PageSize*PageNo).SetLimit(PageSize);

               }
               else
               {
                   TempCursor = TempCollection.FindAll().SetSortOrder(SortBy.Ascending("ItemName")).SetSkip(PageSize*PageNo).SetLimit(PageSize);
               }

               if (TempCursor.Size() <= 0) { return null; }
               return TempCursor.ToList<ItemCategory>();
                 




            }

            catch(Exception ex ){

                throw ex;
            
            }
        }

    }

    public class PurchaseTrackService
    {
        public int QueryPageNo;
        public int QueryPageSize;
        

        public int CreatePurchaseTrack(PurchasesTrack Item, List<StoreItems> PurchaseItems)
        {
            int ReturnValue=-2;
             List<ObjectId> ItemsInserted = new List<ObjectId>();
            bool exceptionTrue = false;
            MongoCollection<PurchasesTrack> TempCollection=null;
            MongoCollection<StoreItems> ItemsCollection=null;
            ObjectId? PurchaseId=null;
            try{
             MongoDatabase Temp = ConnectionClass.GetConnectionToDB();
                 
                if (Temp == null) throw new MongoConnectionException("Error connecting to DataBase");
                TempCollection= Temp.GetCollection<PurchasesTrack>("PurchasesTrack");
                 ItemsCollection=Temp.GetCollection<StoreItems>("StoreItems");
                TempCollection.Insert(Item,SafeMode.True);

                PurchaseId= Item.Id;

                foreach (var TempItem in PurchaseItems){

                    TempItem.PurchaseID=PurchaseId;
                    ItemsCollection.Insert(TempItem,SafeMode.True);
                    ItemsInserted.Add(TempItem.Id);



                }
            
            }
            catch(MongoConnectionException ex){

                
                exceptionTrue=true;
            } 
            catch (Exception ex){
    
                exceptionTrue=true;
                
            }
            finally{

                if (exceptionTrue || ItemsInserted.Count<PurchaseItems.Count){
                    if (PurchaseId==null){
                        ReturnValue=-1;
                        
                    }

                    else {

                        TempCollection.Remove(  Query<PurchasesTrack>.EQ(x=>x.Id,PurchaseId));


                    }


                }



            }
                return 0;

        }

        public PurchasesTrack GetPurchasesTrackById(string ID)
        {


            return new PurchasesTrack();

        }

        public int DeletePurchasesTrack(string ID)
        {

            return 0;
        }

    }

    public static class ConnectionClass{

     public static MongoDatabase GetConnectionToDB(){
          try
          {
              MongoServerSettings settings = new MongoServerSettings();
              settings.Server = new MongoServerAddress("localhost", 27017);
              // Create server object to communicate with our server
              MongoServer server = new MongoServer(settings);
              // Get our database instance to reach collections and data
              var database = server.GetDatabase("SatStoreTracker");
              return database;
          }

          catch (Exception ex)
          {
              return null;

          }
              
}

    }



}