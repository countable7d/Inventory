﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using Caliburn.Micro;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;

namespace SatStoreTrac
{
    public class StoreManagerViewModel : Screen
    {

        public ObservableCollection<StorePrintHeader> _listPrintLines = new ObservableCollection<StorePrintHeader>();

        public ObservableCollection<StorePrintHeader> listPrintLines { get { return _listPrintLines; } set { _listPrintLines = value; } }

        private string _isSaveOrUpdate = "Add New";
        public string isSaveOrUpdate { get { return _isSaveOrUpdate; } set { _isSaveOrUpdate = value; NotifyOfPropertyChange(() => isSaveOrUpdate); } }
        double DefaultPrice = 0;
        double ROLForItem = 0;
        private string _txtName;
        private string _txtROLvalue;
        private string _txtDefaultPricevalue;
        private int pageindex = 0;
        private int pageSize = 15;
        private string searchCriteria = "";
        public bool IsUpdate { get { return _IsUpdate; } set { _IsUpdate = value; NotifyOfPropertyChange(() => IsUpdate); } }
        public bool _IsUpdate = false;
        public int CurrentItemID = -1;
        private bool _isAllChecked = false;
        public bool isAllChecked { get { return _isAllChecked; } set { _isAllChecked = value; NotifyOfPropertyChange(() => isAllChecked); } }

        private bool _isAdminPwd = false;
        private string _txtAdminPwd = "";
        private string _txtPwd = "";
        private string _txtConfirmPwd = "";


        public bool isAdminPwd { get {  return _isAdminPwd;} set{_isAdminPwd=value;NotifyOfPropertyChange(()=>isAdminPwd);}  }
        public string txtAdminPwd { get { return _txtAdminPwd; } set { _txtAdminPwd = value; NotifyOfPropertyChange(() => txtAdminPwd); } }
        public string txtPwd { get { return _txtPwd; } set { _txtPwd = value; NotifyOfPropertyChange(() => txtPwd); } }
        public string txtConfirmPwd { get { return _txtConfirmPwd; } set { _txtConfirmPwd = value; NotifyOfPropertyChange(() => txtConfirmPwd); } }

        public string txtItemName { get { return _txtName; } set { _txtName = value; NotifyOfPropertyChange(() => txtItemName); } }
        public string txtROL { get { return _txtROLvalue; } set { _txtROLvalue = value; NotifyOfPropertyChange(() => txtROL); } }
        public string txtDefaultPrice { get { return _txtDefaultPricevalue; } set { _txtDefaultPricevalue = value; NotifyOfPropertyChange(() => txtDefaultPrice); } }

        ISession currentses = null;

        public ItemCategoryService itemCategoryService = new ItemCategoryService();

        public StoreManagerViewModel()
        {
            /*
             if (currentses == null)
             {

                 currentses = SecurityValuesForApp.AppDataFactory.OpenSession();

             }



             IQuery resultsquery = currentses.CreateQuery(" from  ItemCategory order by ItemName");
             */
            isAllChecked = true;
            var results = ItemsService.GetPrintHeader();
            foreach (var ItemsInList in results)
            {


                _listPrintLines.Add(ItemsInList);


            }

            ClearForm();
        }


        public bool SaveHeaders()
        {
            
            List<string> headersValues = new List<string>();
            try
            {

                headersValues = listPrintLines.Select(x => x.line).ToList<string>();

                return ItemsService.SavePrintHeader(headersValues);

            }
            catch (Exception ex)
            {
                return false;
                throw ex;

            }



        }


        public bool  UpdatePassword(string argAdminPwd,string argPwd,string argConfirmPwd){


            txtAdminPwd = argAdminPwd;
            txtPwd = argPwd; txtConfirmPwd = argConfirmPwd;


            if (ValidatePasswordChange())
            {
                string UserType = "USER";
                string UserName = "User";

                if (isAdminPwd) { UserType = "ADMIN"; UserName = "Administrator"; }

                if (ItemsService.UpdateUserPin(txtPwd, UserType))
                {
                    MessageBox.Show("Successfully updated " + UserName + " Password", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    SecurityValuesForApp.UserData = ItemsService.GetUserData();
                    txtAdminPwd = ""; txtPwd = ""; txtConfirmPwd = "";
                    return true;
                }

                else
                {

                    MessageBox.Show("Error updating " + UserName + " Password", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                    return false;
                }

               

            }
            return false;

        }


        public bool ValidatePasswordChange()
        {

            

            string UserType = "ADMIN";
            var tmpUser= SecurityValuesForApp.UserData.Where(x => ((x.UserType.ToUpper().Trim() == UserType.ToUpper().Trim()) && (x.UserString == txtAdminPwd))).FirstOrDefault();

            if (tmpUser == null)
            {

                MessageBox.Show("Admin Password is Wrong!", " Enter correct Admin Password", MessageBoxButton.OK, MessageBoxImage.Exclamation);

                return false;
            }

            if (txtPwd.StartsWith(" ") || txtPwd.EndsWith(" "))
            {

                MessageBox.Show(" Password cannot start or end with spaces!", "Wrong Password Format", MessageBoxButton.OK, MessageBoxImage.Exclamation);

                return false;

            }

            if (txtPwd.Length<4)
            {

                MessageBox.Show("Minimum Password length is 4 characters !", "Minimum Password Length ", MessageBoxButton.OK, MessageBoxImage.Exclamation);

                return false;

            }

            if (txtPwd != txtConfirmPwd)
            {


                MessageBox.Show("Rentered password does not match ","Passwords do not match!",  MessageBoxButton.OK, MessageBoxImage.Exclamation);

                return false;

            }

            return true;

        }




        public void btnSaveOrUpdate(RoutedEventArgs e)
        {
            e.Handled = true;
            try
            {
                if (validateForm()){

                if (CurrentItemID < 0)
                {
                    _listPrintLines.Add(new StorePrintHeader { lineNo = listPrintLines.Count + 1, line = txtItemName });
                    listPrintLines = _listPrintLines;
                   
                }
                else{
                    _listPrintLines[CurrentItemID] = new StorePrintHeader() { lineNo = _listPrintLines[CurrentItemID].lineNo, line = txtItemName };
                    listPrintLines = _listPrintLines;
                }
                    ClearForm();
               }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Failed to update Printer header", "Failed ", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }




        public void ShowItemSelectedInList(ListView itemsList)
        {

            

            if (itemsList.SelectedItem != null)
            {
                StorePrintHeader Tempitem = itemsList.SelectedItem as StorePrintHeader;

               
                txtItemName = Tempitem.line;
                CurrentItemID = itemsList.SelectedIndex;
                IsUpdate = true;
                isSaveOrUpdate = "Update";
            }




        }
        public void ClearForm()
        {


            
            txtItemName = "";
            CurrentItemID = -1;
            IsUpdate = false;
            isSaveOrUpdate = "Add New";


        }

        private bool validateForm()
        {
            if (txtItemName.Trim() == "") { MessageBox.Show("Empty string will not be accepted", "Empty string!", MessageBoxButton.OK, MessageBoxImage.Warning); return false; }
            return true;

        }


    }
}
