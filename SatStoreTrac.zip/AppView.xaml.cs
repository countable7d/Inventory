﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Caliburn.Micro;
using Caliburn;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for AppView.xaml
    /// </summary>
    public partial class AppView : UserControl
    {
        public AppView()
        {
            InitializeComponent();
        }

        private void Button_StoreManager_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((AppViewModel)this.DataContext).Parent).ActivateItem(new StoreManagerViewModel());
            
        }
       

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((AppViewModel)this.DataContext).Parent).ActivateItem(new AddItemViewModel());
            
        }
        private void Stores_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((AppViewModel)this.DataContext).Parent).ActivateItem(new StoreManageViewModel());

        }

        private void PurchaseReturns_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((AppViewModel)this.DataContext).Parent).ActivateItem(new ReturnsViewModel());

        }
        private void Button_Dispatch_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((AppViewModel)this.DataContext).Parent).ActivateItem(new DispatchTrackViewModel());

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ((IConductor)((AppViewModel)this.DataContext).Parent).ActivateItem(new PurchaseTrackViewModel());
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ((IConductor)((AppViewModel)this.DataContext).Parent).ActivateItem(new MisCenterViewModel());
        }

       
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            ((IConductor)((AppViewModel)this.DataContext).Parent).ActivateItem(new FrontViewModel());

           // System.Environment.Exit(0);
        }


    }
}
