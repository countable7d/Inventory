﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for StoreDialogView.xaml
    /// </summary>
    public partial class StoreDialogView : Window
    {
        public StoreDialogView()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
          /*  Window temp = Window.GetWindow(this.Parent);
            temp.Height = 900;
            temp.Width = 1500;
            temp.ResizeMode = ResizeMode.NoResize;
            temp.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            temp.WindowStyle = WindowStyle.ToolWindow;
            temp.UseLayoutRounding = true;
            
           */
            this.Width = 900;
            this.Height = 500;
            this.MinHeight = 500;
            this.MinWidth = 900;
            this.WindowStartupLocation=WindowStartupLocation.CenterScreen;
            this.WindowStyle = WindowStyle.None;


        }



        private void listView1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if ((sender != null) && (sender is ListView))
            {
                ListView tempItemsList = (ListView)sender;

                ((StoreDialogViewModel)this.DataContext).ShowItemSelectedInList(tempItemsList);


              //  btnSaveORUpdate.Content = "Update item";


                //dataContext.ShowItemSelectedInList(TempItem );
            }

        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
          //  Button tempButton = sender as Button;
            ((StoreDialogViewModel)this.DataContext).CurrentItemID = -3;

            this.Close();
         //   btnSaveORUpdate.Content = "Add New";

        }

        private void btnSaveORUpdate_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            /*
            if (((StoreDialogViewModel)this.DataContext).CurrentItemID <= 0)
            {
                if (MessageBoxResult.OK == MessageBox.Show("No Store Selected! Do you want to close", "No Store Selected", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation))
                {

                    this.Close();
                }
            
            }
             */ 
        }
/*
        private void btnSaveORUpdate_Click(object sender, RoutedEventArgs e)
        {
            ((StoreManageViewModel)this.DataContext).btnSaveOrUpdate();

            btnSaveORUpdate.Content = "Add New";
        }

        */
    }
    }

