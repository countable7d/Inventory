﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using Caliburn.Micro;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for DispatchTrackView.xaml
    /// </summary>
    public partial class DispatchTrackView : UserControl
    {
        public DispatchTrackView()
        {
            InitializeComponent();
        }


        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            Window temp = Window.GetWindow(this.Parent);
            temp.Height = 900;
            temp.Width = 1500;
            temp.ResizeMode = ResizeMode.NoResize;
            temp.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            temp.WindowStyle = WindowStyle.ToolWindow;
            temp.UseLayoutRounding = true;
            this.Width = 1500;
            this.Height = 950;
            this.MinHeight = 900;
            this.MinWidth = 1400;

           

            txtItemName.ItemsSource = ((DispatchTrackViewModel)this.DataContext).StoreItems;

            txtItemName.FilterMode = AutoCompleteFilterMode.Custom;

            txtItemName.ItemFilter = (txt, i) => ItemCategoryAutoComplete.IsAutoCompleteSuggestion(txt, i);
          //  txtItemName.AddHandler(AutoCompleteBox.DropDownClosingEvent, new RoutedEventHandler(txtItemName_DropDownClosed), false);
          //  txtItemName.AddHandler(AutoCompleteBox., new RoutedEventHandler(txtItemName_DropDownClosed), false);

        }

        

        private void txtItemName_DropDownClosed(object sender, RoutedEventArgs e)
        {
            

            if (txtItemName.Text.Trim() == "") { return; }
            if (sender is AutoCompleteBox)
            {

                if (txtItemName.SelectedItem == null)
                {


                    MessageBox.Show("No Item with quantity in Store Starts with " + txtItemName.Text.Trim() + "\r\n \r\n Please select a Valid Item", " Select a valid Item", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                    txtItemName.Text = "";
                }

                else
                {
                    txtItemName.Text = (((ItemCategory)txtItemName.SelectedItem).ItemName);
                 //   txtDefaultPrice.Text = (((ItemCategory)txtItemName.SelectedItem).DefaultPrice ?? 0).ToString();
                    int tempItemID=(((ItemCategory)txtItemName.SelectedItem).ItemTypeId ?? -1);;
                    ((DispatchTrackViewModel)this.DataContext).currentItemID = tempItemID;
                    ((DispatchTrackViewModel)this.DataContext).SetPurchases(tempItemID);
                }

            }
            e.Handled = true;
           
        }

        private void cmbPrevPurchasePrice_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            try
            {
                ComboBox tempBox = sender as ComboBox;
                if (tempBox.SelectedItem != null)
                {
                    decimal tempVal;
                    if (decimal.TryParse(tempBox.SelectedValue.ToString(), out tempVal))
                    {
                     //   txtPurchasePrice.Text = tempVal.ToString();

                        if (((DispatchTrackViewModel)this.DataContext).currentItemID > 0)
                        {
                            ((DispatchTrackViewModel)this.DataContext).SetDiscounts(tempVal, ((DispatchTrackViewModel)this.DataContext).currentItemID);
                            txtPercentage.Text = "5";
                            Decimal tempDiscount = 0;Decimal dispatchPrice=0;
                            if (decimal.TryParse(tempBox.SelectedValue.ToString(),out tempDiscount)){

                                if (((DispatchTrackViewModel)this.DataContext).convertPercentageToPrice("5", tempDiscount, out dispatchPrice))
                                {
                                    txtDispatchPrice.Text = dispatchPrice.ToString();
                                }
                                else
                                {
                                    txtDispatchPrice.Text = "N/A";

                                }
                            }

                        }

                    }
                    e.Handled = true;

                }
            }
            catch (Exception ex)
            {
                e.Handled = true;
            }
        }

        private void cmbPrevDiscounts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            


            bool validItem = false; int tempItemID;
            e.Handled = true;
            try
            {
                ComboBox tempBox = sender as ComboBox;

                if (txtItemName.Text.Trim() == "") { return; }

                if (txtItemName.SelectedItem == null)
                {
                    txtItemName.Text = "";

                    MessageBox.Show("Please select a Valid Item", "No Item Selected", MessageBoxButton.OK, MessageBoxImage.Error);
                    e.Handled = true;
                    return;

                }

                else
                {
                    txtItemName.Text = (((ItemCategory)txtItemName.SelectedItem).ItemName);
                    //   txtDefaultPrice.Text = (((ItemCategory)txtItemName.SelectedItem).DefaultPrice ?? 0).ToString();
                    tempItemID = (((ItemCategory)txtItemName.SelectedItem).ItemTypeId ?? -1);
                    if (((DispatchTrackViewModel)this.DataContext).currentItemID != tempItemID)
                    {
                        txtItemName.Text = "";

                        MessageBox.Show("Item selection has changed! select again a Valid Item to get proper prices(MRP) and discounts and quantity available", "No Item Selected", MessageBoxButton.OK, MessageBoxImage.Error);
                        e.Handled = true;
                        return;

                    }
                    else { validItem = true; }
                    //    ((DispatchTrackViewModel)this.DataContext).SetPurchases(tempItemID);
                }


                if (validItem && (cmbPrevPurchasePrice.SelectedValue!=null))
                {

                    decimal tempPurchaseVal = -1;
                    if (cmbPrevPurchasePrice.SelectedValue.ToString().ToUpper().Trim() != "N/A")
                    {
                        if (decimal.TryParse(cmbPrevPurchasePrice.SelectedValue.ToString(), out tempPurchaseVal))
                        {

                            if (tempBox.SelectedValue == null) return;
                            double tempVal;
                            if (tempBox.SelectedValue.ToString().ToUpper().Trim() != "N/A")
                            {
                                if (double.TryParse(tempBox.SelectedValue.ToString(), out tempVal))
                                {
                                    int QOHTempValue = ((DispatchTrackViewModel)this.DataContext).QOHForAnItem(tempItemID, tempPurchaseVal, tempVal);

                                    if (QOHTempValue >= 0)
                                    {

                                        txtQOH.Text = QOHTempValue.ToString();
                                    }
                                    else
                                    {

                                        txtQOH.Text = "No Quantity";

                                    }

                                    //   ((DispatchTrackViewModel)this.DataContext).SetDiscountsForItemPrice(

                                }

                                // ((DispatchTrackViewModel)this.DataContext).SetPurchases(tempItemID);

                                //   ((DispatchTrackViewModel)this.DataContext).SetDiscountsForItemPrice(

                            }

                        }
                    }

                }
            }

            catch (Exception ex)
            {

            }


        }

        private void btnRemovefromList_Click(object sender, RoutedEventArgs e)
        {
            e.Handled = true;
            if (listView1.Items.Count <= 0) return;
           if (listView1.SelectedItem!= null)

           {
               if (listView1.SelectedIndex >= 0)
               {

                   ((DispatchTrackViewModel)this.DataContext).listItems.RemoveAt(listView1.SelectedIndex);
               }
           }
           }

        private void btnShowStoreDialog_Click(object sender, RoutedEventArgs e)
        {
            StoreDialogViewModel StoreViewModel = new StoreDialogViewModel();

            SecurityValuesForApp.AppWindowManger.ShowDialog(StoreViewModel);

            if (StoreViewModel.CurrentItemID == -3) { return; }

            if (StoreViewModel.CurrentItemID <= 0) 
            {
                MessageBox.Show("No Store Selected!", "No Store Selected", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                

            }
            else{


                 ((DispatchTrackViewModel)this.DataContext).StoreID=   StoreViewModel.CurrentItemID ;
                txtStoreName.Text=StoreViewModel.txtStoreName;
            }
        }




        /*

        private void txtDispatchPrice_TextChanged(object sender, TextChangedEventArgs e)
        {
            e.Handled=true;
            if (txtDispatchPrice.Text.Trim() == "")
            {
                txtPercentage.Text = "";



            }

            Decimal discountvalue = -1;
            Decimal tempPurchasePrice=0;
            if (cmbPrevPurchasePrice.SelectedIndex<0) return ;
            if (((DispatchTrackViewModel)this.DataContext).currentItemID<0){

                MessageBox.Show("Select an Item before entering Dispatch Price","No Dispatch Item Selected",MessageBoxButton.OK,MessageBoxImage.Stop);
                return;
            }

            if ( Decimal.TryParse((string)cmbPrevPurchasePrice.SelectedValue,out tempPurchasePrice)){

                if (((DispatchTrackViewModel)this.DataContext).convertPriceToPercentage(txtDispatchPrice.Text.Trim(), tempPurchasePrice, out discountvalue))
                {

                    txtPercentage.Text = discountvalue.ToString();
                }
            }

        }
        */
        private void txtPercentage_TextChanged(object sender, TextChangedEventArgs e)
        {


            e.Handled = true;
            if (txtPercentage.Text.Trim() == "")
            {
                txtDispatchPrice.Text = "";



            }

            Decimal discountvalue = -1;
            Decimal tempPurchasePrice = 0;
            if (cmbPrevPurchasePrice.SelectedIndex < 0) return;
            if (((DispatchTrackViewModel)this.DataContext).currentItemID < 0)
            {
                if (txtItemName.Text != "") { 
                MessageBox.Show("Select an Item before entering Dispatch Price", "No Dispatch Item Selected", MessageBoxButton.OK, MessageBoxImage.Stop);
                return;
                }
            }

            if (Decimal.TryParse((string)cmbPrevPurchasePrice.SelectedValue, out tempPurchasePrice))
            {

                if (((DispatchTrackViewModel)this.DataContext).convertPercentageToPrice(txtPercentage.Text.Trim(), tempPurchasePrice, out discountvalue))
                {

                    txtDispatchPrice.Text = discountvalue.ToString();
                }
            }

        }

        private void cmbPrevPurchasePrice_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnclear_Click(object sender, RoutedEventArgs e)
        {
            ((DispatchTrackViewModel)this.DataContext).ClearForm();
        }

        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            ((DispatchTrackViewModel)this.DataContext).PrintItem();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            if ((((DispatchTrackViewModel)this.DataContext).isSaved) && (((DispatchTrackViewModel)this.DataContext).currentDispatchID>0))
            {

                if (((DispatchTrackViewModel)this.DataContext).confirmOperation())
                {
                    ((DispatchTrackViewModel)this.DataContext).CancelDispatchTrack();


                }

            }
        }

        private void btnGetDispatch_Click(object sender, RoutedEventArgs e)
        {
            ((DispatchTrackViewModel)this.DataContext).LoadDispatch();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            

            ((IConductor)(((DispatchTrackViewModel)this.DataContext).Parent)).ActivateItem(new FrontViewModel());
        }

        private void txtItemName_DropDownClosing(object sender, RoutedPropertyChangingEventArgs<bool> e)
        {
            txtItemName_DropDownClosed(sender, e);
        }
    
        }
    


    
}
