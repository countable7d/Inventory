﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using Caliburn.Micro;
using Caliburn;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for StoreManageView.xaml
    /// </summary>
    public partial class StoreManageView : UserControl
    {
        public StoreManageView()
        {
            InitializeComponent();
        }


        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            Window temp = Window.GetWindow(this.Parent);
            temp.Height = 900;
            temp.Width = 1500;
            temp.ResizeMode = ResizeMode.NoResize;
            temp.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            temp.WindowStyle = WindowStyle.ToolWindow;
            temp.UseLayoutRounding = true;
            this.Width = 1500;
            this.Height = 900;
            this.MinHeight = 800;
            this.MinWidth = 1400;


        }



        private void listView1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if ((sender != null) && (sender is ListView))
            {
                ListView tempItemsList = (ListView)sender;

                ((StoreManageViewModel)this.DataContext).ShowItemSelectedInList(tempItemsList);


                //  btnSaveORUpdate.Content = "Update item";


                //dataContext.ShowItemSelectedInList(TempItem );
            }

        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            ((StoreManageViewModel)this.DataContext).ClearForm();
         //   btnSaveORUpdate.Content = "Add New";

        }

        
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)(((StoreManageViewModel)this.DataContext).Parent)).ActivateItem(new FrontViewModel());
        }
/*
        private void btnSaveORUpdate_Click(object sender, RoutedEventArgs e)
        {
            ((StoreManageViewModel)this.DataContext).btnSaveOrUpdate();

            btnSaveORUpdate.Content = "Add New";
        }

        */
    }
}
