﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for DispatchReturnsView.xaml
    /// </summary>
    public partial class DispatchReturnsView : UserControl
    {
        public DispatchReturnsView()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            Window temp = Window.GetWindow(this.Parent);
            temp.Height = 900;
            temp.Width = 1500;
            temp.ResizeMode = ResizeMode.NoResize;
            temp.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            temp.WindowStyle = WindowStyle.ToolWindow;
            temp.UseLayoutRounding = true;
            this.Width = 1500;
            this.Height = 900;
            this.MinHeight = 800;
            this.MinWidth = 1400;

            //txtItemName.ItemsSource = ((DispatchTrackViewModel)this.DataContext).StoreItems;

            //txtItemName.FilterMode = AutoCompleteFilterMode.Custom;

            //txtItemName.ItemFilter = (txt, i) => ItemCategoryAutoComplete.IsAutoCompleteSuggestion(txt, i);
            //txtItemName.AddHandler(AutoCompleteBox.DropDownClosingEvent, new RoutedEventHandler(txtItemName_DropDownClosed), false);
            //  txtItemName.AddHandler(AutoCompleteBox., new RoutedEventHandler(txtItemName_DropDownClosed), false);

        }

        private void btnclear_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
