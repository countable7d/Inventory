﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;
using Caliburn.Micro;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for DispatchesReportView.xaml
    /// </summary>
    public partial class PurchaseReturnsReportView : UserControl
    {
        public PurchaseReturnsReportView()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            Window temp = Window.GetWindow(this.Parent);
            temp.Height = 900;
            temp.Width = 1500;
            temp.ResizeMode = ResizeMode.NoResize;
            temp.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            temp.WindowStyle = WindowStyle.ToolWindow;
            temp.UseLayoutRounding = true;
            this.Width = 1500;
            this.Height = 900;
            this.MinHeight = 800;
            this.MinWidth = 1400;

            txtItemName.ItemsSource = ((PurchaseReturnsReportViewModel)this.DataContext).StoreItems;

            txtItemName.FilterMode = AutoCompleteFilterMode.Custom;

            txtItemName.ItemFilter = (txt, i) => ItemCategoryAutoComplete.IsAutoCompleteSuggestion(txt, i);
            txtItemName.AddHandler(AutoCompleteBox.DropDownClosingEvent, new RoutedEventHandler(txtItemName_DropDownClosed), false);
            //  txtItemName.AddHandler(AutoCompleteBox., new RoutedEventHandler(txtItemName_DropDownClosed), false);



        }



        private void btnShowStoreDialog_Click(object sender, RoutedEventArgs e)
        {
            StoreDialogViewModel StoreViewModel = new StoreDialogViewModel();

            SecurityValuesForApp.AppWindowManger.ShowDialog(StoreViewModel);

            if (StoreViewModel.CurrentItemID == -3) { return; }

            if (StoreViewModel.CurrentItemID <= 0)
            {
                MessageBox.Show("No Store Selected!", "No Store Selected", MessageBoxButton.OK, MessageBoxImage.Exclamation);


            }
            else
            {


                ((PurchaseReturnsReportViewModel)this.DataContext).StoreID = StoreViewModel.CurrentItemID;
                txtStoreName.Text = StoreViewModel.txtStoreName;
            }
        }






        private void txtItemName_DropDownClosed(object sender, RoutedEventArgs e)
        {


            if (sender is AutoCompleteBox)
            {
                if (selectAll.IsChecked ?? false) { return; }

                if (txtItemName.SelectedItem == null)
                {
                    txtItemName.Text = "";

                    MessageBox.Show("Please select a Valid Item", "No Item Selected", MessageBoxButton.OK, MessageBoxImage.Error);

                }

                else
                {
                    txtItemName.Text = (((ItemCategory)txtItemName.SelectedItem).ItemName);
                    //   txtDefaultPrice.Text = (((ItemCategory)txtItemName.SelectedItem).DefaultPrice ?? 0).ToString();
                    int tempItemID = (((ItemCategory)txtItemName.SelectedItem).ItemTypeId ?? -1); ;
                    ((PurchaseReturnsReportViewModel)this.DataContext).currentItemID = tempItemID;

                }

            }
            e.Handled = true;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            ((PurchaseReturnsReportViewModel)this.DataContext).SearchDetails();
        }

        private void fromDate_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            e.Handled = true;

            if (((DatePicker)sender).SelectedDate != null)
            {

                ((PurchaseReturnsReportViewModel)this.DataContext).fromDate = ((DatePicker)sender).SelectedDate ?? DateTime.MinValue;


            }
        }

        private void toDate_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            e.Handled = true;

            if (((DatePicker)sender).SelectedDate != null)
            {

                ((PurchaseReturnsReportViewModel)this.DataContext).toDate = ((DatePicker)sender).SelectedDate ?? DateTime.MinValue;


            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)(((PurchaseReturnsReportViewModel)this.DataContext).Parent)).ActivateItem(new FrontViewModel());
        }

    }
}
