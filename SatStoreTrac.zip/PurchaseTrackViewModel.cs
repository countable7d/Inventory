﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using Caliburn.Micro;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;

namespace SatStoreTrac
{
    class PurchaseTrackViewModel: Screen
    {
        private PurchasesTrack CurrentTrack = null;
        private bool _isSaved = false;
        public int currentItemID=0;
        public bool isSaved { get { return _isSaved; } set { _isSaved = value; NotifyOfPropertyChange(() => isSaved); } }
        private string _txtItemName="" ;
        private string _txtDefaultPrice = "";
        private string _txtPurchasePrice = "";
        private string _txtQuantity = "";
        private string _txtRefNo = "";
        private string _txtNotes = "";
        private string _txtDiscount = "";
        public int currentPurchaseID = -1;
        private string _txtDate = "";
        private string _txtPurchaseID = "";
        public string txtPurchaseID { get { return _txtPurchaseID; } set { _txtPurchaseID = value; NotifyOfPropertyChange(() => txtPurchaseID); } }
        public string txtDate { get { return _txtDate; } set { _txtDate = value; NotifyOfPropertyChange(() => txtDate); } }
        public string txtRefNo { get { return _txtRefNo; } set { _txtRefNo = value; NotifyOfPropertyChange(() => txtRefNo); } }
        public string txtNotes { get { return _txtNotes; } set { _txtNotes = value; NotifyOfPropertyChange(() => txtNotes); } }
        public string onetxtItemName { get { return _txtItemName; } set { _txtItemName = value; NotifyOfPropertyChange(() => onetxtItemName); } }
        public string txtDefaultPrice { get { return _txtDefaultPrice; } set { _txtDefaultPrice = value; NotifyOfPropertyChange(() =>  txtDefaultPrice); } }
        public string txtQuantity { get { return _txtQuantity; } set { _txtQuantity = value; NotifyOfPropertyChange(() => txtQuantity); } }
        public string txtPurchasePrice { get { return _txtPurchasePrice; } set { _txtPurchasePrice = value; NotifyOfPropertyChange(() => txtPurchasePrice); } }
        public string txtDiscount { get { return _txtDiscount; } set { _txtDiscount = value; NotifyOfPropertyChange(() => txtDiscount); } }
        public List<ItemCategory> itemsDB = new List<ItemCategory>();
        public List<ItemsTrack> registerDB = new List<ItemsTrack>();
        private string _txtItemID = "";
        public string txtItemID { get { return _txtItemID; } set { _txtItemID = value; NotifyOfPropertyChange(() => txtItemID); } }
        public ObservableCollection<ItemCategoryWithDiscount> _listItems = new ObservableCollection<ItemCategoryWithDiscount>();

        public ObservableCollection<ItemCategoryWithDiscount> listItems { get { return _listItems; } set { _listItems = value; NotifyOfPropertyChange(() => listItems); } }

        public ObservableCollection<ItemCategory> _StoreItems = new ObservableCollection<ItemCategory>();

        public ObservableCollection<ItemCategory> StoreItems { get { return _StoreItems; } set { _StoreItems = value; } }
        public ItemCategory currentItemCategory = null;
        public bool enableSave { get {return !isSaved;} set { isSaved = !value; NotifyOfPropertyChange(() => enableSave); }}
        public ObservableCollection<string> PreviousPurchases { get { return _PreviousPurchases; } set { _PreviousPurchases = value; } }
        public ObservableCollection<string> _PreviousPurchases = new ObservableCollection<string>();
        public ObservableCollection<string> PreviousDiscounts { get { return _PreviousDiscounts; } set { _PreviousDiscounts = value; } }
        public ObservableCollection<string> _PreviousDiscounts = new ObservableCollection<string>();
        private ItemCategory _selectedStoreItem;
        public ItemCategory selectedStoreItem { get { return _selectedStoreItem; } set { _selectedStoreItem = value; NotifyOfPropertyChange(() => selectedStoreItem); } }
        private int _SelectedIndexPurchasePrice;
        private int _SelectedIndexDiscount;
        public int SelectedIndexDiscount { get { return _SelectedIndexDiscount; } set { _SelectedIndexDiscount = value; NotifyOfPropertyChange(() => SelectedIndexDiscount); } }
        public void setSlectionforSelectedID()
        {
            var tempcategory = itemsDB.Where(x => x.ItemTypeId == currentItemID).FirstOrDefault();
            if (tempcategory != null) { onetxtItemName = (tempcategory.ItemName == null) ? "" : tempcategory.ItemName; }


        }







        public void LoadDispatch()
        {

            try
            {

                if (txtPurchaseID.Trim() == "")
                {

                    MessageBox.Show("Enter Id ", "ID Cannot Be Empty", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }
                int DispatchID = -1;
                if (!int.TryParse(txtPurchaseID.Trim(), out DispatchID))
                {
                    MessageBox.Show("ID is not an number ", "ID has to be an integer", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;


                }

                if (DispatchID <= 0)
                {
                    MessageBox.Show("ID Should be an positive number ", "ID has to be Positive number", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;


                }

                PurchasesTrack TrackToGet = new PurchasesTrack() { Id = DispatchID };
                StoreData storeToGet = new StoreData();

                List<StoreItemsDTO> tempItems = PurchaseTrackService.GetItems(ref TrackToGet, out storeToGet);


                if (TrackToGet == null)
                {

                    MessageBox.Show("No Item  with the ID  " + DispatchID.ToString(), "NO Item", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;

                }

                ClearForm();
                CurrentTrack = TrackToGet;
                isSaved = true;
                txtItemID = (CurrentTrack.Id ?? -1).ToString();
                txtNotes = TrackToGet.Notes ?? "";
                txtRefNo = TrackToGet.PurchaseRef ?? "";
                txtDate = (TrackToGet.PurchasedDate ?? DateTime.Now).ToLongDateString();
                List<ItemCategoryWithDiscount> tempItemsSrc = tempItems.Select(src=>  new ItemCategoryWithDiscount() { DefaultPrice = ((double?)src.PurchasePrice), Discount = src.Discount, ItemName=src.ItemName, ItemTypeId=src.ItemTypeRef, ROL=src.Quantity } ).ToList<ItemCategoryWithDiscount>();
                listItems = new ObservableCollection<ItemCategoryWithDiscount>(tempItemsSrc);

            }

            catch (Exception ex)
            {
                MessageBox.Show("Error gettting Data! Try restart Application", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }












      public  bool confirmOperation()
        {

            if (!isSaved) { MessageBox.Show("No Active Record \r\n Save or Get a Dispatch Item to Cancel ", "No Active Record", MessageBoxButton.YesNo, MessageBoxImage.Exclamation); return false; }

            if (MessageBoxResult.Yes == MessageBox.Show("The Current Purchase Record will be canceled \r\n To DO You want to Proceed?", "Proceed with Caution", MessageBoxButton.YesNo, MessageBoxImage.Question))
            {
                LoginViewModel TempLogin = new LoginViewModel(true);
                SecurityValuesForApp.AppWindowManger.ShowDialog(TempLogin);

                return TempLogin.LoginSuccess;



            }


            return false;


        }






      public void CancelPurchaseTrack()
      {
          try
          {

              Mouse.OverrideCursor = Cursors.Wait;
              StateOfOperation tempState = StoresService.DeletePurchaseTrack(CurrentTrack);


              if (tempState == StateOfOperation.Success)
              {

                  MessageBox.Show("Successfully cancelled Purchase/Incoming Transaction with ID: " + CurrentTrack.Id.ToString(), " Success", MessageBoxButton.OK, MessageBoxImage.Information);

                  ClearForm();
              }
              else if (tempState == StateOfOperation.CannotCancelPurchase)
              {

                  MessageBox.Show("Cannot cancel Purchase/Incoming Transaction with ID: " + CurrentTrack.Id.ToString() + "\r\n Because there are dispatches on this Transaction", " Cannot Cancel", MessageBoxButton.OK, MessageBoxImage.Exclamation);



              }
              else
              {
                  MessageBox.Show("Cannot cancel Purchase/Incoming Transaction with ID: " + CurrentTrack.Id.ToString() + "\r\n Because there are no Store Items related to this ID", " Cannot Cancel", MessageBoxButton.OK, MessageBoxImage.Exclamation);


              }

          }
          catch (Exception)
          {

              MessageBox.Show("Unexpected error Try Restarting App", " restart App", MessageBoxButton.OK, MessageBoxImage.Error);
          }

          finally
          {

              Mouse.OverrideCursor = null;

          }
      }









        public int SelectedIndexPurchasePrice
        {
            get
            {
                return _SelectedIndexPurchasePrice;
            }
            set
            {
                _SelectedIndexPurchasePrice = value;
                NotifyOfPropertyChange(() => SelectedIndexPurchasePrice);
            }
        }
        public List<string> cmbPrevPurchasePrice
        {
            get
            {
                // silly example of the collection to bind to
                return new List<string>(PreviousPurchases);
            }
            private set
            {
                
                if (value != null)
                {

                    PreviousPurchases = new ObservableCollection<string>(value);
                    NotifyOfPropertyChange(() => cmbPrevPurchasePrice);
                   if (PreviousPurchases.Count>0){
                       SelectedIndexPurchasePrice = 0;
                       Decimal tempDiscount = -1;

                       if (decimal.TryParse(PreviousPurchases[0], out tempDiscount))
                       {
                           SetDiscounts(tempDiscount, currentItemID);

                       }
                    }

                }
                
            }

        }
        public void SetDiscounts(Decimal prevPurchasePrice, int tempItemID){

            List<string> prevDiscounts = registerDB.Where(x => x.ItemsCategoryID ==tempItemID  && x.InStoreID == 0 && x.ItemPrice==prevPurchasePrice).OrderBy(x => x.ItemPrice).GroupBy(x => x.Discount).Select(x => x.Key.ToString()).ToList<string>();

            if (prevDiscounts == null)
            {
                prevDiscounts = new List<string>();
                prevDiscounts.Add("N/A");


            }

            else
            {
                if (prevDiscounts.Count <= 0)
                {
                    prevDiscounts.Add("N/A");


                }
            }

           PreviousDiscounts.Clear();
           PreviousDiscounts = new ObservableCollection<string>(prevDiscounts);
           cmbPrevDiscounts = PreviousDiscounts.ToList<string>();


        }

        public List<string> cmbPrevDiscounts
        {
            get
            {
                // silly example of the collection to bind to
                return new List<string>(PreviousDiscounts);
            }
            private set
            {

                if (value != null)
                {

                    PreviousDiscounts = new ObservableCollection<string>(value);
                    NotifyOfPropertyChange(() => cmbPrevDiscounts);
                    if (PreviousDiscounts.Count > 0)
                    {
                        SelectedIndexDiscount = 0;
                    }

                }

            }

        }




        private string _selectedcmbPrevPurchasePrice;
        public string SelectedcmbPrevPurchasePrice
        {
            get { return _selectedcmbPrevPurchasePrice; }
            set
            {
                _selectedcmbPrevPurchasePrice = value;
                NotifyOfPropertyChange(() => SelectedcmbPrevPurchasePrice);
                // and do anything else required on selection changed
            }
        }

        public void ClearForm(){
            itemsDB = ItemsService.GetRegisterAndItems(out registerDB);

            StoreItems = new ObservableCollection<ItemCategory>(itemsDB);
            listItems.Clear();
            txtNotes = "";
            txtRefNo = "";
            txtDate = DateTime.Now.Date.ToLongDateString();
            ClearAddList();
            isSaved = false;
            CurrentTrack = null;
            txtItemID = "Add New..";

        }

        public void PrintItem()
        {


            if (!isSaved)
            {


                MessageBox.Show("Before printing an Item Please save the Item or Retrive an item", "Save or Get an Item To print", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }
            try
            {
                PrinterService.MakePrintPurchase(listItems.ToList<ItemCategoryWithDiscount>(), new StoreData(), CurrentTrack);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Printing! Try Restart Application", "Restart", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                
            }
        }

        public void btnSaveOrUpdate(RoutedEventArgs e)
        {
            int Tempint = -2;
            e.Handled = true;
            if (isSaved)
            {

                MessageBox.Show("Information already Saved. To add more items Clear form ", "Information", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (listItems.Count <= 0)
            {

                MessageBox.Show("No Items to save", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
               
                PurchasesTrack tempPurchaseTrack = new PurchasesTrack() { Notes = txtNotes, PurchaseRef = txtRefNo, PurchasedDate = DateTime.Now };

                var tempStoreItems = listItems.Select((src) => new StoreItems() { DispatchPrice = 0, InStore_Or_Dispatched = "P", InStoreID = 0, ItemTypeRef = src.ItemTypeId, PurchasePrice = (Decimal?)src.DefaultPrice, QOH = (int?)src.ROL, Quantity = (int?)src.ROL ,Discount=(double?)src.Discount}).ToList<StoreItems>();


                if ((Tempint=(new PurchaseTrackService()).CreatePurchaseTrack(ref tempPurchaseTrack, tempStoreItems)) != 0) { throw new Exception(); }
                MessageBox.Show("Items added successfully", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                CurrentTrack = tempPurchaseTrack;
                txtItemID = (CurrentTrack.Id ?? -1).ToString();
                isSaved = true;
                currentPurchaseID = tempPurchaseTrack.Id ?? 0;
               // ClearForm();
            }
            catch (Exception ex) {

                if (Tempint < 0)
                {

                    MessageBox.Show("Error in adding Items ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    MessageBox.Show("Error clearing the Form \r\n But Items are Saved successfully to DataBase", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                }
            
            }
            finally
            {

                Mouse.OverrideCursor = null;

            }


        }

        public PurchaseTrackViewModel()
        {

            /*
            itemsDB = ItemsService.GetRegisterAndItems(out registerDB);
            
            StoreItems= new ObservableCollection<ItemCategory>(itemsDB);

            ClearAddList();
             * 
             * /
             */
            ClearForm();
        }
        
        

        public void ClearAddList()
        {
            PreviousPurchases = new ObservableCollection<string>();
            PreviousPurchases.Add("N/A");
            cmbPrevPurchasePrice = PreviousPurchases.ToList<string>();
            PreviousDiscounts = new ObservableCollection<string>();
            PreviousDiscounts.Add("N/A");
            cmbPrevDiscounts = PreviousDiscounts.ToList<string>();
            currentItemID = -1;
            currentItemCategory = null;
            txtDefaultPrice = "";
            txtDiscount = "";
            txtPurchasePrice = "";
            txtQuantity = "";
            onetxtItemName = "";
            txtDate = DateTime.Now.Date.ToLongDateString();
           
        }

        public  void SetPurchases(int ItemID){

            List<string> prevPurchases = registerDB.Where(x => x.ItemsCategoryID == ItemID && x.InStoreID==0).OrderBy(x=>x.ItemPrice).GroupBy(x=>x.ItemPrice).Select(x => x.Key.ToString() ).ToList<string>();

            if (prevPurchases == null)
            {
                prevPurchases= new List<string>();
                prevPurchases.Add("N/A");

                
            }

            else
            {
                if (prevPurchases.Count <= 0)
                {
                    prevPurchases.Add("N/A");
                   

                }
            }

            PreviousPurchases.Clear();
            PreviousPurchases = new ObservableCollection<string>(prevPurchases);
            cmbPrevPurchasePrice = PreviousPurchases.ToList<string>();
            Decimal tempPrice=0;
            if (decimal.TryParse(PreviousPurchases[0], out tempPrice))
            {
                SetDiscounts(tempPrice, ItemID);
            }
            else
            {
                cmbPrevDiscounts = new List<string> { "N/A" };

            }
        }


        public void AddPurchaseItem(RoutedEventArgs e )
        {
            ItemCategoryWithDiscount selectedItem = null;
            e.Handled = true;

            if (isSaved) { MessageBox.Show("Item already saved. To save New Item Clear form ", "Already Saved", MessageBoxButton.OK, MessageBoxImage.Information); return; }
            if (validateItem(out selectedItem))
            {
                if (ShowConfirmDialog(selectedItem)!=null)
                {

                    listItems.Add(selectedItem);
                    ClearAddList();

                }

            }
          
        }

        private ItemCategory ShowConfirmDialog(ItemCategory itemValue)
        {
            int TempId = itemValue.ItemTypeId??currentItemID;

            var getItem = StoreItems.Where(x => x.ItemTypeId == TempId).FirstOrDefault();
            if (getItem == null)
            {
                MessageBox.Show("Not a ValidItem Selected, select the Item again", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                
                return null;

            }

            string confirmMessage = "The Item : " + getItem.ItemName + "\r\n" + " With Purchase Price : " + (itemValue.DefaultPrice ?? 0).ToString() + "\r\n and Quantity: " + ((Decimal)(itemValue.ROL ?? 0)).ToString() + " will be added to list ";
            if (MessageBoxResult.Cancel == MessageBox.Show(confirmMessage, "Confirm or Cancel to add the item to Purchase list", MessageBoxButton.OKCancel, MessageBoxImage.Question)) return null;
            itemValue.ItemName = getItem.ItemName;
            return itemValue;
        }

        private bool validateItem(out ItemCategoryWithDiscount TempItem)
        {
            TempItem = new ItemCategoryWithDiscount();
            StringBuilder str = new StringBuilder();
            try
            {

                


                if ( currentItemID<=0)
                {
                    str.Clear();
                    str.Append("No valid Item Selected to add");
                    throw new Exception();


                }



                if (onetxtItemName.Trim() == "")
                {


                    str.Clear();
                    str.Append("No valid Item Selected to add");
                    throw new Exception();
                }

                if (txtPurchasePrice.Trim() == "")
                {


                    str.Clear();
                    str.Append("Purchase price cannot be empty");
                    throw new Exception();
                }

                if (txtQuantity.Trim() == "")
                {


                    str.Clear();
                    str.Append("Quantity cannot be empty, Enter Quantity");
                    throw new Exception();
                }

                if (txtDiscount.Trim() == "")
                {


                    str.Clear();
                    str.Append("Discount cannot be empty, Enter Discount betweeen 0 and 100");
                    throw new Exception();
                }

                str.Append("Default Price should be a Money and Decimal value");
                NumberStyles style = NumberStyles.AllowDecimalPoint;
                Decimal DefaultPrice;

                // defaultprice is denoting purchase price here

                DefaultPrice = decimal.Parse(txtPurchasePrice.Trim(), style);
              
                if ((DefaultPrice <= 0))
                {

                    str.Clear();
                    str.Append("Default price cannot be negative or zero");
                    throw new Exception();
                }

                if (DefaultPrice.ToString().Count(x => x == '.') > 1)
                {

                    str.Clear();
                    str.Append("Purchase price cannot have more than two decimals points");
                    throw new Exception();

                }

                if ((DefaultPrice.ToString().Contains(".")) && ((DefaultPrice.ToString().Length - (DefaultPrice.ToString().IndexOf(".") + 1)) > 2))
                {


                    str.Clear();
                    str.Append("Purchase price is money, cannot have more than two digits after decimal");
                    throw new Exception();
                }

                Double Discount=-1;
                if (!double.TryParse(txtDiscount.Trim(), out Discount))
                {
                    str.Clear();
                    str.Append("Only Numbers are allowed for Discount Price");
                    throw new Exception();
                }

                if ((Discount<0) || (Discount>100))
                {
                    str.Clear();
                    str.Append("Discount Value should be between 0 and 100");
                    throw new Exception();
                }


                



                str.Clear();
                str.Append("quantity is not valid number");

                // ROL denotes quantity
                int  ROLForItem = int.Parse(txtQuantity.Trim());

                if ((ROLForItem <= 0))
                {

                    str.Clear();
                    str.Append("Quantity cannot be negative or zero and cannot have decimals");
                    throw new Exception();
                }

                /*
                if ((ROLForItem.ToString().Contains(".")) && ((ROLForItem.ToString().Length - (ROLForItem.ToString().IndexOf(".") + 1)) > 0))
                {


                    str.Clear();
                    str.Append("Purchase price cannot have more than two decimals");
                    throw new Exception();
                }

                */

                TempItem.DefaultPrice =(double) DefaultPrice;
                TempItem.ItemTypeId = currentItemID;
                TempItem.ItemName = onetxtItemName;
                TempItem.ROL = ROLForItem;
                TempItem.Discount = Discount;
                // BEGIN HERE

                return true;
            }

            catch (Exception ex)
            {
                MessageBox.Show(str.ToString(), "Error Saving Item record", MessageBoxButton.OK, MessageBoxImage.Error);


                return false;
            }

            //   return false;

        }

    
    }
}
