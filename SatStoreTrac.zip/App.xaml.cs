﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using ActivityDB;
using NHibernate;
using FluentNHibernate;
using System.IO;

// remove after

using FluentNHibernate.Mapping;
using System.Text;
using System.Data.SQLite;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using FluentNHibernate.Automapping;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using NHibernate.Criterion;
using NHibernate.Linq;
using ActivityDB.EntityLayer;
using FluentNHibernate.Automapping.Alterations;
using SatStoreTrac;
using System.Threading;




namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        Mutex m;

        public App()
        {


            bool isnew;
            m = new Mutex(true, @"Global\SatishJeevanVani1968", out isnew);
            if (!isnew)
            {
                
                System.Environment.Exit(-2);
            }      


            SecurityValuesForApp.adminmode = true;
            SecurityValuesForApp.isLoggedIn = true;
            SecurityValuesForApp.Normalmode = true;

            string appBaseDir = System.AppDomain.CurrentDomain.BaseDirectory;
            DataFactory Temp = new DataFactory( appBaseDir + @".\Stores1.s3db", false);
            SecurityValuesForApp.AppDataFactory = Temp.CreateStoreSessionFactory();
            SecurityValuesForApp.UserData = ItemsService.GetUserData();
            
          
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            

            LoginViewModel TempLogin = new LoginViewModel();
            SecurityValuesForApp.AppWindowManger.ShowDialog(TempLogin);
            if (!TempLogin.LoginSuccess)
            {

                MessageBox.Show("Error Authentication! closing application", "Login Failed", MessageBoxButton.OK, MessageBoxImage.Error);

                Application.Current.Shutdown(-1);

            }

            else
            {
                SecurityValuesForApp.adminmode = TempLogin.isAdminMode;
                MessageBox.Show("Successfully logged in", "Log in Success", MessageBoxButton.OK, MessageBoxImage.Information);

            }
        
        }

    }
}
