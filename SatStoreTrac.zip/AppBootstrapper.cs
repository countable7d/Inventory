﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Caliburn.Micro;
using System.Windows;


namespace SatStoreTrac
{
    

        public class AppBootstrapper : BootstrapperBase 
        {

            public AppBootstrapper()
        {
           // Initialize();
            Initialize();
            SecurityValuesForApp.AppWindowManger = new WindowManager();
        }

        protected override void OnStartup(object sender, StartupEventArgs e)
        {
            DisplayRootViewFor<MainScreenRootViewModel>();
            
        }
        
        
        
        }
    
}
