﻿using FluentNHibernate;
using FluentNHibernate.Mapping;
using NHibernate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SQLite;
using System.Data;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using FluentNHibernate.Automapping;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using NHibernate.Criterion;
using NHibernate.Linq;
using System.IO;
using FluentNHibernate.Automapping.Alterations;


namespace ActivityDB
{

    /// <summary>
    /// Data Factory and Data Repository Object(Data Repository depends on DataFactory
    ///
    /// </summary>


    #region Data Factory

    public   class DataFactory
    {
        string _dbFile = string.Empty;
        bool _overwriteExisting = false;
        Configuration config = null;
    public  DataFactory(string dbFile, bool overwriteExisting)
    {
        _dbFile = dbFile;
        _overwriteExisting = overwriteExisting;
        
    }
       
    public ISessionFactory CreateStoreSessionFactory()
    {
         try
        {

    return    Fluently.Configure()
    .Database(SQLiteConfiguration.Standard.UsingFile(_dbFile))
    .Mappings(m => m.FluentMappings.AddFromAssemblyOf<DataFactory>())

    .ExposeConfiguration(c =>
    {
        config = c; //pass configuration to class scoped variable
    })
    .BuildSessionFactory();
        }
         catch (Exception Ex)
         {

             throw Ex;
         }
    }
    public ISessionFactory CreateSessionFactory()
    {
        try
        {
            return Fluently.Configure()
                .Database(
                 
                    SQLiteConfiguration.Standard.UsingFile(_dbFile)
                )
                .Mappings(m =>
                {
                  //  m.FluentMappings.AddFromAssemblyOf<DataFactory>().UseOverridesFromAssemblyOf<DataFactory>();
                    m.FluentMappings.AddFromAssemblyOf<DataFactory>();
               //  m.AutoMappings.Add(   AutoMap.AssemblyOf<DataFactory>().UseOverridesFromAssemblyOf<DataFactory>());

                
      // your automapping setup here
       } )
                 .ExposeConfiguration(BuildSchema).BuildSessionFactory();
        }
        catch (Exception Ex)
        {

            throw Ex;
        }
        }
 
    private void BuildSchema(Configuration config)
    {
        if (_overwriteExisting)
        {
            if (File.Exists(_dbFile)) File.Delete(_dbFile);
 
            var se = new SchemaExport(config);
            se.Create(false, true);
        }
    }
}

#endregion

    /// <summary>
    /// Add overide mapping classes
    /// </summary>




    /*
public static class OcDataRepository
{
    public static void Create(string dbFile)
    {
        DataFactory df = new DataFactory(dbFile, true);
        using (var sf = df.CreateSessionFactory())
        {
            sf.Close();
        }
    }
    public static UserEntity GetUserEntity(string dbFile,string UserID)
    {

        DataFactory df = new DataFactory(dbFile, false);
        using (var sf = df.CreateSessionFactory())
        using (var session = sf.OpenSession())
        
        {

            return (UserEntity)session.Get("UserEntity", UserID);
            
        }

    }
    public static void AddUserEntity(string dbFile, UserEntity SaveUser)
    {
        DataFactory df = new DataFactory(dbFile, false);
        using (var sf = df.CreateSessionFactory())
        using (var session = sf.OpenSession())
        using (var trans = session.BeginTransaction())
        {
            // session.SaveOrUpdate(project.Author);
            session.SaveOrUpdate(SaveUser);
            trans.Commit();
        }
    }

    // Need to changes

//    public static IList<UserEntity> QueryUserEntity(string dbFile, UserEntity SaveUser, string LinqWhereClause)
//    {
//        DataFactory df = new DataFactory(dbFile, false);
//        using (var sf = df.CreateSessionFactory())
//        using (var session = sf.OpenSession())
//       // using (var trans = session.BeginTransaction())
        

//       var linq = (from product in session.Query<UserEntity>()
//            where + LinqWhereClause +
//            orderby product.Id
//            select product);
//var list4 = linq.ToList();
       
       
//    }

    public static UserEntity GetUserWithId(string dbFile, string WithUserName)
    {

        DataFactory df = new DataFactory(dbFile, false);
        var sf1 = df.CreateSessionFactory();

        using (var sf = sf1.OpenSession())
        {

            // session.SaveOrUpdate(project.Author);
            //  UserEntity Tempadd1 = (UserEntity)sf.Get("UserEntity", WithUserName);

            //      Assert.AreEqual(Tempadd1.UserName,Add1.UserName);
            //Assert.IsInstanceOf<DateTime>(Tempadd1.DateCreated);
            UserEntity Tempadd1 = (from UserExists in sf.Query<UserEntity>()
                                   where UserExists.UserName.ToUpper().Trim() == WithUserName.Trim().ToUpper()
                                   select UserExists).FirstOrDefault<UserEntity>();

            //         trans.Commit();

            return Tempadd1;


        }

    }

    public static void DeleteUserEntity(string dbFile, UserEntity SaveUser)
    {
        DataFactory df = new DataFactory(dbFile, false);
        using (var sf = df.CreateSessionFactory())
        using (var session = sf.OpenSession())
        using (var trans = session.BeginTransaction())
        {
             // session.SaveOrUpdate(project.Author);
            session.Delete(SaveUser);
            trans.Commit();
        }
    }




}
    #endregion Data Factory
[Serializable]
    //Not used currently
//public class TwoPartIdentifier
//{
//    public virtual string ID1 { get; set; }
//    public virtual string ID2 { get; set; }

//    public override bool Equals(object obj)
//    {
//        if (obj == null)
//            return false;
//        var t = obj as TwoPartIdentifier;
//        if (t == null)
//            return false;
//        if (ID1 == t.ID1 && ID2 == t.ID2)
//            return true;
//        return false;
//    }
//    public override int GetHashCode()
//    {
//        return (ID1 + "|" + ID2).GetHashCode();
//    }
//}

/// <summary>
/// Users Profile,Task,Followlist(followers of task), Subscribers to a task Tables with NHibernate 
/// and maps
/// </summary>
     */ 

#region stotertrackerMaps

   
   //TODO: SEP 17 DESIGN DTO for reports Purchase and Dispatch and PR





    public class ItemCategory
    {

        public virtual int? ItemTypeId { get; set; }
        public virtual double? DefaultPrice { get; set; }
        public virtual double? ROL { get; set; }
        public virtual string ItemName { get; set; }
        
        
    }

    public class ItemCategoryWithDiscount : ItemCategory
    {

        public virtual double? Discount { get; set; }

    }


    //Used to populate PurchaseReturns from HQL query

    public class PurchaseReturnsForDispatch
    {

        public virtual int ItemType { get; set; }
        public virtual decimal Price { get; set; }
        public virtual long QOH { get; set; }
        public virtual string ItemCategoryName { get; set; }
        public virtual decimal Discount { get; set; }




    }

    public class ItemCategoryAutoComplete : ItemCategory
    {

        public static bool IsAutoCompleteSuggestion(string search, object item)
        {

            ItemCategory itemSelected = item as ItemCategory;

            if (itemSelected != null)
            {

                search = search.ToUpper();

                return (itemSelected.ItemName.ToUpper().StartsWith(search) );

            }

            else
            {

                return false;

            }

        }
 

        public override string ToString()
        {

            return ItemName;
        }

    }

public class StoreItems
    {

        public virtual int? ItemID {get;  set;}
        public virtual int? ItemTypeRef {get;set;}
    
    
    public virtual decimal? PurchasePrice { get; set; }
    public virtual decimal? DispatchPrice { get; set; }
        public virtual string InStore_Or_Dispatched {get;set;}
        public virtual int? Quantity { get; set; }
        public virtual int? QOH { get; set; }
        
    public virtual int? InStoreID {get;  set;}
       
            public virtual int? PurchaseID {get;  set;}
            public virtual double? Discount { get; set; }
          
        


    }


public class StoreItemsDTO
{

    public virtual int? ItemID { get; set; }
    public virtual int? ItemTypeRef { get; set; }


    public virtual decimal? PurchasePrice { get; set; }
    public virtual decimal? DispatchPrice { get; set; }
    public virtual string InStore_Or_Dispatched { get; set; }
    public virtual int? Quantity { get; set; }
    public virtual int? QOH { get; set; }

    public virtual int? InStoreID { get; set; }

    public virtual int? PurchaseID { get; set; }
    public virtual double? Discount { get; set; }

    public virtual string ItemName { get; set; }


}

public enum StateOfOperation { Success = 0, GeneralFailure, RegisterCorrupted, NotEnoughDispatchItems, DataBaseError,ItemNotFound,CannotCancelDispatch,CannotCancelPurchase };



public class DispatchReportDTO
{

    public virtual string ItemName { get; set; }
    public virtual int? ItemTypeId { get; set; }
    public virtual decimal? DefaultPrice { get; set; }
    public virtual long? ROL { get; set; }
    
    public virtual decimal? Discount { get; set; }


}

public class PurchaseReportDTO
{

    public virtual string ItemName { get; set; }
    public virtual int? ItemTypeId { get; set; }
    public virtual decimal? DefaultPrice { get; set; }
    public virtual long? ROL { get; set; }
    
    public virtual double? Discount { get; set; }


}


public class PurchaseReturnsReportDTO
{

    public virtual string ItemName { get; set; }
    public virtual int? ItemTypeId { get; set; }
    public virtual decimal? DefaultPrice { get; set; }
    public virtual long? ROL { get; set; }
   
    public virtual decimal? Discount { get; set; }



}

public class DispatchHistory
{

    public virtual int? OutStoreID { get; set; }
    public virtual int? ID { get; set; }
    public virtual int? ItemId { get; set; }
    public virtual int? DispatchID { get; set; }
    public virtual int? quantity { get; set; }
    public virtual Decimal? DispatchPrice { get; set; }

     public virtual Decimal? PriceOut { get; set; }
    public virtual Decimal?  Percenatge { get; set; }
    public virtual int? initQuantity { get; set; }
    

}


  public class  DispatchTrack {
       public virtual int? Id {get;  set;}
            public virtual string Notes {get;  set;}
            public virtual DateTime? DispatchedDate { get; set; }
            public virtual string DisPatchRef { get; set; }
}

  public class PurchasesTrack
  {
      public virtual int? Id { get; set; }
      public virtual string Notes { get; set; }
      public virtual DateTime? PurchasedDate { get; set; }
      public virtual string PurchaseRef { get; set; }



  }

  public class PurchasesReturns
  {
      public virtual int? ID { get; set; }
      public virtual int? DispatchHistoryID { get; set; }
      public virtual DateTime? ReturnDate { get; set; }
      public virtual int? Quantity { get; set; }
      public virtual int? ItemID { get; set; }
     

  }


  public class PinData
  {
      public virtual int ID { get; set; }
      public virtual string UserType { get; set; }
      public virtual string UserString { get; set; }
       

  }

  public class ItemsTrack
  {
      public virtual int? Id { get; set; }
      public virtual int? ItemsCategoryID { get; set; }

      public virtual Decimal? ItemPrice { get; set; }

      public virtual int? QOH { get; set; }
      public virtual double? Discount { get; set; }

      public virtual int? InStoreID { get; set; }


  }

    // To be used to store dispatch items in Dispatch order

  public class DispatchItems
  {
      public virtual int? ItemCategoryID { get; set; }

      public virtual Decimal? ItemPrice { get; set; }

      // QOH represents qunatity to be dispatched

      public virtual int? QOH { get; set; }

      public virtual int? InStoreID { get; set; }

      // out discount

      public virtual Decimal? Percenatge { get; set; }

      public virtual Decimal? PriceOut { get; set; }

      public virtual double? inDiscount { get; set; }


      public virtual Decimal? DispatchPrice { get; set; }

      public virtual int? OutStoreID { get; set; }

 



  }

  public class DispatchItemsWithItemName : DispatchItems
  {

      public virtual string ItemName { get; set; }

  }


   public class StoreData{ 
       
       public virtual int? StoreId {get; set;}
       public virtual string StoreName {get;set;}
        public virtual string StoreLocation {get;set;}
        public virtual string Address {get;set;}
        public virtual string StoreType {get;set;}
        public virtual string StorePhone { get; set; }
    
}

   public class StorePrintHeader
   {

       public virtual int? lineNo { get; set; }
       public virtual string line { get; set; }


   }



   public class StorePrintHeaderMap : ClassMap<StorePrintHeader>
   {

       public StorePrintHeaderMap()
       {
           Table("StorePrintHeader");

           Id(x => x.lineNo);
           Map(x => x.line);
       }


   }
    // Task Table Table with NHibernate

   public class PurchaseReturnsMap : ClassMap<PurchasesReturns>
   {

       public PurchaseReturnsMap()
       {
           Table("PurchaseReturn");

           Id(x=>x.ID).GeneratedBy.Increment();
           Map(x => x.DispatchHistoryID);
           Map(x => x.ItemID);
           Map(x => x.Quantity);
           Map(x => x.ReturnDate);
           
       }

   }

   public class ItemsTrackMap : ClassMap<ItemsTrack>
   {
       public ItemsTrackMap(){
           Table("ItemsTrack");
           Id(x => x.Id).GeneratedBy.Increment(); 
           Map(x => x.ItemsCategoryID);
           Map(x => x.ItemPrice);
           Map(x => x.QOH);
           Map(x => x.InStoreID);
           Map(x => x.Discount);
   }



   }
   public class DispatchHistoryMap : ClassMap<DispatchHistory>
   {

        public DispatchHistoryMap()
       {
           Table("DispatchHistory");

           Id(x => x.ID).GeneratedBy.Increment(); ;
           Map(x => x.OutStoreID);
           Map(x => x.DispatchPrice);
           Map(x => x.ItemId);
           Map(x => x.DispatchID);
           Map(x => x.quantity);
           Map(x => x.PriceOut);
           Map(x => x.Percenatge);
           Map(x => x.initQuantity);

       }

   }
    
   public class ItemCategoryMap : ClassMap<ItemCategory>
   {

       public ItemCategoryMap()
       {
           
           Id(x => x.ItemTypeId).GeneratedBy.Increment(); 
           Map(x => x.ItemName);
           Map(x => x.ROL);
           Map(x => x.DefaultPrice);
           Table("ItemsType");
       }




   }



   public class PurchasesTrackMap : ClassMap<PurchasesTrack>
   {
       public PurchasesTrackMap()
       {
           Table("PurchasesTrack");

           Id(x => x.Id).GeneratedBy.Increment(); ;
           Map(x => x.Notes);
           Map(x => x.PurchasedDate);
           Map(x => x.PurchaseRef);

       }


   }

    public class PinDataMap: ClassMap<PinData>{

        public PinDataMap()
        {

            Table("PinData");
            Id(x => x.ID).GeneratedBy.Increment();
            Map(x => x.UserType);
            Map(x => x.UserString);

        }
    }

   public class DispatchTrackMap : ClassMap<DispatchTrack>
   {
       public DispatchTrackMap()
       {
           Table("DispatchTrack");

           Id(x => x.Id).GeneratedBy.Increment(); 
           Map(x => x.Notes);
           Map(x => x.DispatchedDate);
           Map(x => x.DisPatchRef);


       }


   }

    public class StoreItemsMap : ClassMap<StoreItems>
    {
        // chenge the ID such that it reflects PK
        public StoreItemsMap()
    
      
        {
            Table("Items");

            Id(x => x.ItemID).GeneratedBy.Increment();
            Map(x => x.ItemTypeRef);
           
            
            Map(x => x.InStore_Or_Dispatched);
            Map(x => x.InStoreID);
            
            Map(x => x.Quantity);
            Map(x => x.QOH);
             Map(x => x.PurchaseID);
            Map(x => x.PurchasePrice);
            Map(x => x.Discount);
           

           
        }
    }

    public class StoreDataMap : ClassMap<StoreData>
    {
        // chenge the ID such that it reflects PK
        public StoreDataMap()
        {
            Table("StoreData");

            Id(x => x.StoreId).GeneratedBy.Increment(); 
            Map(x => x.Address);
            Map(x => x.StoreLocation);
            Map(x => x.StoreName);
            Map(x => x.StoreType);
            Map(x => x.StorePhone);
            

        }
    }








#endregion stotertrackerMaps
    /*
    
    



    public class Subscribers
    {
        public virtual string TaskId
        {
            get;
            set;
            }
        
        public virtual string SubscriberId
        {
           
            get;
            set;
            
        
        }
        public virtual DateTime SubscribedDate { get; set; }
        //  public virtual string RatingValue { get; set; }

        public override bool Equals(object obj)
        {
            var t = obj as Subscribers;
            return ((TaskId==t.TaskId)&&(SubscriberId==t.SubscriberId));
        }

        public override int GetHashCode()
        {

            return (TaskId + "|" + SubscriberId).GetHashCode(); 
        }


    }

    public class SubscribersMap : ClassMap<Subscribers>
    {
        // chenge the ID such that it reflects PK

        public SubscribersMap()
        {


            Table("Subscribers");
            CompositeId()
           .KeyProperty(x => x.TaskId, "TaskId")
           .KeyProperty(x => x.SubscriberId, "SubscriberId");
            Map(x => x.SubscribedDate);
        }
    }

    
    public class RatingTable
    {
        // chenge the ID such that it reflects PK

        public virtual string RatingMember
        {
            get;
            set;
            
        }
        public virtual string RatedMember
        {
            get;
            set;

        }
        public virtual string RatingValue { get; set; }

        public override bool Equals(object obj)
        {
            var t = obj as RatingTable;
            return ((RatingMember==t.RatingMember)&&(RatedMember==t.RatedMember)) ;
        }

        public override int GetHashCode()
        {

            return (RatedMember + "|" + RatedMember).GetHashCode();
        }

    }


    public class AssignedToTable
    {
        // chenge the ID such that it reflects PK

        public virtual string TaskId
        {
            get;
            set;

        }
        public virtual string Owner
        {
            get;
            set;

        }
        public virtual string AssignedTo { get; set; }

        public override bool Equals(object obj)
        {
            var t = obj as AssignedToTable;
            return ((TaskId == t.TaskId) && (Owner == t.Owner) && (AssignedTo == t.AssignedTo));
        }

        public override int GetHashCode()
        {

            return (TaskId + "|" + Owner + "|" + AssignedTo).GetHashCode();
        }

    }

    public class RatingTableMap : ClassMap<RatingTable>
    {
        // chenge the ID such that it reflects PK

        public RatingTableMap()
        {
            Table("RatingTable");
            CompositeId()
           .KeyProperty(x => x.RatingMember, "RatingMember")
           .KeyProperty(x => x.RatedMember, "RatedMember");
            Map(x => x.RatingValue);
        }
    }
    public class AssignedToMap : ClassMap<AssignedToTable>
    {
        

        public AssignedToMap()
        {
            Table("AssignedToTable");
            CompositeId()
           .KeyProperty(x => x.TaskId, "TaskId")
           .KeyProperty(x => x.Owner, "Owner")
            .KeyProperty(x => x.AssignedTo,"AssignedTo");
           
        }
    }

   





    public class AppRoles
    {
        // chenge the ID such that it reflects PK

        public virtual string RoleName { get; set; }


    }

    public class AppRolesMap : ClassMap<AppRoles>
    {
        // chenge the ID such that it reflects PK

        public AppRolesMap()
        { 
            
            Table("AppRoles");
          
            Id(x => x.RoleName);
            
        }
    }






    public class TaskEntityMap : ClassMap<TaskEntity>
    {
        public TaskEntityMap()
        {
            
            Table("TaskEntity");
            Id(x => x.TaskId);

            Map(x => x.Description);
            Map(x => x.Details);
            Map(x => x.Location);
            Map(x => x.Status);
            Map(x => x.Owner);
            Map(x => x.Value);
            Map(x => x.TaskHistory);
            Map(x => x.Rating);
            Map(x => x.DateCreated);
            Map(x => x.DateClosed);
            Map(x => x.DateStatusChanged);
            Map(x => x.PaymentDate);
            Map(x => x.TaskStartDate);
            Map(x => x.TaskEndDate);
            Map(x => x.prefferedTMZ);
            
        }


    }






    public class UserEntityMap : ClassMap<UserEntity>
    {


        public UserEntityMap()
        {
            Table("UserEntity");
            Id(x => x.UserName);
            Map(x => x.UserPwd);
            Map(x => x.Description);
            Map(x => x.Details);
            Map(x => x.Address);
            Map(x => x.PhoneNo);
            Map(x => x.IsActive);
            Map(x => x.IsApproved);
            Map(x => x.Role);
            Map(x => x.Rating);
            Map(x => x.DateCreated);
            Map(x => x.prefferedTMZ);
            Map(x => x.UserEmail);




        }



    }


     

    /// <summary>
    ///  TimeZone Helper Classes 
    /// </summary>
   


    public class timezonehelper
    {
        public string displayname { get; set; }
        public string id { get; set; }
    }


    
  public  static class AddTimeZonesList {

   public     static timezonehelper GetIdByDisplayName(string DisplayName)
        {


            List<timezonehelper> ListOfTMZ = gettimezonehelpers();
            return ListOfTMZ.Find(x => x.displayname.ToUpper().Trim() == DisplayName.ToUpper().Trim());

        }
      public  static  List<timezonehelper> gettimezonehelpers()
        {
            return new List<timezonehelper>()
            {
                new timezonehelper() { displayname="(gmt) casablanca", id="morocco standard time", },
                new timezonehelper() { displayname="(gmt) greenwich mean time : dublin, edinburgh, lisbon, london", id="gmt standard time", },
                new timezonehelper() { displayname="(gmt) monrovia, reykjavik", id="greenwich standard time", },
                new timezonehelper() { displayname="(gmt+01:00) amsterdam, berlin, bern, rome, stockholm, vienna", id="w. europe standard time", },
                new timezonehelper() { displayname="(gmt+01:00) belgrade, bratislava, budapest, ljubljana, prague", id="central europe standard time", },
                new timezonehelper() { displayname="(gmt+01:00) brussels, copenhagen, madrid, paris", id="romance standard time", },
                new timezonehelper() { displayname="(gmt+01:00) sarajevo, skopje, warsaw, zagreb", id="central european standard time", },
                new timezonehelper() { displayname="(gmt+01:00) west central africa", id="w. central africa standard time", },
                new timezonehelper() { displayname="(gmt+02:00) amman", id="jordan standard time", },
                new timezonehelper() { displayname="(gmt+02:00) athens, bucharest, istanbul", id="gtb standard time", },
                new timezonehelper() { displayname="(gmt+02:00) beirut", id="middle east standard time", },
                new timezonehelper() { displayname="(gmt+02:00) cairo", id="egypt standard time", },
                new timezonehelper() { displayname="(gmt+02:00) harare, pretoria", id="south africa standard time", },
                new timezonehelper() { displayname="(gmt+02:00) helsinki, kyiv, riga, sofia, tallinn, vilnius", id="fle standard time", },
                new timezonehelper() { displayname="(gmt+02:00) jerusalem", id="israel standard time", },
                new timezonehelper() { displayname="(gmt+02:00) minsk", id="e. europe standard time", },
                new timezonehelper() { displayname="(gmt+02:00) windhoek", id="namibia standard time", },
                new timezonehelper() { displayname="(gmt+03:00) baghdad", id="arabic standard time", },
                new timezonehelper() { displayname="(gmt+03:00) kuwait, riyadh", id="arab standard time", },
                new timezonehelper() { displayname="(gmt+03:00) moscow, st. petersburg, volgograd", id="russian standard time", },
                new timezonehelper() { displayname="(gmt+03:00) nairobi", id="e. africa standard time", },
                new timezonehelper() { displayname="(gmt+03:00) tbilisi", id="georgian standard time", },
                new timezonehelper() { displayname="(gmt+03:30) tehran", id="iran standard time", },
                new timezonehelper() { displayname="(gmt+04:00) abu dhabi, muscat", id="arabian standard time", },
                new timezonehelper() { displayname="(gmt+04:00) baku", id="azerbaijan standard time", },
                new timezonehelper() { displayname="(gmt+04:00) yerevan", id="caucasus standard time", },
                new timezonehelper() { displayname="(gmt+04:30) kabul", id="afghanistan standard time", },
                new timezonehelper() { displayname="(gmt+05:00) ekaterinburg", id="ekaterinburg standard time", },
                new timezonehelper() { displayname="(gmt+05:00) islamabad, karachi", id="pakistan standard time", },
                new timezonehelper() { displayname="(gmt+05:00) tashkent", id="west asia standard time", },
                new timezonehelper() { displayname="(gmt+05:30) chennai, kolkata, mumbai, new delhi", id="india standard time", },
                new timezonehelper() { displayname="(gmt+05:30) sri jayawardenepura", id="sri lanka standard time", },
                new timezonehelper() { displayname="(gmt+05:45) kathmandu", id="nepal standard time", },
                new timezonehelper() { displayname="(gmt+06:00) almaty, novosibirsk", id="n. central asia standard time", },
                new timezonehelper() { displayname="(gmt+06:00) astana, dhaka", id="central asia standard time", },
                new timezonehelper() { displayname="(gmt+06:30) yangon (rangoon)", id="myanmar standard time", },
                new timezonehelper() { displayname="(gmt+07:00) bangkok, hanoi, jakarta", id="se asia standard time", },
                new timezonehelper() { displayname="(gmt+07:00) krasnoyarsk", id="north asia standard time", },
                new timezonehelper() { displayname="(gmt+08:00) beijing, chongqing, hong kong, urumqi", id="china standard time", },
                new timezonehelper() { displayname="(gmt+08:00) irkutsk, ulaan bataar", id="north asia east standard time", },
                new timezonehelper() { displayname="(gmt+08:00) kuala lumpur, singapore", id="singapore standard time", },
                new timezonehelper() { displayname="(gmt+08:00) perth", id="w. australia standard time", },
                new timezonehelper() { displayname="(gmt+08:00) taipei", id="taipei standard time", },
                new timezonehelper() { displayname="(gmt+09:00) osaka, sapporo, tokyo", id="tokyo standard time", },
                new timezonehelper() { displayname="(gmt+09:00) seoul", id="korea standard time", },
                new timezonehelper() { displayname="(gmt+09:00) yakutsk", id="yakutsk standard time", },
                new timezonehelper() { displayname="(gmt+09:30) adelaide", id="cen. australia standard time", },
                new timezonehelper() { displayname="(gmt+09:30) darwin", id="aus central standard time", },
                new timezonehelper() { displayname="(gmt+10:00) brisbane", id="e. australia standard time", },
                new timezonehelper() { displayname="(gmt+10:00) canberra, melbourne, sydney", id="aus eastern standard time", },
                new timezonehelper() { displayname="(gmt+10:00) guam, port moresby", id="west pacific standard time", },
                new timezonehelper() { displayname="(gmt+10:00) hobart", id="tasmania standard time", },
                new timezonehelper() { displayname="(gmt+10:00) vladivostok", id="vladivostok standard time", },
                new timezonehelper() { displayname="(gmt+11:00) magadan, solomon is., new caledonia", id="central pacific standard time", },
                new timezonehelper() { displayname="(gmt+12:00) auckland, wellington", id="new zealand standard time", },
                new timezonehelper() { displayname="(gmt+12:00) fiji, kamchatka, marshall is.", id="fiji standard time", },
                new timezonehelper() { displayname="(gmt+13:00) nuku'alofa", id="tonga standard time", },
                new timezonehelper() { displayname="(gmt-01:00) azores", id="azores standard time", },
                new timezonehelper() { displayname="(gmt-01:00) cape verde is.", id="cape verde standard time", },
                new timezonehelper() { displayname="(gmt-02:00) mid-atlantic", id="mid-atlantic standard time", },
                new timezonehelper() { displayname="(gmt-03:00) brasilia", id="e. south america standard time", },
                new timezonehelper() { displayname="(gmt-03:00) buenos aires", id="argentina standard time", },
                new timezonehelper() { displayname="(gmt-03:00) georgetown", id="sa eastern standard time", },
                new timezonehelper() { displayname="(gmt-03:00) greenland", id="greenland standard time", },
                new timezonehelper() { displayname="(gmt-03:00) montevideo", id="montevideo standard time", },
                new timezonehelper() { displayname="(gmt-03:30) newfoundland", id="newfoundland standard time", },
                new timezonehelper() { displayname="(gmt-04:00) atlantic time (canada)", id="atlantic standard time", },
                new timezonehelper() { displayname="(gmt-04:00) la paz", id="sa western standard time", },
                new timezonehelper() { displayname="(gmt-04:00) manaus", id="central brazilian standard time", },
                new timezonehelper() { displayname="(gmt-04:00) santiago", id="pacific sa standard time", },
                new timezonehelper() { displayname="(gmt-04:30) caracas", id="venezuela standard time", },
                new timezonehelper() { displayname="(gmt-05:00) bogota, lima, quito, rio branco", id="sa pacific standard time", },
                new timezonehelper() { displayname="(gmt-05:00) eastern time (us & canada)", id="eastern standard time", },
                new timezonehelper() { displayname="(gmt-05:00) indiana (east)", id="us eastern standard time", },
                new timezonehelper() { displayname="(gmt-06:00) central america", id="central america standard time", },
                new timezonehelper() { displayname="(gmt-06:00) central time (us & canada)", id="central standard time", },
                new timezonehelper() { displayname="(gmt-06:00) guadalajara, mexico city, monterrey", id="central standard time (mexico)", },
                new timezonehelper() { displayname="(gmt-06:00) saskatchewan", id="canada central standard time", },
                new timezonehelper() { displayname="(gmt-07:00) arizona", id="us mountain standard time", },
                new timezonehelper() { displayname="(gmt-07:00) chihuahua, la paz, mazatlan", id="mountain standard time (mexico)", },
                new timezonehelper() { displayname="(gmt-07:00) mountain time (us & canada)", id="mountain standard time", },
                new timezonehelper() { displayname="(gmt-08:00) pacific time (us & canada)", id="pacific standard time", },
                new timezonehelper() { displayname="(gmt-08:00) tijuana, baja california", id="pacific standard time (mexico)", },
                new timezonehelper() { displayname="(gmt-09:00) alaska", id="alaskan standard time", },
                new timezonehelper() { displayname="(gmt-10:00) hawaii", id="hawaiian standard time", },
                new timezonehelper() { displayname="(gmt-11:00) midway island, samoa", id="samoa standard time", },
                new timezonehelper() { displayname="(gmt-12:00) international date line west", id="dateline standard time", }
            };
    }
    }


     
     */ 
}
