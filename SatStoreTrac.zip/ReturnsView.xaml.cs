﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using Caliburn.Micro;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for ReturnsView.xaml
    /// </summary>
    public partial class ReturnsView : UserControl
     {
        public ReturnsView()
        {
            InitializeComponent();
        }


        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            Window temp = Window.GetWindow(this.Parent);
            temp.Height = 900;
            temp.Width = 1500;
            temp.ResizeMode = ResizeMode.NoResize;
            temp.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            temp.WindowStyle = WindowStyle.ToolWindow;
            temp.UseLayoutRounding = true;
            this.Width = 1500;
            this.Height = 900;
            this.MinHeight = 800;
            this.MinWidth = 1400;

            txtItemName.ItemsSource = ((ReturnsViewModel)this.DataContext).StoreItems;

            txtItemName.FilterMode = AutoCompleteFilterMode.Custom;

            txtItemName.ItemFilter = (txt, i) => ItemCategoryAutoComplete.IsAutoCompleteSuggestion(txt, i);
            txtItemName.AddHandler(AutoCompleteBox.DropDownClosingEvent, new  RoutedEventHandler(txtItemName_DropDownClosed), false);
          //  txtItemName.AddHandler(AutoCompleteBox., new RoutedEventHandler(txtItemName_DropDownClosed), false);

        }




        private void btnShowStoreDialog_Click(object sender, RoutedEventArgs e)
        {
            StoreDialogViewModel StoreViewModel = new StoreDialogViewModel();

            SecurityValuesForApp.AppWindowManger.ShowDialog(StoreViewModel);

            if (StoreViewModel.CurrentItemID == -3) { return; }

            if (StoreViewModel.CurrentItemID <= 0)
            {
                MessageBox.Show("No Store Selected!", "No Store Selected", MessageBoxButton.OK, MessageBoxImage.Exclamation);


            }
            else
            {


                ((ReturnsViewModel)this.DataContext).StoreID = StoreViewModel.CurrentItemID;
                txtStoreName.Text = StoreViewModel.txtStoreName;
                ((ReturnsViewModel)this.DataContext).ClearAfterStoreSelection();

            }
        }



        private void txtItemName_DropDownClosed(object sender, RoutedEventArgs e)
        {

            

            e.Handled = true;
            if (((ReturnsViewModel)this.DataContext).StoreID <= 0) { MessageBox.Show("Select Store First!", "Select Store", MessageBoxButton.OK, MessageBoxImage.Exclamation); return; }

            Mouse.OverrideCursor = Cursors.Wait;

            if (sender is AutoCompleteBox)
            {

                if (txtItemName.SelectedItem == null)
                {
                    txtItemName.Text = "";

                    MessageBox.Show("Please select a Valid Item", "No Item Selected", MessageBoxButton.OK, MessageBoxImage.Error);

                }

                else
                {
                    txtItemName.Text = (((ItemCategory)txtItemName.SelectedItem).ItemName);
                 //   txtDefaultPrice.Text = (((ItemCategory)txtItemName.SelectedItem).DefaultPrice ?? 0).ToString();
                    int tempItemID=(((ItemCategory)txtItemName.SelectedItem).ItemTypeId ?? -1);;
                    ((ReturnsViewModel)this.DataContext).currentItemID = tempItemID;
                    ((ReturnsViewModel)this.DataContext).SetPurchases(tempItemID);
                }

            }

            Mouse.OverrideCursor = null;
           
        }

        private void cmbPrevPurchasePrice_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            bool validItem=false; int tempItemID;
            e.Handled = true;
            try{

                if (((ReturnsViewModel)this.DataContext).isLoadPurchase) { ((ReturnsViewModel)this.DataContext).isLoadPurchase = false; return; }

                ComboBox tempBox = sender as ComboBox;

                Mouse.OverrideCursor = Cursors.Wait;
                    
                if (txtItemName.SelectedItem == null)
                {
                    txtItemName.Text = "";

                    MessageBox.Show("Please select a Valid Item", "No Item Selected", MessageBoxButton.OK, MessageBoxImage.Error);
                    e.Handled=true;
                    return;

                }

                else
                {
                    txtItemName.Text = (((ItemCategory)txtItemName.SelectedItem).ItemName);
                 //   txtDefaultPrice.Text = (((ItemCategory)txtItemName.SelectedItem).DefaultPrice ?? 0).ToString();
                     tempItemID=(((ItemCategory)txtItemName.SelectedItem).ItemTypeId ?? -1);
                     if (((ReturnsViewModel)this.DataContext).currentItemID != tempItemID)
                     {
                        txtItemName.Text = "";
                       
                    MessageBox.Show("Item selection has changed! select again a Valid Item to get proper prices(MRP) and discounts and quantity available", "No Item Selected", MessageBoxButton.OK, MessageBoxImage.Error);
                    e.Handled=true;
                    return;

                    }
                    else { validItem =true;}
                //    ((DispatchTrackViewModel)this.DataContext).SetPurchases(tempItemID);
                }


                if (validItem)
                {

                    decimal tempVal;
                    if (tempBox.SelectedValue.ToString().ToUpper().Trim()!="N/A"){
                    if (decimal.TryParse(tempBox.SelectedValue.ToString(), out tempVal))
                    {
                        int tempTotal;
                        ((ReturnsViewModel)this.DataContext).SetDiscountsForItemPrice(tempItemID, ((ReturnsViewModel)this.DataContext).StoreID, tempVal, out tempTotal);

                        //   ((DispatchTrackViewModel)this.DataContext).SetDiscountsForItemPrice(

                    }
                
                }
            }

                
                }
            
            catch (Exception ex){

            }

            finally
            {
                Mouse.OverrideCursor = Cursors.Wait;

            }
        }

        private void cmbPrevDiscounts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            


            bool validItem = false; int tempItemID;
            e.Handled = true;
            try
            {

                if (((ReturnsViewModel)this.DataContext).isLoadDiscount) { ((ReturnsViewModel)this.DataContext).isLoadDiscount = false; return; }
                ComboBox tempBox = sender as ComboBox;

                Mouse.OverrideCursor = Cursors.Wait;


                if (txtItemName.SelectedItem == null)
                {
                    txtItemName.Text = "";

                    MessageBox.Show("Please select a Valid Item", "No Item Selected", MessageBoxButton.OK, MessageBoxImage.Error);
                    e.Handled = true;
                    return;

                }

                else
                {
                    txtItemName.Text = (((ItemCategory)txtItemName.SelectedItem).ItemName);
                    //   txtDefaultPrice.Text = (((ItemCategory)txtItemName.SelectedItem).DefaultPrice ?? 0).ToString();
                    tempItemID = (((ItemCategory)txtItemName.SelectedItem).ItemTypeId ?? -1);
                    if (((ReturnsViewModel)this.DataContext).currentItemID != tempItemID)
                    {
                        txtItemName.Text = "";

                        MessageBox.Show("Item selection has changed! select again a Valid Item to get proper prices(MRP) and discounts and quantity available", "No Item Selected", MessageBoxButton.OK, MessageBoxImage.Error);
                        e.Handled = true;
                        return;

                    }
                    else { validItem = true; }
                    //    ((DispatchTrackViewModel)this.DataContext).SetPurchases(tempItemID);
                }


                if (validItem)
                {

                    decimal tempPurchaseVal = -1;
                    if (cmbPrevPurchasePrice.SelectedValue.ToString().ToUpper().Trim() != "N/A")
                    {
                        if (decimal.TryParse(cmbPrevPurchasePrice.SelectedValue.ToString(), out tempPurchaseVal))
                        {


                            decimal tempVal;
                            if (tempBox.SelectedValue.ToString().ToUpper().Trim() != "N/A")
                            {
                                if (decimal.TryParse(tempBox.SelectedValue.ToString(), out tempVal))
                                {
                                    int QOHTempValue = ((ReturnsViewModel)this.DataContext).QOHForAnItem(tempItemID,(((ReturnsViewModel)this.DataContext)).StoreID ,tempPurchaseVal, tempVal);

                                    if (QOHTempValue >= 0)
                                    {

                                        txtQOH.Text = QOHTempValue.ToString();
                                    }
                                    else
                                    {

                                        txtQOH.Text = "N/A";

                                    }

                                    //   ((DispatchTrackViewModel)this.DataContext).SetDiscountsForItemPrice(

                                }

                                // ((DispatchTrackViewModel)this.DataContext).SetPurchases(tempItemID);

                                //   ((DispatchTrackViewModel)this.DataContext).SetDiscountsForItemPrice(

                            }

                        }
                    }

                }
            }

            catch (Exception ex)
            {

                ex.ToString();

                return;
            }
            finally
            {


                Mouse.OverrideCursor = null;
            }


        }

        private void btnclear_Click(object sender, RoutedEventArgs e)
        {
            ((ReturnsViewModel)this.DataContext).ClearForm();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)(((ReturnsViewModel)this.DataContext).Parent)).ActivateItem(new FrontViewModel());
        }
    


    }
}
