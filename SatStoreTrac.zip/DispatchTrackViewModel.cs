﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using Caliburn.Micro;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;

namespace SatStoreTrac
{
    class DispatchTrackViewModel : Screen
    {
    private bool _isSaved = false;
    public bool isClose = true;
        public int currentItemID=0;
        public bool isSaved { get { return _isSaved; } set { _isSaved = value; NotifyOfPropertyChange(() => isSaved); } }
        private DispatchTrack currentDispatch = null;
        private string _txtItemName="" ;
        private string _txtDispatchPrice = "";
        private string _txtQOH = "";
        private string _txtQuantity = "";
        private string _txtPercentage = "";
        private string _txtRefNo = "";
        private string _txtNotes = "";
        private string _txtDispatchID = "";
        
        private bool _chkEnabled=true;

        public bool chkRestrictEnabled
        {
            get { return _chkEnabled; }
            set
            {
                _chkEnabled = value;
                NotifyOfPropertyChange(() => chkRestrictEnabled);
                
            }
        }

        private string _txtDate = "";
        public string txtDate { get { return _txtDate; } set { _txtDate = value; NotifyOfPropertyChange(() => txtDate); } }
        public string txtDispatchID { get { return _txtDispatchID; } set { _txtDispatchID = value; NotifyOfPropertyChange(() => txtDispatchID); } }
        public string txtRefNo { get { return _txtRefNo; } set { _txtRefNo = value; NotifyOfPropertyChange(() => txtRefNo); } }
        public string txtNotes { get { return _txtNotes; } set { _txtNotes = value; NotifyOfPropertyChange(() => txtNotes); } }
        public string onetxtItemName { get { return _txtItemName; } set { _txtItemName = value; NotifyOfPropertyChange(() => onetxtItemName); } }
        private string _txtStoreName="";
        public string txtStoreName { get { return _txtStoreName; } set { _txtStoreName = value; NotifyOfPropertyChange(() => txtStoreName); } }
        public string txtQuantity { get { return _txtQuantity; } set { _txtQuantity = value; NotifyOfPropertyChange(() => txtQuantity); } }
        public string txtDispatchPrice { get { return _txtDispatchPrice; } set { _txtDispatchPrice = value; NotifyOfPropertyChange(() => txtDispatchPrice); } }
        public string txtQOH { get { return _txtQOH; } set { _txtQOH = value; NotifyOfPropertyChange(() => txtQOH); } }
        public string txtPercentage { get { return _txtPercentage; } set { _txtPercentage = value; NotifyOfPropertyChange(() => txtPercentage); } }
        public int StoreID=-1;
        public string StoreName;
        public int currentDispatchID = -1;
        public List<ItemCategory> itemsDB = new List<ItemCategory>();
        public List<ItemsTrack> registerDB = new List<ItemsTrack>();
        public List<ItemCategory> itemsDBTemp = new List<ItemCategory>();
        public List<ItemsTrack> registerDBTemp = new List<ItemsTrack>();
        private string _txtItemID = "";
        public string txtItemID { get { return _txtItemID; } set { _txtItemID = value; NotifyOfPropertyChange(() => txtItemID); } }


        public ObservableCollection<PurchaseReturnsForDispatch> _PurchaseReturnItems = new ObservableCollection<PurchaseReturnsForDispatch>();

        public ObservableCollection<PurchaseReturnsForDispatch> PurchaseReturnItems { get { return _PurchaseReturnItems; } set { _PurchaseReturnItems = value; } }


        public ObservableCollection<DispatchItemsWithItemName> _listItems = new ObservableCollection<DispatchItemsWithItemName>();

        public ObservableCollection<DispatchItemsWithItemName> listItems { get { return _listItems; } set { _listItems = value; NotifyOfPropertyChange(() => listItems); } }

        public ObservableCollection<ItemCategory> _StoreItems = new ObservableCollection<ItemCategory>();

        public ObservableCollection<ItemCategory> StoreItems { get { return _StoreItems; } set { _StoreItems = value; } }
        public ItemCategory currentItemCategory = null;

        public ObservableCollection<string> PreviousPurchases { get { return _PreviousPurchases; } set { _PreviousPurchases = value; } }
        public ObservableCollection<string> _PreviousPurchases = new ObservableCollection<string>();

        public ObservableCollection<string> PreviousDiscounts { get { return _PreviousDiscounts; } set { _PreviousDiscounts = value; } }
        public ObservableCollection<string> _PreviousDiscounts = new ObservableCollection<string>();

        private ItemCategory _selectedStoreItem;
        public ItemCategory selectedStoreItem { get { return _selectedStoreItem; } set { _selectedStoreItem = value; NotifyOfPropertyChange(() => selectedStoreItem); } }
        private int _SelectedIndexPurchasePrice;
        private int _SelectedIndexDiscount;
        public int SelectedIndexPurchasePrice
        {
            get
            {
                return _SelectedIndexPurchasePrice;
            }
            set
            {
                _SelectedIndexPurchasePrice = value;
                NotifyOfPropertyChange(() => SelectedIndexPurchasePrice);
            }
        }

        public int SelectedIndexDiscount
        {
            get
            {
                return _SelectedIndexDiscount;
            }
            set
            {
                _SelectedIndexDiscount = value;
                NotifyOfPropertyChange(() => SelectedIndexDiscount);
            }
        }


        public override void CanClose(Action<bool> callback)
        {
            //if(some logic...)
            callback(isClose); // will cancel close
        }



        public List<string> cmbPrevPurchasePrice
        {
            get
            {
                // silly example of the collection to bind to
                return new List<string>(PreviousPurchases);
            }
            private set
            {
                
                if (value != null)
                {

                    PreviousPurchases = new ObservableCollection<string>(value);
                    NotifyOfPropertyChange(() => cmbPrevPurchasePrice);
                   if (PreviousPurchases.Count>0){
                       SelectedIndexPurchasePrice = 0;
                       Decimal tempDiscount = -1;

                       if (decimal.TryParse(PreviousPurchases[0], out tempDiscount))
                       {
                           SetDiscounts(tempDiscount, currentItemID);

                       }
                    }

                }
                
            }

        }
       

        public void LoadDispatch()
        {

            try
            {

                if (txtDispatchID.Trim() == "")
                {

                    MessageBox.Show("Enter Id ", "ID Cannot Be Empty", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }
                int DispatchID = -1;
                if (!int.TryParse(txtDispatchID.Trim(), out DispatchID))
                {
                    MessageBox.Show("ID is not an number ", "ID has to be an integer", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;


                }

                if (DispatchID <= 0)
                {
                    MessageBox.Show("ID Should be an positive number ", "ID has to be Positive number", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;


                }

                DispatchTrack dispatchTrackToGet = new DispatchTrack() { Id = DispatchID };
                StoreData storeToGet = new StoreData();

                List<PurchaseReturnsForDispatch> tempPurchaseReturns = new List<PurchaseReturnsForDispatch>();
                List<DispatchItemsWithItemName> tempListItems = GetItems(ref dispatchTrackToGet, out tempPurchaseReturns,out storeToGet);

                

                if (dispatchTrackToGet == null)
                {

                    MessageBox.Show("No Dispatch  with the ID  " + DispatchID.ToString(), "NO Dispatch", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

                ClearForm();
                isSaved = true;
                currentDispatch = dispatchTrackToGet;
                currentDispatchID = currentDispatch.Id ?? -1;
                txtItemID = (currentDispatch.Id ?? -1).ToString();
                txtNotes = dispatchTrackToGet.Notes??"";
                txtRefNo = dispatchTrackToGet.DisPatchRef ?? "";
                txtDate = (dispatchTrackToGet.DispatchedDate ?? DateTime.Now).ToLongDateString();
                listItems = new ObservableCollection<DispatchItemsWithItemName>( tempListItems);
                StoreID = storeToGet.StoreId??0;
                txtStoreName = storeToGet.StoreName ?? "";
                
                //TODO: ADD PURCHASE RETURN ITEMS LATER

            }

            catch (Exception ex)
            {
                MessageBox.Show("Error gettting Data! Try restart Application", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public List<DispatchItemsWithItemName> GetItems(ref DispatchTrack argDispatch, out List<PurchaseReturnsForDispatch> argPurchaseReturns, out StoreData argStore)
        {

            try
            {
                return DispacthTrackService.GetItems(ref argDispatch, out argPurchaseReturns, out argStore);

            }
           catch(Exception ex)
            {

                throw ex;
            }

           


        } 

        public List<string> cmbPrevDiscounts 


        {
            get
            {
                // silly example of the collection to bind to
                return new List<string>(PreviousDiscounts);
            }
            private set
            {
                
                if (value != null)
                {

                    PreviousDiscounts = new ObservableCollection<string>(value);
                    NotifyOfPropertyChange(() => cmbPrevDiscounts);
                    if (PreviousDiscounts.Count > 0)
                    {
                       SelectedIndexDiscount = 0;
                    }

                }
                
            }

        }





        private string _selectedcmbPrevPurchasePrice;
        public string SelectedcmbPrevPurchasePrice
        {
            get { return _selectedcmbPrevPurchasePrice; }
            set
            {
                _selectedcmbPrevPurchasePrice = value;
                NotifyOfPropertyChange(() => SelectedcmbPrevPurchasePrice);
                // and do anything else required on selection changed
            }
        }
        private string _SelectedcmbPrevDiscount="";
        public string SelectedcmbPrevDiscount
        {
            get { return _SelectedcmbPrevDiscount; }
            set
            {
                _SelectedcmbPrevDiscount = value;
                NotifyOfPropertyChange(() => SelectedcmbPrevDiscount);
                // and do anything else required on selection changed
            }
        }


        public bool confirmOperation()
        {

            if (!isSaved) { MessageBox.Show("No Active Record \r\n Save or Get a Dispatch Item to Cancel ", "No Active Record", MessageBoxButton.YesNo, MessageBoxImage.Exclamation); return false; }

            if (MessageBoxResult.Yes == MessageBox.Show("The Current Dispatch Record will be canceled \r\n To DO You want to Proceed?", "Proceed with Caution", MessageBoxButton.YesNo, MessageBoxImage.Question))
            {
                LoginViewModel TempLogin = new LoginViewModel(true);
                SecurityValuesForApp.AppWindowManger.ShowDialog(TempLogin);

                return TempLogin.LoginSuccess;



            }


            return false;


        }


        public void CancelDispatchTrack()
        {
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;

                isClose = false;
               StateOfOperation tempState= StoresService.DeleteDispatch(currentDispatch);


               if (tempState == StateOfOperation.Success)
               {

                   MessageBox.Show("Successfully cancelled Dispatch Transaction with ID: " + currentDispatch.Id.ToString(), " Success", MessageBoxButton.OK, MessageBoxImage.Information);

                   ClearForm();
               }
               else if (tempState == StateOfOperation.CannotCancelDispatch)
               {

                   MessageBox.Show("Cannot cancel Dispatch Transaction with ID: " + currentDispatch.Id.ToString() + "\r\n Because there are returns on this dispatch", " Cannot Cancel", MessageBoxButton.OK, MessageBoxImage.Exclamation);



               }
               else
               {
                   MessageBox.Show("Cannot cancel Dispatch Transaction with ID: " + currentDispatch.Id.ToString() + "\r\n Because there are no dispatch Items related to this ID", " Cannot Cancel", MessageBoxButton.OK, MessageBoxImage.Exclamation);


               }
               isClose = true;

            }
            catch (Exception)
            {
                isClose = true;
                MessageBox.Show("Un Expected error Try Restarting App", " restart App", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {

                Mouse.OverrideCursor = null;

            }
        }


        public void ClearForm(){
            itemsDB = ItemsService.GetRegisterAndItems(out registerDB);
            initializeItemsList();

        //    StoreItems = new ObservableCollection<ItemCategory>(itemsDB);
            listItems.Clear();
            ClearAddList();
            txtNotes = "";
            txtRefNo = "";
            txtItemID = "Add New..";
            isSaved = false;
            txtStoreName = "";
            txtDate = DateTime.Now.Date.ToLongDateString();

        }

        public void RefreshAfterSave(bool isSave)
        {
            itemsDB = ItemsService.GetRegisterAndItems(out registerDB);
            initializeItemsList();

            //    StoreItems = new ObservableCollection<ItemCategory>(itemsDB);
           // listItems.Clear();
            ClearAddList();
            isSaved = isSave;

        }

       
        public void btnSaveOrUpdate(RoutedEventArgs e)
        {

           
            e.Handled = true;
            if (isSaved)
            {

                MessageBox.Show("Information already Saved. To add more items Clear form ", "Information", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (StoreID<=0)
            {

                MessageBox.Show("No DispatchStore selected.", "Select a Dispatch store ", MessageBoxButton.OK, MessageBoxImage.Stop);
                return;
            }

            if (listItems.Count <= 0)
            {

                MessageBox.Show("No Items to save", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                string mesgstr="";
                if (!CheckForQOH(out mesgstr))
                {

                    MessageBox.Show(mesgstr, "Error Saving. Items counts did not tally",MessageBoxButton.OK,MessageBoxImage.Error);
                    return;

                }

                DispatchTrack tempDispatchTrack = new DispatchTrack() { Notes = txtNotes,  DisPatchRef=txtRefNo,  DispatchedDate = DateTime.Now };

                var tempStoreItems = listItems.Select((src) => new DispatchItems {  DispatchPrice=src.DispatchPrice, inDiscount=src.inDiscount, InStoreID=0, ItemCategoryID=src.ItemCategoryID, ItemPrice=src.ItemPrice, OutStoreID=StoreID, Percenatge=src.Percenatge,PriceOut=src.PriceOut, QOH=src.QOH }).ToList<DispatchItems>();

                isClose = false;

                if (((new DispacthTrackService()).CreateDispatchTrack(ref tempDispatchTrack, tempStoreItems,false)) != StateOfOperation.Success) { throw new Exception(); }
                currentDispatchID = tempDispatchTrack.Id??0;
                isSaved = true;
                currentDispatch = tempDispatchTrack;
                txtItemID = (currentDispatch.Id ?? -1).ToString();
                MessageBox.Show("Items Dispatched successfully", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                isClose = true;
                RefreshAfterSave(true);
               // ClearForm();
            }
            catch (Exception ex) {

                isClose = true;

                    MessageBox.Show("Error in adding Items ", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                
            
            }

            finally
            {
                isClose = true;
                Mouse.OverrideCursor = null;
            }
        }



        public void PrintItem()
        {


            if (!isSaved)
            {


                MessageBox.Show("Before printing an Item Please save the Item or Retrive an item", "Save or Get an Item To print", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }
            try
            {
                isClose = false;

                List<ItemCategoryWithDiscount> tempList=listItems.Select((src)=> new ItemCategoryWithDiscount(){ItemName=src.ItemName,ItemTypeId=src.ItemCategoryID, DefaultPrice=(double?)src.DispatchPrice, Discount=(double?)src.Percenatge, ROL=(double?)src.QOH}).ToList<ItemCategoryWithDiscount>();

                PrinterService.MakePrintDispatch(tempList, new StoreData() { StoreId = this.StoreID, StoreName = txtStoreName }, currentDispatch);
                isClose = true;
            }
            catch (Exception ex)
            {
                isClose = true;
                MessageBox.Show("Error Printing! Try Restart Application", "Restart", MessageBoxButton.OK, MessageBoxImage.Exclamation);

            }
        }





        void initializeItemsList()
        {
            itemsDBTemp.Clear();
            foreach (var tempItem in registerDB)
            {


                var GetItemDB = itemsDBTemp.Where(x => x.ItemTypeId == tempItem.ItemsCategoryID).FirstOrDefault();

                if (GetItemDB == null)
                {
                    var getItemName = itemsDB.Where(x => x.ItemTypeId == tempItem.ItemsCategoryID).First().ItemName;
                    itemsDBTemp.Add(new ItemCategory() { ItemTypeId = tempItem.ItemsCategoryID, ItemName = getItemName, DefaultPrice = 0, ROL = tempItem.QOH });

                }
                else
                {
                    GetItemDB.ROL += tempItem.QOH ?? 0;


                }



            }

            StoreItems = new ObservableCollection<ItemCategory>(itemsDBTemp);

        }
        public DispatchTrackViewModel()
        {

            /*
            itemsDB = ItemsService.GetRegisterAndItems(out registerDB);



            initializeItemsList();

            ClearAddList();
             * 
             */
            ClearForm();
        }
        
       

        public void ClearAddList()
        {
            PreviousPurchases = new ObservableCollection<string>();
            PreviousPurchases.Add("N/A");
            cmbPrevPurchasePrice = PreviousPurchases.ToList<string>();
            PreviousDiscounts = new ObservableCollection<string>();
            PreviousDiscounts.Add("N/A");
            cmbPrevDiscounts = PreviousDiscounts.ToList<string>();
            currentItemID = -1;
            currentItemCategory = null;
            onetxtItemName = "";
            txtPercentage = "";
            txtQuantity = "";
            txtQOH = "";
            txtDispatchPrice = "";
            txtDate = DateTime.Now.Date.ToLongDateString();
            
        }

        public  void SetPurchases(int ItemID){

            List<string> prevPurchases = registerDB.Where(x => x.ItemsCategoryID == ItemID && x.InStoreID == 0).OrderBy(x => x.ItemPrice).GroupBy(x => x.ItemPrice).Select(x => x.Key.ToString()).ToList<string>();

            if (prevPurchases == null)
            {
                prevPurchases = new List<string>();
                prevPurchases.Add("N/A");


            }

            else
            {
                if (prevPurchases.Count <= 0)
                {
                    prevPurchases.Add("N/A");


                }
            }

            PreviousPurchases.Clear();
            PreviousPurchases = new ObservableCollection<string>(prevPurchases);
            cmbPrevPurchasePrice = PreviousPurchases.ToList<string>();
            Decimal tempPrice = 0;
            if (decimal.TryParse(PreviousPurchases[0], out tempPrice))
            {
                SetDiscounts(tempPrice, ItemID);
            }
            else
            {
                cmbPrevDiscounts = new List<string> { "N/A" };

            }
        }


        public void SetDiscounts(Decimal prevPurchasePrice, int tempItemID)
        {

            List<string> prevDiscounts = registerDB.Where(x => x.ItemsCategoryID == tempItemID && x.InStoreID == 0 && x.ItemPrice == prevPurchasePrice).OrderBy(x => x.ItemPrice).GroupBy(x => x.Discount).Select(x => x.Key.ToString()).ToList<string>();

            if (prevDiscounts == null)
            {
                prevDiscounts = new List<string>();
                prevDiscounts.Add("N/A");


            }

            else
            {
                if (prevDiscounts.Count <= 0)
                {
                    prevDiscounts.Add("N/A");


                }
            }

            PreviousDiscounts.Clear();
            PreviousDiscounts = new ObservableCollection<string>(prevDiscounts);
            cmbPrevDiscounts = PreviousDiscounts.ToList<string>();

            double discountSelected = 0;

            if (double.TryParse(cmbPrevDiscounts[0], out discountSelected))
            {
                int tempID = tempItemID; int tempReturnVal = 0;
                tempReturnVal = QOHForAnItem(tempID, prevPurchasePrice, discountSelected);
                if (tempReturnVal >= 0)
                {
                    txtQOH = tempReturnVal.ToString();
                }
                else
                {
                    txtQOH = "N/A";
                }
            }


        }



        // check for total dispatch qunatity is available

        

        public bool CheckForQOH(out string Message)
        {

            Message = "";

            int TotalQOH = 0;



            var returnItemCategories = listItems.GroupBy(cm => new { cm.ItemCategoryID, cm.DispatchPrice, cm.inDiscount }, (key, group) => new
            {
                category = key.ItemCategoryID,
                purchasePrice = key.DispatchPrice,
                inDiscount = key.inDiscount,
                totalQOH = group.Sum(x => x.QOH),
                itemName =group.FirstOrDefault().ItemName
                
            });
            foreach (var temp in returnItemCategories)
            {

                var  RegisterTotalQOH = registerDB.Where(x => x.ItemsCategoryID == temp.category && x.ItemPrice == temp.purchasePrice && x.Discount == temp.inDiscount).FirstOrDefault();

                if (RegisterTotalQOH == null) { Message = "Error Please restart the application"; return false; }
                if (RegisterTotalQOH.QOH<temp.totalQOH){

                    Message="The total items are more than the Items in store at " + temp.purchasePrice.ToString() + " and discount " + temp.inDiscount.ToString() + " for \r\n " + temp.itemName.ToString() +" ";
                    return false;

                }


            }

            return true;


        }


      public  int QOHForAnItem(int tempItemID, Decimal Itemprice, double tempDiscount)
        {

            ItemsTrack prevDiscountsList = registerDB.Where(x => x.ItemsCategoryID == tempItemID && x.ItemPrice == Itemprice && x.Discount == tempDiscount).FirstOrDefault();

            if (prevDiscountsList == null) { return -1; }

            return prevDiscountsList.QOH ?? 0;

        }

        //Begin Here
        public bool  SetDiscountsForItemPrice(int tempItemID,Decimal Itemprice,out int TotalQOH){

            List<string> prevDiscounts = registerDB.Where(x => x.ItemsCategoryID == tempItemID && x.ItemPrice==Itemprice).OrderBy(x => x.Discount).Select(x => x.Discount.ToString()).ToList<string>();
            List<ItemsTrack> prevDiscountsList = registerDB.Where(x => x.ItemsCategoryID == tempItemID && x.ItemPrice == Itemprice).OrderBy(x => x.Discount).ToList();
            
            TotalQOH = 0;
            bool HasValues = true;


            if (prevDiscounts == null)
            {
                prevDiscounts = new List<string>();
                prevDiscounts.Add("N/A");
                HasValues = false;
                txtQOH = TotalQOH.ToString();
                
               

            }

            else
            {
                if (prevDiscounts.Count <= 0)
                {
                    prevDiscounts = new List<string>();
                    prevDiscounts.Add("N/A");
                    HasValues = false;
                    txtQOH = TotalQOH.ToString();

                }
            }

            PreviousDiscounts.Clear();
            PreviousDiscounts = new ObservableCollection<string>(prevDiscounts);
            cmbPrevPurchasePrice = PreviousDiscounts.ToList<string>();
            if (HasValues)
            {
                int tempID = tempItemID; Decimal TempPrice = prevDiscountsList[0].ItemPrice ?? -1; Double QOHdiscount = prevDiscountsList[0].Discount ?? -1;
                int tempQOH = QOHForAnItem(tempID, TempPrice, QOHdiscount);
                txtQOH = tempQOH.ToString();
            }
            

            return true;


        }
        public void AddPurchaseItem(RoutedEventArgs e )
        {
            DispatchItemsWithItemName selectedItem = null;
            e.Handled = true;

            if (isSaved) { MessageBox.Show("Dispatch already saved. To save New Clear form ", "Already Saved", MessageBoxButton.OK, MessageBoxImage.Information); return; }
            if (validateItem(out selectedItem))
            {
                if (ShowConfirmDialog(ref selectedItem)!=null)
                {

                    listItems.Add(selectedItem);
                    ClearAddList();

                }

            }
          
        }

        private bool ShowConfirmDialog(ref DispatchItemsWithItemName itemValue)
        {
            int TempId = itemValue.ItemCategoryID??currentItemID;

            var getItem = StoreItems.Where(x => x.ItemTypeId == TempId).FirstOrDefault();
            if (getItem == null)
            {
                MessageBox.Show("Not a ValidItem Selected, select the Item again", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                
                return true;

            }

            string confirmMessage = "The Item : " + getItem.ItemName + "\r\n" + " With Purchase Price : " + (itemValue.DispatchPrice ?? 0).ToString() + "\r\n and Quantity: " + ((int)(itemValue.QOH ?? 0)).ToString() + " will be added to list ";
            if (MessageBoxResult.Cancel == MessageBox.Show(confirmMessage, "Confirm or Cancel to add the item to Purchase list", MessageBoxButton.OKCancel, MessageBoxImage.Question)) return false;
            itemValue.ItemName = getItem.ItemName;
            return true;
        }


     public   bool convertPriceToPercentage(string priceString, Decimal PurchasePrice,out Decimal calcDiscount)

        {
            calcDiscount = -1;

            decimal DispatchPrice = -1;
            decimal one = 1.0M;
            if (decimal.TryParse(priceString,out DispatchPrice)){
 
                if (DispatchPrice>0) { calcDiscount = ((DispatchPrice/PurchasePrice)+ one)*100;}
                else{calcDiscount=-1;}
                return true;

            }

            return false;
        }







        public   bool convertPercentageToPrice(string percentageString, Decimal PurchasePrice,out Decimal calcDiscount)

        {
            calcDiscount = -1;

            decimal DispatchPercentage = -1;
            decimal one = 1.0M;
            if (decimal.TryParse(percentageString,out DispatchPercentage)){
 
                if (DispatchPercentage>0) { calcDiscount = (PurchasePrice*( one - DispatchPercentage/100));}
                else{calcDiscount=-1;}
                return true;

            }

            return false;
        }

        private bool validateItem(out DispatchItemsWithItemName TempItem)
        {
            TempItem = new DispatchItemsWithItemName();
            StringBuilder str = new StringBuilder();
            try
            {
                str.Clear();
                str.Append("Purchase Price Not Valid");
                
                decimal tempPurchasePrice=-1;

                tempPurchasePrice = decimal.Parse(SelectedcmbPrevPurchasePrice.ToString());
                str.Clear();
                str.Append("Purchased Discount Not Valid");
                decimal tempDiscount = -1;

                tempDiscount = decimal.Parse(SelectedcmbPrevDiscount.ToString());
                str.Clear();


                if ( currentItemID<=0)
                {
                    str.Clear();
                    str.Append("No valid Item Selected to add");
                    throw new Exception();


                }



                if (onetxtItemName.Trim() == "")
                {


                    str.Clear();
                    str.Append("No valid Item Selected to add");
                    throw new Exception();
                }
                /*
                if (txtDispatchPrice.Trim() == "")
                {


                    str.Clear();
                    str.Append("Purchase price cannot be empty");
                    throw new Exception();
                }

                 */
 
                if (txtQuantity.Trim() == "")
                {


                    str.Clear();
                    str.Append("Quantity cannot be empty, Enter Quantity");
                    throw new Exception();
                }
                str.Append("Discount Percentage should be a Decimal value");
                NumberStyles style = NumberStyles.AllowDecimalPoint;
                Decimal DefaultDiscount;

                // defaultDiscount is denoting dispatch percentage


                DefaultDiscount = decimal.Parse(txtPercentage.Trim(), style);

                if ((DefaultDiscount <= 0))
                {

                    str.Clear();
                    str.Append("Discount  percentage cannot be negative or zero");
                    throw new Exception();
                }

                if (DefaultDiscount.ToString().Count(x => x == '.') > 1)
                {

                    str.Clear();
                    str.Append("Dispatch price cannot have more than two decimals points");
                    throw new Exception();

                }
                /*

                if ((DefaultPrice.ToString().Contains(".")) && ((DefaultPrice.ToString().Length - (DefaultPrice.ToString().IndexOf(".") + 1)) > 2))
                {


                    str.Clear();
                    str.Append("Purchase price is money, cannot have more than two digits after decimal");
                    throw new Exception();
                }

                */




                str.Clear();
                str.Append("Quantity is not valid number");

                // ROL denotes quantity
                int  ROLForItem = int.Parse(txtQuantity.Trim());
                str.Append("Quantity on Hand is not valid number");
                int tempQOH = int.Parse(txtQOH.Trim());
                if ((ROLForItem <=0))
                {

                    str.Clear();
                    str.Append("Quantity cannot be Negative or zero");
                    throw new Exception();
                }
                if ((ROLForItem >tempQOH))
                {

                    str.Clear();
                    str.Append("Quantity cannot be more than Quantity on Hand ");
                    throw new Exception();
                }

                /*
                if ((ROLForItem.ToString().Contains(".")) && ((ROLForItem.ToString().Length - (ROLForItem.ToString().IndexOf(".") + 1)) > 0))
                {


                    str.Clear();
                    str.Append("Purchase price cannot have more than two decimals");
                    throw new Exception();
                }

                */

              //  TempItem.ItemPrice = DefaultPrice;
                TempItem.ItemCategoryID = currentItemID;
                TempItem.ItemName = onetxtItemName;
                TempItem.QOH = ROLForItem;
                TempItem.InStoreID = 0;
                TempItem.OutStoreID = -1;
                TempItem.DispatchPrice = tempPurchasePrice;
                TempItem.ItemPrice = tempPurchasePrice;
                TempItem.Percenatge = DefaultDiscount;
                TempItem.inDiscount = (double)tempDiscount;
                TempItem.PriceOut =decimal.Parse(txtDispatchPrice);
                
                    str.Clear();
                    str.Append("There is no enough Quantity in store for this Dispatch");
                    

                    if (QOHForAnItem(TempItem.ItemCategoryID ?? 0, TempItem.DispatchPrice ?? 0, TempItem.inDiscount ?? 0) <= 0)
                    {
                        throw new Exception();

                    }

                return true;
            }

            catch (Exception ex)
            {
                MessageBox.Show(str.ToString(), "Error Saving Item record", MessageBoxButton.OK, MessageBoxImage.Error);


                return false;
            }

            //   return false;

        }

    
    }
}
