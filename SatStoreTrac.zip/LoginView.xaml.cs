﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for LoginView.xaml
    /// </summary>
    public partial class LoginView : Window
    {
        public LoginView()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            e.Handled=true;
            if (cmbUserType.SelectedItem!=null){
                if (cmbUserType.SelectedIndex>=0){}
           if( ((LoginViewModel)this.DataContext).CheckLogin( ((ComboBoxItem) cmbUserType.SelectedItem).Content.ToString().Trim(),txtPassword.Password)){
               
           SecurityValuesForApp.isLoggedIn=true;
           SecurityValuesForApp.adminmode=((LoginViewModel)this.DataContext).isAdminMode;   
           this.Close();
               return;


           }

        ErrorLabel.Visibility=Visibility.Visible;
 


            }

            }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            this.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            this.WindowStyle = WindowStyle.ToolWindow;
            cmbUserType.SelectedIndex = 0;


            if (((LoginViewModel)this.DataContext).checkAdmin)
            {

                this.Title = "Log in as Administartor to proceed";
                cmbUserType.Visibility = Visibility.Hidden;

                lblUserType.Visibility = Visibility.Hidden;
            }
        }
        }
    
}
