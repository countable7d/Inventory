﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using Caliburn.Micro;
using Caliburn;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for StoreManagerView.xaml
    /// </summary>
    public partial class StoreManagerView : UserControl
    {
        public StoreManagerView()
        {
            InitializeComponent();
        }



        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            Window temp = Window.GetWindow(this.Parent);
            temp.Height = 900;
            temp.Width = 1500;
            temp.ResizeMode = ResizeMode.NoResize;
            temp.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            temp.WindowStyle = WindowStyle.ToolWindow;
            temp.UseLayoutRounding = true;
            this.Width = 1500;
            this.Height = 900;
            this.MinHeight = 800;
            this.MinWidth = 1400;


        }


        private void btnSavePrint_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (listView1.Items.Count <= 0)
                {

                    MessageBox.Show("No Items in Print header", "No Items in header", MessageBoxButton.OK, MessageBoxImage.Warning);

                }

                else
                {

                    if (!((StoreManagerViewModel)this.DataContext).SaveHeaders()) { throw new Exception(); }

                    else { MessageBox.Show("Sucessfully updated print Header", "Success", MessageBoxButton.OK, MessageBoxImage.Information); }

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error in saving Print Headers", "Error!", MessageBoxButton.OK, MessageBoxImage.Stop);

            }


        }

        private void btnRemovefromList_Click(object sender, RoutedEventArgs e)
        {
            e.Handled = true;
            if (listView1.SelectedIndex >= 0)
            {
                ((StoreManagerViewModel)this.DataContext).listPrintLines.RemoveAt(listView1.SelectedIndex);

            }
        }

        private void listView1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;

            if (sender is ListView){

                ((StoreManagerViewModel)this.DataContext).ShowItemSelectedInList((ListView)sender);

        }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            ((StoreManagerViewModel)this.DataContext).ClearForm();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)(((StoreManagerViewModel)this.DataContext).Parent)).ActivateItem(new FrontViewModel());
            
        }

        private void btnSavePwd_Click(object sender, RoutedEventArgs e)
        {
            if (((StoreManagerViewModel)this.DataContext).UpdatePassword(txtAdminPwdBox.Password, txtPwdBox.Password, txtConfirmPwdBox.Password))
            {

                txtAdminPwdBox.Password = ""; txtPwdBox.Password = ""; txtConfirmPwdBox.Password = "";

            }
        }
    }
}
