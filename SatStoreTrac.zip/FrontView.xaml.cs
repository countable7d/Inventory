﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Caliburn.Micro;

namespace SatStoreTrac
{
    /// <summary>
    /// Interaction logic for FrontView.xaml
    /// </summary>
    public partial class FrontView : UserControl
    {
        public FrontView()
        {
            InitializeComponent();
        }
    
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            System.Environment.Exit(0);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 

        private void Button_Purchase_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((FrontViewModel)this.DataContext).Parent).ActivateItem(new PurchaseTrackViewModel());
        }
        private void Button_Dispatch_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((FrontViewModel)this.DataContext).Parent).ActivateItem(new DispatchTrackViewModel());

        }

        private void Items_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((FrontViewModel)this.DataContext).Parent).ActivateItem(new AddItemViewModel());
        }

        private void OutStores_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((FrontViewModel)this.DataContext).Parent).ActivateItem(new StoreManageViewModel());
        }

        private void Admin_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((FrontViewModel)this.DataContext).Parent).ActivateItem(new StoreManagerViewModel());
        }

        private void Returns_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((FrontViewModel)this.DataContext).Parent).ActivateItem(new ReturnsViewModel());
        }

        private void DispatchReport_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((FrontViewModel)this.DataContext).Parent).ActivateItem(new DispatchesReportViewModel());
        }

        private void PurchaseReport_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((FrontViewModel)this.DataContext).Parent).ActivateItem(new PurchasesReportViewModel());
        }

        private void ReturnsReport_Click(object sender, RoutedEventArgs e)
        {
            ((IConductor)((FrontViewModel)this.DataContext).Parent).ActivateItem(new PurchaseReturnsReportViewModel());
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

            if ((System.Windows.SystemParameters.WorkArea.Width < 1500) ||  (System.Windows.SystemParameters.WorkArea.Height< 900))
            {
                screenHolder.Width = System.Windows.SystemParameters.WorkArea.Width;
                screenHolder.Height = System.Windows.SystemParameters.WorkArea.Height;

            }
            
            
        }

    }
    
    
    
    
}
