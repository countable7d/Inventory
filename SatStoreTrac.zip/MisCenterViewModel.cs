﻿using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ActivityDB;
using Caliburn.Micro;
using NHibernate;
using NHibernate.Hql;
using System.Data;
using System.Globalization;
using ActivityDB.EntityLayer;


namespace SatStoreTrac
{
    class MisCenterViewModel: Screen
    {

        public MisCenterViewModel()
        {

        }
    }
}
